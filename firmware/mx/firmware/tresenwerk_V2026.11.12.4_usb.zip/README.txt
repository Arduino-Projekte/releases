Nur fuer Elecrow ESP32-P4, 16 MB Flash, XIP-Build.
Python installieren, danach: py -m pip install esptool
USB-Datenkabel anschliessen, COM-Port im Geraete-Manager ermitteln.
Im entpackten Ordner: flash_usb.bat COM7 (Port ersetzen).
Bei Verbindungsproblemen BOOT halten, RESET druecken, BOOT loslassen.
Schreibt Bootloader, Partitionen, OTA-Startdaten, Anwendung und LittleFS.
Bestehende Flash-Einstellungen koennen ueberschrieben werden. SD-Karte bleibt unberuehrt.
