@echo off
setlocal
if "%~1"=="" (echo Aufruf: flash_usb.bat COM7 & exit /b 1)
cd /d "%~dp0"
py -m esptool --chip esp32p4 --port %1 --baud 460800 write-flash 0x0 mx_main.ino.merged.bin 0xA10000 mx_main.littlefs.bin
if errorlevel 1 exit /b 1
echo Fertig. RESET druecken.
