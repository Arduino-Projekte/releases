"""Komplettsicherung und Rücksicherung.

Eine Sicherung ist ein ZIP mit
- fcg_collector.sqlite3: konsistente Kopie über die SQLite-Backup-API, auch
  während der Collector läuft,
- secret.key: ohne ihn lassen sich die gespeicherten Gateway- und
  SMTP-Passwörter nach einer Rücksicherung auf einer neuen NAS nicht lesen,
- backup.json: Version, Schema, Zeitpunkt, Anlass und Zahlen zur Übersicht.

Der Sicherungsordner liegt im Datenordner (Hyper Backup sichert ihn mit) oder
per FCG_BACKUP_DIR auf einer eigenen Freigabe. Wegen secret.key gehört er
nicht in den Exportordner für die Kollegen.
"""
from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
from contextlib import closing, contextmanager
import sqlite3
import struct
import tempfile
import threading
import time
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from cryptography.fernet import Fernet, InvalidToken

from . import __version__, backup_crypto
from .db import SCHEMA_VERSION, Database, now_text

log = logging.getLogger("fcg_nas.backup")

DB_NAME = "fcg_collector.sqlite3"
KEY_NAME = "secret.key"
INFO_NAME = "backup.json"
NAME_PATTERN = re.compile(r"^FCG_Sicherung_(\d{4}-\d{2}-\d{2})_(\d{6})_([a-z_]+?)(?:_[0-9a-f]{12})?\.zip(?:\.enc)?$")
KINDS = {"auto": "nächtlich", "manuell": "von Hand", "vor_update": "vor Update", "vor_ruecksicherung": "vor Rücksicherung"}
KEEP_AT_LEAST = 3
MAX_RESTORE_BYTES = 1024 * 1024 * 1024
REQUIRED_TABLES = {"settings", "users", "gateways", "sites", "entries"}


class BackupError(Exception):
    pass


@dataclass
class BackupFile:
    name: str
    path: Path
    size: int
    created: str
    kind: str

    @property
    def kind_text(self) -> str:
        return KINDS.get(self.kind, self.kind)


@dataclass
class RestoreInfo:
    version: str = ""
    schema: int = 0
    created_at: str = ""
    kind: str = ""
    has_key: bool = False
    counts: dict[str, int] = field(default_factory=dict)
    problems: list[str] = field(default_factory=list)
    accounts: list[dict] = field(default_factory=list)


def _bounded_zip_directory(path: Path) -> None:
    """Reject huge central directories before ZipFile allocates its member list."""
    size = path.stat().st_size
    if size > MAX_RESTORE_BYTES + 1024:
        raise BackupError('Die Sicherung überschreitet die Dateigrößengrenze.')
    with path.open('rb') as handle:
        handle.seek(max(0,size-65557))
        tail = handle.read(65557)
    offset = tail.rfind(b'PK\x05\x06')
    if offset < 0 or len(tail)-offset < 22:
        raise BackupError('Die Datei ist kein gültiges ZIP.')
    _,disk,start,disk_count,count,directory_size,directory_offset,comment = struct.unpack('<4s4H2IH',tail[offset:offset+22])
    if (disk or start or disk_count != count or count > 16 or directory_size > 65536
            or offset+22+comment != len(tail) or directory_offset+directory_size > size):
        raise BackupError('Das ZIP enthält zu viele Dateien oder ein ungültiges Inhaltsverzeichnis.')


def _counts(conn: sqlite3.Connection) -> dict[str, int]:
    result = {}
    for table in ("gateways", "sites", "entries", "gateway_logs", "runs", "users"):
        try:
            result[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except sqlite3.Error:
            result[table] = 0
    return result


class BackupService:
    def __init__(self, db: Database, data_dir: Path, backup_dir: Path) -> None:
        self.db = db
        self.data_dir = Path(data_dir)
        self.backup_dir = Path(backup_dir)
        self.key_path = self.data_dir / KEY_NAME
        self._lock = threading.RLock()

    # --- Sichern -----------------------------------------------------------

    def create(self, kind: str, passphrase: str = "") -> BackupFile:
        if kind not in KINDS:
            raise ValueError(kind)
        if passphrase:
            from .password_policy import check_new_password
            check_new_password(passphrase)
        with self._lock:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            from .storage import require_space
            needed = self.db.path.stat().st_size * (3 if passphrase else 2) if self.db.path.exists() else 0
            require_space(self.backup_dir, needed, max(128, self.db.get_int_setting('alert_disk_min_mb')) * 1024**2)
            stamp = datetime.now()
            name = f"FCG_Sicherung_{stamp.strftime('%Y-%m-%d_%H%M%S')}_{kind}_{secrets.token_hex(6)}.zip"
            target = self.backup_dir / name
            with tempfile.TemporaryDirectory(dir=self.backup_dir) as tmp:
                copy = Path(tmp) / DB_NAME
                with self.db.connect() as src:
                    dst = sqlite3.connect(copy)
                    try:
                        src.backup(dst)
                        counts = _counts(dst)
                        schema = dst.execute("PRAGMA user_version").fetchone()[0]
                    finally:
                        dst.close()
                info = {"schema_name": "fcg_nas_backup_v1", "version": __version__, "schema": schema,
                        "created_at": now_text(), "kind": kind, "counts": counts}
                partial = Path(tmp) / (name + ".part")
                with zipfile.ZipFile(partial, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                    zf.write(copy, DB_NAME)
                    if self.key_path.exists():
                        zf.write(self.key_path, KEY_NAME)
                    zf.writestr(INFO_NAME, json.dumps(info, ensure_ascii=False, indent=2))
                if passphrase:
                    encrypted = Path(tmp) / (name + ".enc")
                    backup_crypto.encrypt(partial, encrypted, passphrase)
                    target = target.with_name(target.name + ".enc")
                    name = target.name
                    partial = encrypted
                os.replace(partial, target)
            os.chmod(target, 0o600)
        log.info("Sicherung angelegt: %s", name)
        return self._entry(target)

    def _entry(self, path: Path) -> BackupFile:
        match = NAME_PATTERN.match(path.name)
        created = f"{match.group(1)} {match.group(2)[:2]}:{match.group(2)[2:4]}:{match.group(2)[4:]}" if match else ""
        return BackupFile(path.name, path, path.stat().st_size, created, match.group(3) if match else "")

    def list(self) -> list[BackupFile]:
        if not self.backup_dir.is_dir():
            return []
        files = [self._entry(p) for p in self.backup_dir.iterdir() if p.is_file() and NAME_PATTERN.match(p.name)]
        return sorted(files, key=lambda f: (f.created, f.path.stat().st_mtime_ns, f.name), reverse=True)

    def path_of(self, name: str) -> Path:
        if not NAME_PATTERN.match(name or ""):
            raise BackupError("Unbekannte Sicherung.")
        path = self.backup_dir / name
        if not path.is_file():
            raise BackupError("Sicherung nicht gefunden.")
        return path

    def prune(self, keep_days: int) -> list[str]:
        """Löscht Sicherungen älter als keep_days; die neuesten drei bleiben immer."""
        limit = (datetime.now() - timedelta(days=keep_days)).strftime("%Y-%m-%d %H:%M:%S")
        removed = []
        for item in self.list()[KEEP_AT_LEAST:]:
            if item.created and item.created < limit:
                item.path.unlink(missing_ok=True)
                removed.append(item.name)
        return removed

    def last_auto_date(self) -> str:
        for item in self.list():
            if item.kind == "auto":
                return item.created[:10]
        return ""

    def due(self, now: datetime | None = None) -> bool:
        now = now or datetime.now()
        settings = self.db.get_settings()
        if settings.get("backup_enabled") != "1":
            return False
        hour = int(settings.get("backup_hour") or 2)
        return now.hour >= hour and self.last_auto_date() < now.strftime("%Y-%m-%d")

    def run_nightly(self) -> str:
        """Nächtliche Sicherung mit Aufräumen. Liefert '' oder den Fehler."""
        try:
            item = self.create("auto")
            removed = self.prune(self.db.get_int_setting("backup_keep_days"))
            summary = f"{item.name} ({item.size // 1024} KB)" + (f", {len(removed)} alte gelöscht" if removed else "")
            self._remember(True, summary)
            return ""
        except (OSError, sqlite3.Error, ValueError, BackupError) as exc:
            log.exception("Sicherung fehlgeschlagen")
            self._remember(False, str(exc))
            return str(exc)

    def _remember(self, ok: bool, summary: str) -> None:
        self.db.set_settings({"backup_last_at": now_text(), "backup_last_ok": "1" if ok else "0",
                              "backup_last_summary": summary[:500]})

    def problem(self) -> str:
        values = self.db.get_settings()
        if values.get("backup_enabled") != "1":
            return ""
        if values.get("backup_last_ok") == "0":
            return values.get("backup_last_summary", "fehlgeschlagen")
        last = self.last_auto_date()
        if last and last < (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d"):
            return f"Letzte nächtliche Sicherung vom {last}."
        return ""

    # --- Zurücksichern ------------------------------------------------------

    def inspect(self, zip_path: Path, work_dir: Path) -> RestoreInfo:
        """Prüft ein hochgeladenes ZIP und entpackt die Datenbank nach work_dir."""
        info = RestoreInfo()
        try:
            _bounded_zip_directory(zip_path)
            with zipfile.ZipFile(zip_path) as zf:
                members = zf.infolist()
                if len(members) > 16 or len({m.filename for m in members}) != len(members):
                    raise BackupError("Das ZIP enthält doppelte oder zu viele Dateien.")
                names = {m.filename for m in members}
                limits = {DB_NAME: MAX_RESTORE_BYTES, KEY_NAME: 200, INFO_NAME: 64 * 1024}
                for member in members:
                    if member.filename in limits and member.file_size > limits[member.filename]:
                        raise BackupError(f"{member.filename} im ZIP ist unplausibel groß.")
                if DB_NAME not in names:
                    raise BackupError("Im ZIP fehlt fcg_collector.sqlite3. Ist das eine Sicherung der FCG Zentrale?")
                unknown = names - {DB_NAME, KEY_NAME, INFO_NAME}
                if unknown:
                    info.problems.append(f"Unbekannte Dateien werden ignoriert: {', '.join(sorted(unknown))}")
                if zf.getinfo(DB_NAME).file_size > MAX_RESTORE_BYTES:
                    raise BackupError("Die Datenbank im ZIP ist unplausibel groß.")
                with zf.open(DB_NAME) as source, (work_dir / DB_NAME).open("wb") as target:
                    shutil.copyfileobj(source, target, length=1024 * 1024)
                if KEY_NAME in names:
                    key = zf.read(KEY_NAME)
                    if not key.strip():
                        raise BackupError("secret.key im ZIP ist ungültig.")
                    try:
                        Fernet(key.strip())
                    except (ValueError, TypeError) as exc:
                        raise BackupError("secret.key im ZIP ist ungültig.") from exc
                    (work_dir / KEY_NAME).write_bytes(key.strip())
                    os.chmod(work_dir / KEY_NAME, 0o600)
                    info.has_key = True
                if INFO_NAME in names:
                    meta = json.loads(zf.read(INFO_NAME).decode("utf-8"))
                    if not isinstance(meta, dict):
                        raise BackupError("backup.json muss ein Objekt enthalten.")
                    info.version = str(meta.get("version", ""))
                    info.created_at = str(meta.get("created_at", ""))
                    info.kind = str(meta.get("kind", ""))
        except zipfile.BadZipFile as exc:
            raise BackupError("Die Datei ist kein gültiges ZIP.") from exc
        except (ValueError, KeyError) as exc:
            raise BackupError(f"backup.json im ZIP ist ungültig: {exc}") from exc
        try:
            conn = sqlite3.connect(f"file:{work_dir / DB_NAME}?mode=ro", uri=True)
            try:
                check = conn.execute("PRAGMA integrity_check").fetchone()[0]
                if check != "ok":
                    raise BackupError(f"Die Datenbank im ZIP ist beschädigt: {check}")
                tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
                missing = REQUIRED_TABLES - tables
                if missing:
                    raise BackupError(f"Die Datenbank im ZIP ist keine Collector-Datenbank (fehlt: {', '.join(sorted(missing))}).")
                info.schema = conn.execute("PRAGMA user_version").fetchone()[0]
                info.counts = _counts(conn)
                info.accounts = [{'username':row[0], 'role':row[1]} for row in conn.execute('SELECT username,role FROM users ORDER BY username')]
                if conn.execute('PRAGMA foreign_key_check').fetchone():
                    raise BackupError('Die Datenbank enthält ungültige Verweise zwischen Datensätzen.')
                self._validate_secrets(conn, work_dir / KEY_NAME if info.has_key else self.key_path)
            finally:
                conn.close()
        except sqlite3.DatabaseError as exc:
            raise BackupError(f"Die Datei im ZIP ist keine lesbare SQLite-Datenbank: {exc}") from exc
        if info.schema > SCHEMA_VERSION:
            raise BackupError(f"Die Sicherung hat Schema {info.schema}, diese Version kennt nur {SCHEMA_VERSION}. "
                              "Erst den Collector aktualisieren.")
        try:
            Database(work_dir / DB_NAME).migrate()
        except (RuntimeError, sqlite3.Error) as exc:
            raise BackupError('Das Schema der Sicherung kann nicht sicher migriert werden.') from exc
        if not info.has_key:
            info.problems.append("Ohne secret.key bleiben die gespeicherten Gateway- und SMTP-Passwörter nur lesbar, "
                                 "wenn die Sicherung von dieser NAS stammt.")
        return info

    @staticmethod
    def _validate_secrets(conn: sqlite3.Connection, key_path: Path) -> None:
        """Check every persisted encrypted credential without exposing its value."""
        try:
            cipher = Fernet(key_path.read_bytes().strip()) if key_path.exists() else None
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for table in ("gateways", "update_sources"):
                if table in tables:
                    for row in conn.execute(f'SELECT password_enc FROM "{table}" WHERE length(password_enc) > 0'):
                        if cipher is None:
                            raise ValueError("missing key")
                        cipher.decrypt(row[0].encode("ascii"))
            if 'account_totp' in tables:
                for row in conn.execute('SELECT secret_enc FROM account_totp'):
                    if cipher is None:
                        raise ValueError('missing key')
                    cipher.decrypt(row[0].encode('ascii'))
            for row in conn.execute("SELECT value FROM settings WHERE key LIKE '%_enc' AND value != ''"):
                if cipher is None:
                    raise ValueError("missing key")
                cipher.decrypt(row[0].encode("ascii"))
        except (OSError, ValueError, TypeError, InvalidToken, UnicodeError) as exc:
            raise BackupError("Der Sicherungsschlüssel passt nicht zu den gespeicherten Zugangsdaten.") from exc

    def _write_key(self, value: bytes) -> None:
        fd, name = tempfile.mkstemp(prefix=".restore-key-", dir=self.key_path.parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(value)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, self.key_path)
        finally:
            Path(name).unlink(missing_ok=True)

    @staticmethod
    def _sync_folder(path: Path) -> None:
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    @property
    def _recovery_dir(self) -> Path:
        return self.data_dir / ".restore-transaction"

    def recover_pending(self) -> bool:
        """Before opening services, undo an interrupted database/key activation."""
        folder = self._recovery_dir
        if not (folder / "pending").exists():
            if folder.exists():
                shutil.rmtree(folder)
            return False
        with self._lock, self.db.maintenance():
            with closing(sqlite3.connect(folder / DB_NAME)) as source, self.db.connect() as target:
                source.backup(target)
            if (folder / KEY_NAME).exists():
                self._write_key((folder / KEY_NAME).read_bytes())
            else:
                self.key_path.unlink(missing_ok=True)
            (folder / "pending").unlink()
            self._sync_folder(folder)
            shutil.rmtree(folder)
            self._sync_folder(self.data_dir)
        log.warning("Unterbrochene Rücksicherung zurückgerollt; vorheriger Datenstand wiederhergestellt")
        return True

    @contextmanager
    def _activation_transaction(self):
        folder = self._recovery_dir
        if folder.exists():
            raise BackupError("Eine Rücksicherung wartet auf Wiederherstellung. Dienst neu starten.")
        folder.mkdir(mode=0o700)
        with self.db.connect() as source, closing(sqlite3.connect(folder / DB_NAME)) as target:
            source.backup(target)
        if self.key_path.exists():
            (folder / KEY_NAME).write_bytes(self.key_path.read_bytes())
        for child in folder.iterdir():
            with child.open("rb") as handle:
                os.fsync(handle.fileno())
        self._sync_folder(folder)
        self._sync_folder(self.data_dir)
        with (folder / "pending").open("xb") as handle:
            handle.write(b"rollback required\n")
            handle.flush()
            os.fsync(handle.fileno())
        self._sync_folder(folder)
        try:
            yield
        except BaseException:
            self.recover_pending()
            raise
        else:
            (folder / "pending").unlink()
            self._sync_folder(folder)
            shutil.rmtree(folder)
            self._sync_folder(self.data_dir)

    def restore(self, work_dir: Path, reload_secrets: Callable[[], None] | None = None) -> BackupFile:
        """Migrate privately, invalidate sessions, activate together, roll back on failure."""
        staged = Database(work_dir / DB_NAME)
        staged.migrate()
        with staged.connect() as conn:
            self._validate_secrets(conn, work_dir / KEY_NAME if (work_dir / KEY_NAME).exists() else self.key_path)
            conn.execute("DELETE FROM sessions")
            # A backup must not resurrect already consumed recovery codes or
            # permit replay of a TOTP from the current time slot.
            conn.execute("UPDATE account_totp SET recovery='[]',last_step=?",(int(time.time())//30,))
        # All application connections participate in this gate. Backups always
        # acquire the service lock first, so nightly backups cannot invert locks.
        with self._lock, self.db.maintenance():
            safety = self.create("vor_ruecksicherung")
            try:
                with self._activation_transaction():
                    with staged.connect() as source, self.db.connect() as target:
                        source.backup(target)
                    # Flush the new database before the durable commit marker
                    # is removed; SQLite backup otherwise may only reside in WAL.
                    with self.db.connect() as target:
                        target.execute("PRAGMA wal_checkpoint(FULL)")
                    with self.db.path.open("rb") as handle:
                        os.fsync(handle.fileno())
                    if (work_dir / KEY_NAME).exists():
                        self._write_key((work_dir / KEY_NAME).read_bytes())
                        self._sync_folder(self.data_dir)
                    if reload_secrets:
                        reload_secrets()
            except BaseException:
                if reload_secrets:
                    reload_secrets()
                raise
        log.warning("Rücksicherung eingespielt, vorheriger Stand in %s", safety.name)
        return safety
