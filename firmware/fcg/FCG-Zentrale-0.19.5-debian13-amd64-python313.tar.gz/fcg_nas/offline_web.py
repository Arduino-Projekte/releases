"""Admin UI for SMB sources, offline approvals and host-worker requests."""
import ipaddress
import json
import os
from urllib.parse import urlsplit

from fastapi import File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse
from .offline_updates import OfflineUpdates
from .mirror_migration import MirrorMigration
from .gateway_client import GatewayAuth
from .smb_updates import Share, validate_source
from . import ota as ota_mod
from .docker_queue import status as docker_status
from .vm_queue import status as vm_status

NOTICES={'source_saved':'SMB-Updatefreigabe gespeichert.', 'source_deleted':'Updatefreigabe entfernt. Bereits eingelesene Pakete bleiben erhalten.',
         'credentials_cleared':'SMB-Zugangsdaten gelöscht und Updatefreigabe deaktiviert.',
         'scanning':'Paketprüfung gestartet.', 'approved':'Firmware freigegeben. Sie ist jetzt über den lokalen Updatepfad erreichbar.',
         'distributing':'Firmware freigegeben und Gateway-Verteilung gestartet.',
         'queued':'Zentralenupdate angefordert. Fortschritt und installierte Version nach dem Neustart prüfen.',
         'mirror_saved':'Lokale Gateway-Updateadresse gespeichert.'}


def mirror_url(value):
    value=value.strip()
    try:
        u=urlsplit(value)
        if (len(value)>500 or u.scheme!='http' or not u.hostname or u.username or u.password or u.query or u.fragment
                or not u.path.endswith('/update.json') or u.hostname.lower()=='localhost'):
            raise ValueError()
        _=u.port
        try:
            address=ipaddress.ip_address(u.hostname)
            if address.is_loopback or address.is_unspecified:raise ValueError('unreachable')
        except ValueError as exc:
            if str(exc)=='unreachable':raise
    except ValueError:
        raise ValueError('Eine von den Gateways erreichbare HTTP-Adresse zum lokalen update.json angeben, ohne Zugangsdaten oder Abfrageparameter.') from None
    return value


def add_routes(app, config, db, secrets, ota, updater, current, check_csrf, render, backups):
    migration = MirrorMigration(ota.trusted)
    service=OfflineUpdates(db,secrets,config.data_dir,ota,config.deployment)

    def destination():
        settings = db.get_settings()
        target = json.loads(settings.get('ota_smb_destination') or 'null')
        if target:
            target['password_enc'] = settings.get('ota_smb_password_enc', '')
        return target

    def publish_external(manifest, raw_manifest, firmware):
        target = destination()
        if not target:
            return
        try:
            with Share(target, secrets.decrypt(target['password_enc']), timeout=90) as share:
                current = share.read_manifest(ota_mod.MAX_MANIFEST_BYTES)
                if current is not None:
                    existing = ota_mod.parse_manifest(current, ota.trusted)
                    if ota_mod.version_key(existing['version']) > ota_mod.version_key(manifest['version']):
                        raise ValueError('Am SMB-Ziel liegt bereits eine neuere Firmware.')
                    if existing['version'] == manifest['version'] and existing['sha256'] != manifest['sha256']:
                        raise ValueError('Am SMB-Ziel liegt dieselbe Version mit anderer Prüfsumme.')
                share.publish_files([(manifest['file'], firmware), (ota_mod.LEGACY_BIN, firmware),
                                     ('update.json', raw_manifest)])
        except ValueError as exc:
            raise ota_mod.OtaError(str(exc)) from None
        except OSError:
            raise ota_mod.OtaError('SMB-Ablageziel konnte nicht verarbeitet werden.') from None

    ota.publish_external = publish_external

    def redirect(notice):return RedirectResponse('/admin/offline-updates?notice='+notice,status_code=303)

    def preflight(row, worker):
        from .storage import require_space
        from .vm_queue import ROOT as vm_root
        from .central_updates import version_key
        from . import __version__, docker_package

        blockers = []
        if (row['kind'] != config.deployment or
                (row['kind'] == 'docker' and row['target'] != docker_package.architecture()) or
                version_key(row['version']) <= version_key(__version__)):
            blockers.append('Paket ist keine neuere Version für diese Installation.')
        if worker.get('state') in ('queued', 'preparing') or worker.get('pending'):
            blockers.append('Ein Zentralenupdate läuft oder wartet bereits.')
        if config.deployment == 'docker' and not worker.get('ready'):
            blockers.append('Der Docker-Updatedienst meldet sich nicht.')
        if config.deployment == 'vm' and not os.access(vm_root / 'inbox', os.W_OK | os.X_OK):
            blockers.append('Das Eingangsverzeichnis des VM-Updatedienstes ist nicht beschreibbar.')
        if updater.running or service._running:
            blockers.append('Paketprüfung oder Gateway-Verteilung läuft.')
        archive = service.root / 'cache' / row['id'] / row['filename']
        try:
            if archive.is_symlink() or not archive.is_file():
                raise FileNotFoundError()
            reserve = max(128, db.get_int_setting('alert_disk_min_mb')) * 1024**2
            needed = archive.stat().st_size + config.db_path.stat().st_size
            require_space(service.root if config.deployment == 'docker' else vm_root / 'inbox', needed, reserve)
        except (OSError, ValueError) as exc:
            blockers.append(str(exc) if isinstance(exc, ValueError) else 'Paketdatei oder Speicherprüfung nicht verfügbar.')
        return blockers

    def page(request,session,message=None,status=200):
        with db.connect() as conn:
            gateways=[dict(row) for row in conn.execute('SELECT * FROM gateways WHERE enabled=1 ORDER BY lower(label),host')]
        values=db.get_settings()
        worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
        worker['text']={'queued':'Installation angefordert','preparing':'Update wird vorbereitet','installed':'Installiert','failed':'Installation fehlgeschlagen','rolled_back':'Vorheriger Stand wiederhergestellt'}.get(worker.get('state'),'')
        packages=service.packages()
        for row in packages:
            if row['kind'] == config.deployment and row['cached'] and row['compatible'] and row['newer']:
                row['preflight'] = preflight(row, worker)
            if row['state']=='queued' and (worker.get('version')==row['version']):
                state=worker.get('state')
                if state in ('installed','failed','rolled_back'):
                    service.decide(row['id'],state,row['decided_by'] or 'admin')
                    row['state']=state
                    from .offline_updates import STATES
                    row['state_text']=STATES[state]
        if message is None and request.query_params.get('notice') in NOTICES:
            message=('ok',NOTICES[request.query_params['notice']])
        try:
            latest_backup = next(iter(backups.list()), None)
        except OSError:
            latest_backup = None
        return render(request,'offline_updates.html',session,status_code=status,message=message,nav='ota',
            latest_backup=latest_backup, sources=service.sources(),packages=packages,job=service.job(),gateways=gateways,
            migration=json.loads(values.get('offline_mirror_migration') or 'null'),
            destination=({key: value for key, value in (destination() or {}).items() if key != 'password_enc'}),
            released_firmware=ota.published().version, values=values,deployment=config.deployment,worker=worker,steps=updater.steps(),
            update_running=updater.running,gateway_admin_saved=bool(values.get('gw_admin_user') and values.get('gw_admin_password_enc')))

    @app.get('/admin/offline-updates')
    def overview(request: Request):return page(request,current(request,admin=True))

    @app.post('/admin/offline-updates/sources/save')
    def source_save(request: Request, csrf: str=Form(''), source_id: int=Form(0), name: str=Form(''),
                    server: str=Form(''), share: str=Form(''), subdir: str=Form(''), username: str=Form(''),
                    password: str=Form(''), encrypt: str=Form(''), enabled: str=Form(''),
                    smb_path: str | None=Form(None)):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            values = dict(name=name, server=server, share=share, subdir=subdir,
                          username=username, encrypt=encrypt=='1', enabled=enabled=='1')
            if smb_path is not None:
                values['smb_path'] = smb_path
            source_id = service.save_source(source_id, values, password)
        except (ValueError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,ValueError) else 'Updatefreigabe konnte nicht gespeichert werden.'),400)
        db.audit(session.username,'offline_source_saved',str(source_id))
        return redirect('source_saved')

    @app.post('/admin/offline-updates/sources/{source_id}/action')
    def source_action(request: Request,source_id: int,csrf: str=Form(''),action: str=Form(''),confirm: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if action=='test':return page(request,session,('ok',service.test(source_id)))
            if confirm!='1':raise ValueError('Löschen zuerst mit dem Haken bestätigen.')
            if action=='delete':service.delete_source(source_id);notice='source_deleted'
            elif action=='clear':service.clear_credentials(source_id);notice='credentials_cleared'
            else:raise ValueError('Unbekannte Freigabeaktion.')
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_source_'+action,str(source_id))
        return redirect(notice)

    @app.post('/admin/offline-updates/mode')
    def mode(request: Request,csrf: str=Form(''),mode: str=Form('online'), smb_auto_scan: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
            if worker.get('state') in ('queued','preparing') or worker.get('pending'):
                raise ValueError('Updatebetrieb erst nach dem laufenden Zentralenupdate ändern.')
            service.set_mode(mode)
            with service._lock:
                db.set_settings({'offline_smb_auto_scan': '1' if smb_auto_scan == '1' else '0'})
                service._next_auto_scan = 0.0
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_mode_saved',mode)
        return page(request,session,('ok','Updatebetrieb gespeichert.'))

    @app.post('/admin/offline-updates/scan')
    def scan(request: Request,csrf: str=Form(''),source_id: int=Form(0)):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if source_id:service.source(source_id)
            service.start_scan(source_id or None)
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_scan_requested',str(source_id))
        return redirect('scanning')

    @app.post('/admin/offline-updates/firmware-upload')
    def firmware_upload(request: Request, csrf: str=Form(''),
                        manifest: UploadFile=File(...), firmware: UploadFile=File(...)):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            raw=manifest.file.read(ota_mod.MAX_MANIFEST_BYTES+1)
            package_id=service.import_firmware(raw,firmware.file)
        except (ValueError,ota_mod.OtaError,OSError):
            return page(request,session,('err','Firmware konnte nicht eingelesen werden. Signiertes update.json und passende BIN-Datei auswählen; Signatur, Prüfsumme und Dateigröße prüfen.'),400)
        finally:
            manifest.file.close();firmware.file.close()
        db.audit(session.username,'offline_firmware_uploaded',package_id)
        return page(request,session,('ok','Firmware geprüft und intern gespeichert. Sie wartet auf Ihre Freigabe.'))

    @app.post('/admin/offline-updates/destination')
    def save_destination(request: Request, csrf: str = Form(''), action: str = Form(''),
                         smb_path: str = Form(''), username: str = Form(''), password: str = Form(''),
                         encrypt: str = Form('')):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            with ota._lock:
                if action in ('save', 'test'):
                    target = validate_source(dict(name='OTA', smb_path=smb_path,
                                                  username=username, encrypt=encrypt == '1'))
                    previous = destination() or {}
                    identity = ('server', 'share', 'subdir', 'username')
                    if not password and previous.get('password_enc') and all(previous.get(k) == target[k] for k in identity):
                        password = secrets.decrypt(previous['password_enc'])
                    if not password:
                        raise ValueError('SMB-Passwort für das Ablageziel eingeben.')
                    with Share(target, password, timeout=20) as share:
                        share.test_write()
                    if action == 'save':
                        db.set_settings({'ota_smb_destination': json.dumps(target),
                                         'ota_smb_password_enc': secrets.encrypt(password)})
                        message = 'SMB-Ablageziel geprüft und gespeichert.'
                    else:
                        message = 'SMB-Schreibtest erfolgreich.'
                elif action == 'local':
                    db.set_settings({'ota_smb_destination': '', 'ota_smb_password_enc': ''})
                    message = 'Lokaler OTA-Ordner wieder als Ablageziel aktiv.'
                elif action == 'publish':
                    if not destination():
                        raise ValueError('Zuerst ein SMB-Ablageziel speichern.')
                    state = ota.published()
                    if not state.version or not state.present:
                        raise ValueError('Keine bereits freigegebene Firmware verfügbar.')
                    ota.approve(state.version, session.username)
                    message = 'Freigegebene Firmware am SMB-Ziel bereitgestellt.'
                else:
                    raise ValueError('Unbekannte Aktion für das Ablageziel.')
        except (ValueError, OSError, ota_mod.OtaError) as exc:
            return page(request, session, ('err', str(exc) if isinstance(exc, (ValueError, ota_mod.OtaError))
                                          else 'SMB-Ablageziel konnte nicht verarbeitet werden.'), 400)
        db.audit(session.username, 'ota_smb_destination', action)
        return page(request, session, ('ok', message))

    @app.post('/admin/offline-updates/mirror')
    def save_mirror(request: Request,csrf: str=Form(''),url: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:clean=mirror_url(url)
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        with ota._lock:
            old = db.get_settings().get('offline_mirror_url', '')
            if old == clean:
                return redirect('mirror_saved')
            pending = None
            note = None
            if old:
                try:
                    pending = migration.offer(old, clean)
                except (ValueError, OSError, ota_mod.OtaError) as exc:
                    note = str(exc) if isinstance(exc, ValueError) else 'Die vorhandenen Firmwaredateien konnten nicht geprüft werden.'
            db.set_settings({'offline_mirror_url': clean, 'offline_mirror_migration': json.dumps(pending)})
        db.audit(session.username, 'offline_mirror_saved', '')
        if note:
            return page(request, session, ('warn', 'Updateadresse gespeichert. ' + note))
        return RedirectResponse('/admin/offline-updates?notice=mirror_saved#mirror-address', status_code=303)

    @app.post('/admin/offline-updates/mirror/migrate')
    def migrate_mirror(request: Request, csrf: str=Form(''), action: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            with ota._lock:
                values = db.get_settings()
                pending = json.loads(values.get('offline_mirror_migration') or 'null')
                if not pending or pending['new'] != values.get('offline_mirror_url'):
                    raise ValueError('Es gibt keine ausstehende Dateiübernahme.')
                if action == 'copy' and pending['phase'] == 'copy':
                    migration.copy(pending)
                    pending['phase'] = 'clean'
                elif action == 'clean' and pending['phase'] == 'clean' and not updater.running:
                    migration.clean(pending)
                    pending = None
                elif action == 'skip':
                    pending = None
                else:
                    raise ValueError('Diese Aktion ist derzeit nicht möglich.')
                db.set_settings({'offline_mirror_migration': json.dumps(pending)})
            db.audit(session.username, 'offline_mirror_migration', action)
        except (ValueError, OSError, ota_mod.OtaError) as exc:
            return page(request, session, ('err', str(exc) if isinstance(exc, ValueError) else
                        'Firmwaredateien konnten nicht übernommen oder bereinigt werden.'), 400)
        return RedirectResponse('/admin/offline-updates#mirror-address', status_code=303)

    @app.post('/admin/offline-updates/packages/{package_id}/approve')
    def approve(request: Request,package_id: str,csrf: str=Form(''),action: str=Form('approve'),confirm: str=Form(''),
                targets: list[str]=Form(default=[]),username: str=Form(''),password: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if confirm!='1':raise ValueError('Freigabe zuerst mit dem Haken bestätigen.')
            if action not in ('approve','distribute'):raise ValueError('Unbekannte Freigabeaktion.')
            gateways=[];auth=None;url=''
            if action=='distribute':
                values=db.get_settings();url=mirror_url(values.get('offline_mirror_url',''))
                if not username and not password and values.get('gw_admin_user') and values.get('gw_admin_password_enc'):
                    username,password=values['gw_admin_user'],secrets.decrypt(values['gw_admin_password_enc'])
                if not username.strip() or not password:raise ValueError('Gateway-Admin-Zugangsdaten eingeben oder unter Konten speichern.')
                auth=GatewayAuth(username.strip()[:64],password[:128])
                with db.connect() as conn:
                    enabled=[dict(row) for row in conn.execute('SELECT * FROM gateways WHERE enabled=1')]
                gateways=enabled if 'all' in targets else [g for g in enabled if str(g['id']) in targets]
                if not gateways:raise ValueError('Mindestens ein aktiviertes Gateway auswählen.')
            # Publication is pinned for the entire batch; another approval waits.
            with ota._lock:
                if updater.running:raise ValueError('Eine Gateway-Verteilung läuft bereits.')
                row=service.approve_gateway(package_id,session.username)
                if action=='distribute' and not updater.start(gateways,auth,session.username,row['version'],manifest_url=url):
                    raise ValueError('Verteilung konnte nicht gestartet werden. Firmware ist freigegeben; erneut verteilen.')
        except (ValueError,ota_mod.OtaError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,(ValueError,ota_mod.OtaError)) else 'Firmware konnte nicht bereitgestellt werden.'),400)
        db.audit(session.username,'offline_gateway_'+action,package_id)
        return redirect('distributing' if action=='distribute' else 'approved')

    @app.post('/admin/offline-updates/packages/{package_id}/install')
    def install(request: Request,package_id: str,csrf: str=Form(''),confirm: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if confirm!='1':raise ValueError('Zentralenupdate und kurzen Neustart zuerst bestätigen.')
            worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
            blockers = preflight(service.package(package_id), worker)
            if blockers:
                raise ValueError(' '.join(blockers))
            service.install(package_id,session.username)
        except (ValueError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,ValueError) else 'Updatedienst ist nicht erreichbar. Einrichtung prüfen.'),400)
        db.audit(session.username,'offline_central_install_requested',package_id)
        return redirect('queued')

    return service
