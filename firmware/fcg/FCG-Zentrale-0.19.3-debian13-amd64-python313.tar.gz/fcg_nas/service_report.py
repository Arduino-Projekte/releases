"""Minimal allowlisted diagnostics: no database, secret key, credentials or raw logs."""
import csv
from io import BytesIO, StringIO
import json
import platform
import zipfile

from . import __version__
from .db import SCHEMA_VERSION, now_text
from .site_history import observations


def passport(db, site_id):
    with db.connect() as conn:
        row = conn.execute('SELECT s.*,g.host,g.fw_version FROM sites s LEFT JOIN gateways g ON g.id=s.gateway_id AND (g.site_id IS NULL OR g.site_id=s.site_id) WHERE s.site_id=?', (site_id,)).fetchone()
    if not row:
        raise ValueError('Messstelle nicht gefunden.')
    changes = observations(db, site_id)
    identity = next((item['values'] for item in changes if item['actor']=='gateway:device'), {})
    counter = next((item['values'] for item in changes if item['actor']=='gateway:counter'), {})
    return {'site': dict(row), 'identity': identity, 'counter': counter, 'history': changes, 'created': now_text()}


def bundle(config, db, worker):
    output = BytesIO()
    with db.connect() as conn:
        gateways = [dict(row) for row in conn.execute('SELECT id,label,site_id,fw_version,last_attempt_at,last_ok_at,last_added FROM gateways ORDER BY id')]
        audit = [dict(row) for row in conn.execute('SELECT ts,username,action FROM audit ORDER BY id DESC LIMIT 100')]
        counts = {name: conn.execute(f'SELECT COUNT(*) FROM {name}').fetchone()[0]
                  for name in ('gateways','sites','entries','runs','gateway_logs')}
    report = {'at':now_text(), 'version':__version__, 'schema':SCHEMA_VERSION, 'deployment':config.deployment,
              'python':platform.python_version(), 'architecture':platform.machine(), 'counts':counts,
              'paths':{'data':str(config.data_dir),'backups':str(config.backups_dir),'export':str(config.export_dir)},
              'worker':{key:worker[key] for key in ('state','at','version','ready') if key in worker}}
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('system.json', json.dumps(report,ensure_ascii=False,indent=2))
        for name, rows in (('gateways.csv',gateways),('account-events.csv',audit)):
            text=StringIO()
            if rows:
                writer=csv.DictWriter(text,fieldnames=list(rows[0]),delimiter=';')
                writer.writeheader()
                writer.writerows({key: ("'"+value if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@')) else value)
                                  for key,value in row.items()} for row in rows)
            archive.writestr(name,text.getvalue())
        archive.writestr('README.txt','FCG service bundle: allowlisted status only. No passwords, key, database or raw log text.\n')
    return output.getvalue()
