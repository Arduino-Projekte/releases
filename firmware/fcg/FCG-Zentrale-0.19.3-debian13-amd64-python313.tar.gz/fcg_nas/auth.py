"""Benutzer, Passwörter und Sitzungen.

Zwei feste Konten: 'admin' (Verwaltung) und 'user' (gemeinsames Konto der
Kollegen, nur ansehen; bis V0.7.0 hieß es 'leser', der alte Name geht weiter). Passwörter als PBKDF2-SHA256, Sitzungen serverseitig.
"""
from __future__ import annotations

import base64
import hashlib
from functools import lru_cache
import hmac
import logging
import re
import secrets
import time
from dataclasses import dataclass

from .db import Database, now_text

log = logging.getLogger("fcg_nas.auth")

ADMIN_USER = "admin"
READER_USER = "user"
LEGACY_READER_USER = "leser"
ROLE_BY_USER = {ADMIN_USER: "admin", READER_USER: "reader"}

PBKDF2_ITERATIONS = 310_000
from .password_policy import MIN_PASSWORD_LENGTH, check_new_password
MAX_FAILED_LOGINS = 5
LOCK_SECONDS = 5 * 60
SESSION_SECONDS = 12 * 3600


@dataclass(frozen=True)
class Session:
    token: str
    username: str
    role: str
    csrf: str

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


class LoginLocked(Exception):
    def __init__(self, seconds: int) -> None:
        super().__init__(f"Zu viele Fehlversuche. Anmeldung in {seconds} s wieder möglich.")
        self.seconds = seconds


def hash_password(password: str, iterations: int = PBKDF2_ITERATIONS) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256${}${}${}".format(
        iterations, base64.b64encode(salt).decode("ascii"), base64.b64encode(digest).decode("ascii")
    )


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iterations, salt_b64, digest_b64 = stored.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), base64.b64decode(salt_b64), int(iterations)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


@lru_cache(maxsize=16)
def _factory_hash_matches(password, stored):
    return verify_password(password, stored)


@lru_cache(maxsize=1)
def _unknown_account_hash():
    return hash_password('unusable dummy credential')


class AuthService:
    def __init__(self, db: Database, factory_password: str | None = None) -> None:
        self.db = db
        self.factory_password = factory_password
        self.second_factor = None
        self._dummy_hash = _unknown_account_hash()

    def needs_password_change(self) -> bool:
        if not self.factory_password:
            return False
        with self.db.connect() as conn:
            row = conn.execute("SELECT pw_hash FROM users WHERE username = ?", (ADMIN_USER,)).fetchone()
        return bool(row) and _factory_hash_matches(self.factory_password, row['pw_hash'])

    def ensure_admin(self, initial_password: str) -> str | None:
        """Legt beim allerersten Start das Admin-Konto an.

        Bekannte Erstzugänge erfordern einen Wechsel. Bestehende Konten bleiben
        auch bei geänderter Startkonfiguration unverändert.
        """
        with self.db.connect() as conn:
            if conn.execute("SELECT 1 FROM users WHERE username = ?", (ADMIN_USER,)).fetchone():
                return None
        generated = None
        password = initial_password
        if password:
            try:
                if password != self.factory_password:check_new_password(password)
            except ValueError as exc:
                # Kein Absturz in einer Neustart-Schleife: Zufallspasswort statt dessen.
                log.error("FCG_ADMIN_PASSWORD wird nicht verwendet: %s", exc)
                password = self.factory_password or ""
        if not password:
            password = self.factory_password or ("Aa1!" + secrets.token_urlsafe(16))
            generated = None if self.factory_password else password
        self.set_password(ADMIN_USER, password)
        self.db.audit(None, "admin_created", "Erststart")
        return generated

    def set_password(self, username: str, password: str) -> None:
        with self.db.connect() as conn:
            existing = conn.execute("SELECT role FROM users WHERE username = ?", (username,)).fetchone()
        role = existing['role'] if existing else ROLE_BY_USER[username]
        pw_hash = hash_password(password)
        with self.db.transaction() as conn:
            conn.execute(
                "INSERT INTO users(username, role, pw_hash, updated_at) VALUES(?, ?, ?, ?) "
                "ON CONFLICT(username) DO UPDATE SET pw_hash = excluded.pw_hash, failed_count = 0, "
                "locked_until = 0, must_change = 0, updated_at = excluded.updated_at",
                (username, role, pw_hash, now_text()),
            )
            # Neues Passwort beendet alle offenen Sitzungen dieses Kontos.
            conn.execute("DELETE FROM sessions WHERE username = ?", (username,))

    def accounts(self) -> list[dict]:
        with self.db.connect() as conn:
            return [dict(row) for row in conn.execute(
                "SELECT username, role, enabled, must_change, updated_at FROM users ORDER BY username")]

    def must_change_password(self, username: str) -> bool:
        with self.db.connect() as conn:
            row = conn.execute("SELECT must_change FROM users WHERE username = ?", (username,)).fetchone()
        return bool(row and row[0])

    def save_account(self, username: str, role: str, password: str, enabled: bool, actor: str) -> None:
        username = username.strip().lower()
        if not re.fullmatch(r'[a-z][a-z0-9_.-]{2,31}', username) or username == LEGACY_READER_USER:
            raise ValueError("Benutzername: 3–32 Zeichen, beginnend mit einem Buchstaben; erlaubt sind a–z, 0–9, Punkt, Bindestrich und Unterstrich.")
        if role not in ('admin', 'reader'):
            raise ValueError("Unbekannte Rolle.")
        if username in ROLE_BY_USER:
            raise ValueError("Die Standardkonten werden in ihren eigenen Bereichen verwaltet.")
        if username == actor and (role != 'admin' or not enabled):
            raise ValueError("Das eigene Verwaltungskonto darf hier nicht gesperrt oder herabgestuft werden.")
        with self.db.transaction() as conn:
            previous = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if not previous and not password:
                raise ValueError("Für ein neues Konto ein Erstpasswort vergeben.")
            if password:
                check_new_password(password)
                pw_hash = hash_password(password)
            else:
                pw_hash = previous['pw_hash']
            conn.execute(
                "INSERT INTO users(username,role,pw_hash,enabled,must_change,updated_at) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(username) DO UPDATE SET role=excluded.role, pw_hash=excluded.pw_hash, "
                "enabled=excluded.enabled,must_change=excluded.must_change,updated_at=excluded.updated_at, "
                "failed_count=0,locked_until=0",
                (username, role, pw_hash, int(enabled), int(bool(password) or bool(previous and previous['must_change'])), now_text()))
            conn.execute("DELETE FROM sessions WHERE username = ?", (username,))
        self.db.audit(actor, 'account_saved', f"{username}; role={role}; enabled={int(enabled)}; password_reset={bool(password)}")

    def has_user(self, username: str) -> bool:
        with self.db.connect() as conn:
            return conn.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone() is not None

    def check_credentials(self, username: str, password: str) -> bool:
        """Prueft ohne Sperrzaehler zu verändern (z. B. aktuelles Passwort beim Wechsel)."""
        with self.db.connect() as conn:
            row = conn.execute("SELECT pw_hash FROM users WHERE username = ?", (username,)).fetchone()
        return bool(row) and verify_password(password, row["pw_hash"])

    def login(self, username: str, password: str, otp: str = "") -> Session | None:
        username = (username or "").strip().lower()
        if username == LEGACY_READER_USER:
            username = READER_USER
        now = time.time()
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if row is None or not row['enabled']:
            # Gleicher Aufwand wie bei echtem Konto, damit Konten nicht erratbar sind.
            verify_password(password, self._dummy_hash)
            self.db.audit(username or None, "login_failed", "unbekanntes Konto")
            return None
        if row["locked_until"] > now:
            raise LoginLocked(int(row["locked_until"] - now) + 1)
        password_ok = verify_password(password, row["pw_hash"])
        factor_ok = password_ok and (not self.second_factor or not self.second_factor.enabled(username)
                                     or self.second_factor.verify(username, otp))
        if not factor_ok:
            with self.db.transaction() as conn:
                current = conn.execute('SELECT failed_count,locked_until FROM users WHERE username=?',(username,)).fetchone()
                if not current:
                    return None
                if current['locked_until'] > now:
                    raise LoginLocked(int(current['locked_until']-now)+1)
                failed = current['failed_count'] + 1
                locked_until = now + LOCK_SECONDS if failed >= MAX_FAILED_LOGINS else 0
                conn.execute(
                    "UPDATE users SET failed_count = ?, locked_until = ? WHERE username = ?",
                    (0 if locked_until else failed, locked_until, username),
                )
            self.db.audit(username, "login_failed", "gesperrt" if locked_until else f"Versuch {failed}")
            return None

        session = Session(
            token=secrets.token_urlsafe(32), username=username, role=row["role"], csrf=secrets.token_urlsafe(24)
        )
        with self.db.transaction() as conn:
            current = conn.execute('SELECT pw_hash,enabled,locked_until FROM users WHERE username=?',(username,)).fetchone()
            if not current or not current['enabled'] or current['pw_hash'] != row['pw_hash'] or current['locked_until'] > now:
                return None
            conn.execute("UPDATE users SET failed_count = 0, locked_until = 0 WHERE username = ?", (username,))
            conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
            conn.execute(
                "INSERT INTO sessions(token, username, csrf, created_at, expires_at) VALUES(?, ?, ?, ?, ?)",
                (session.token, username, session.csrf, now, now + SESSION_SECONDS),
            )
        self.db.audit(username, "login", "")
        return session

    def session(self, token: str | None) -> Session | None:
        if not token:
            return None
        with self.db.connect() as conn:
            row = conn.execute(
                "SELECT s.token, s.username, s.csrf, s.expires_at, u.role, u.enabled FROM sessions s "
                "JOIN users u ON u.username = s.username WHERE s.token = ?",
                (token,),
            ).fetchone()
        if row is None or not row['enabled'] or row["expires_at"] < time.time():
            return None
        return Session(token=row["token"], username=row["username"], role=row["role"], csrf=row["csrf"])

    def logout(self, token: str) -> None:
        with self.db.connect() as conn:
            conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
