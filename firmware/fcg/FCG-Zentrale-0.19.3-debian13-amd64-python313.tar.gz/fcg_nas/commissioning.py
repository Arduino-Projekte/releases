"""Reference-pulse acceptance without resetting the operational counter."""
import json
import math
from .db import now_text
from .live import counter_configuration


def snapshot(data):
    result = {'config':counter_configuration(data)}
    if isinstance(data.get('unit'),str):
        result['config']['unit'] = data['unit'][:80]
    factor = data.get('pulses_per_unit')
    if factor is not None:
        if isinstance(factor,bool):
            raise ValueError('Das Gateway meldet einen ungültigen Impulsfaktor.')
        try:
            factor = float(factor)
        except (TypeError,ValueError):
            raise ValueError('Das Gateway meldet einen ungültigen Impulsfaktor.') from None
        if not math.isfinite(factor) or factor <= 0:
            raise ValueError('Das Gateway meldet einen ungültigen Impulsfaktor.')
        result['config']['pulses_per_unit'] = factor
    for name in ('total_impulses','pcnt_pulses','isr_accepted_pulses','raw_edges',
                 'last_persisted_impulses','pending_persist_impulses'):
        value = data.get(name)
        if isinstance(value, bool):
            continue
        try:
            number = int(value)
        except (ValueError, TypeError):
            continue
        if 0 <= number < 2**64 and str(number) == str(value):
            result[name] = number
    if 'total_impulses' not in result:
        raise ValueError('Das Gateway meldet keinen prüfbaren Impulszähler; zuerst Firmware aktualisieren.')
    return result


def begin(db, site_id, actor, expected, data):
    if not 1 <= expected <= 1000000:
        raise ValueError('Referenzimpulse: 1 bis 1.000.000 eingeben.')
    baseline = snapshot(data)
    with db.transaction() as conn:
        if conn.execute("SELECT 1 FROM commissioning_runs WHERE site_id=? AND state='running'", (site_id,)).fetchone():
            raise ValueError('Für diese Messstelle läuft bereits eine Referenzprüfung.')
        return conn.execute(
            'INSERT INTO commissioning_runs(site_id,actor,started_at,expected,baseline,state) VALUES(?,?,?,?,?,?)',
            (site_id,actor,now_text(),expected,json.dumps(baseline),'running')).lastrowid


def finish(db, run_id, data, saved=False, cancel=False):
    with db.transaction() as conn:
        row = conn.execute('SELECT * FROM commissioning_runs WHERE id=?', (run_id,)).fetchone()
        if not row or row['state'] != 'running':
            raise ValueError('Keine laufende Referenzprüfung gefunden.')
        baseline = json.loads(row['baseline'])
        final = baseline if cancel else snapshot(data)
        delta = final['total_impulses'] - baseline['total_impulses']
        stable = baseline['config'] == final['config']
        final['storage_verified'] = bool(saved)
        final['config_stable'] = stable
        matched = delta == row['expected'] and stable
        if cancel:
            state, reason = 'cancelled', 'Prüfung abgebrochen.'
        else:
            state = 'passed' if matched and saved else 'failed'
            reason = f"Referenz {row['expected']}, gezählt {delta}; Konfiguration {'unverändert' if stable else 'geändert'}; Speicherung {'geprüft' if saved else 'nicht bestätigt'}."
        conn.execute('UPDATE commissioning_runs SET finished_at=?,final=?,state=?,result=? WHERE id=?',
                     (now_text(),json.dumps(final),state,reason,run_id))
    return state


def runs(db, site_id):
    with db.connect() as conn:
        result = [dict(row) for row in conn.execute('SELECT * FROM commissioning_runs WHERE site_id=? ORDER BY id DESC LIMIT 50',(site_id,))]
    for row in result:
        before = json.loads(row['baseline'])
        after = json.loads(row['final']) if row['final'] else {}
        row['deltas'] = {key: after[key]-before[key] for key in ('total_impulses','raw_edges','pcnt_pulses','isr_accepted_pulses')
                         if key in before and key in after}
        row['config'] = before['config']
        row['storage_verified'] = after.get('storage_verified',False)
        row['config_stable'] = after.get('config_stable',False)
    return result
