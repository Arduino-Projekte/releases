"""Portable, streaming password envelopes for ordinary FCG ZIP backups.

The inner ZIP is unchanged across VM and Docker. Authenticate the entire file
before exposing decrypted content to the ZIP parser. Passwords are never saved.
"""
import os
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b'FCG-BACKUP-ENC1\n'
HEADER_SIZE = len(MAGIC) + 16 + 12
CHUNK = 1024 * 1024


def _key(password: str, salt: bytes) -> bytes:
    if not password or len(password) > 1024:
        raise ValueError('Sicherungspasswort fehlt oder ist zu lang.')
    return Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(password.encode('utf-8'))


def encrypted(path: Path) -> bool:
    with path.open('rb') as handle:
        return handle.read(len(MAGIC)) == MAGIC


def encrypt(source: Path, target: Path, password: str) -> None:
    salt, nonce = os.urandom(16), os.urandom(12)
    header = MAGIC + salt + nonce
    cipher = Cipher(algorithms.AES(_key(password, salt)), modes.GCM(nonce)).encryptor()
    cipher.authenticate_additional_data(header)
    try:
        with source.open('rb') as incoming, target.open('xb') as outgoing:
            os.chmod(target, 0o600)
            outgoing.write(header)
            while chunk := incoming.read(CHUNK):
                outgoing.write(cipher.update(chunk))
            outgoing.write(cipher.finalize())
            outgoing.write(cipher.tag)
    except BaseException:
        target.unlink(missing_ok=True)
        raise


def decrypt(source: Path, target: Path, password: str, limit: int) -> None:
    size = source.stat().st_size
    if size < HEADER_SIZE + 16 or size > limit + HEADER_SIZE + 16:
        raise ValueError('Die verschlüsselte Sicherung hat eine ungültige Größe.')
    try:
        with source.open('rb') as incoming, target.open('xb') as outgoing:
            os.chmod(target, 0o600)
            header = incoming.read(HEADER_SIZE)
            if not header.startswith(MAGIC):
                raise ValueError('Unbekanntes Sicherungsformat.')
            incoming.seek(-16, os.SEEK_END)
            tag = incoming.read(16)
            incoming.seek(HEADER_SIZE)
            salt, nonce = header[len(MAGIC):len(MAGIC) + 16], header[-12:]
            cipher = Cipher(algorithms.AES(_key(password, salt)), modes.GCM(nonce, tag)).decryptor()
            cipher.authenticate_additional_data(header)
            remaining = size - HEADER_SIZE - 16
            while remaining:
                chunk = incoming.read(min(CHUNK, remaining))
                if not chunk:
                    raise ValueError('Die Sicherung ist unvollständig.')
                remaining -= len(chunk)
                outgoing.write(cipher.update(chunk))
            outgoing.write(cipher.finalize())
    except InvalidTag as exc:
        target.unlink(missing_ok=True)
        raise ValueError('Sicherungspasswort falsch oder Datei beschädigt.') from exc
    except BaseException:
        target.unlink(missing_ok=True)
        raise
