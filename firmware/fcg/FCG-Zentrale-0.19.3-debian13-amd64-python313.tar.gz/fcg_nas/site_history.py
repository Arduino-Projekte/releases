"""Allowlisted observations of configuration; never raw API bodies or credentials."""
import json
from .db import now_text


def record(conn, site_id, actor, snapshot):
    encoded = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, allow_nan=False)
    previous = conn.execute(
        'SELECT snapshot FROM site_config_history WHERE site_id=? AND actor=? ORDER BY id DESC LIMIT 1',
        (site_id, actor)).fetchone()
    if previous and previous[0] == encoded:
        return
    boundary = conn.execute('SELECT MAX(seq) FROM entries WHERE site_id=?', (site_id,)).fetchone()[0]
    conn.execute('INSERT INTO site_config_history(site_id,observed_at,actor,snapshot,after_seq) VALUES(?,?,?,?,?)',
                 (site_id, now_text(), actor, encoded, boundary))


FIELD_LABELS = {
    'counter_name':'Zählername', 'device_label':'Gerät', 'location':'Standort', 'unit':'Einheit',
    'firmware':'Firmware', 'mac':'MAC-Adresse', 'serial':'Gerätekennung',
    'path':'Aktive Zählart', 'count_path_setting':'Eingestellte Zählart', 'edge_mode':'Zählflanke',
    'pcnt_active':'PCNT aktiv', 'pcnt_running':'Hardwarezähler läuft', 'input':'Zähleingang',
    'pcnt_glitch_filter_ns':'Hardware-Störfilter (ns)', 'debounce_ms':'Entprellzeit (ms)',
    'min_pulse_gap_ms':'Mindestimpulsabstand (ms)', 'effective_gap_ms':'Wirksamer Mindestabstand (ms)',
    'save_interval_sec':'Sicherungsintervall (s)', 'save_pulse_delta':'Sicherung nach Impulsen',
    'counter_block_end_timeout_sec':'Blockende nach Ruhe (s)', 'pulses_per_unit':'Impulse pro Einheit',
}


def observations(db, site_id, display=False):
    with db.connect() as conn:
        return [{**dict(row), 'values': {(FIELD_LABELS.get(key,key) if display else key):value for key,value in json.loads(row['snapshot']).items()}} for row in conn.execute(
            'SELECT * FROM site_config_history WHERE site_id=? ORDER BY id DESC LIMIT 100', (site_id,))]
