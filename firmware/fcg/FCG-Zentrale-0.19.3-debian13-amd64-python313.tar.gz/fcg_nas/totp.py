"""Optional offline TOTP with one-time recovery codes and replay prevention."""
import base64
import hashlib
import hmac
import json
import secrets
import struct
import time


def code(secret, step):
    key = base64.b32decode(secret)
    digest = hmac.new(key, struct.pack('>Q', step), hashlib.sha1).digest()
    offset = digest[-1] & 15
    return f'{(int.from_bytes(digest[offset:offset+4], "big") & 0x7fffffff) % 1000000:06d}'


class TotpService:
    def __init__(self, db, store):
        self.db, self.store = db, store

    def enabled(self, username):
        with self.db.connect() as conn:
            row = conn.execute('SELECT enabled FROM account_totp WHERE username=?', (username,)).fetchone()
        return bool(row and row[0])

    def begin(self, username):
        secret = base64.b32encode(secrets.token_bytes(20)).decode('ascii')
        with self.db.transaction() as conn:
            if self.enabled(username):
                raise ValueError('Zweiter Faktor ist bereits aktiv.')
            conn.execute('INSERT INTO account_totp(username,secret_enc,enabled,last_step,recovery) VALUES(?,?,0,-1,?) '
                         'ON CONFLICT(username) DO UPDATE SET secret_enc=excluded.secret_enc,last_step=-1,recovery=excluded.recovery',
                         (username,self.store.encrypt(secret),'[]'))
        return secret

    def _step(self, secret, token, last_step):
        if len(token) != 6 or not token.isascii() or not token.isdigit():
            return None
        current = int(time.time()) // 30
        for step in (current, current-1, current+1):
            if step > last_step and step >= 0 and hmac.compare_digest(code(secret, step), token):
                return step
        return None

    def confirm(self, username, token):
        recovery = [secrets.token_hex(10) for _ in range(8)]
        with self.db.transaction() as conn:
            row = conn.execute('SELECT * FROM account_totp WHERE username=?',(username,)).fetchone()
            if not row or row['enabled']:
                raise ValueError('Zuerst den zweiten Faktor vorbereiten.')
            step = self._step(self.store.decrypt(row['secret_enc']),token.strip(),-1)
            if step is None:
                raise ValueError('Prüfcode falsch. Systemzeit und Authenticator prüfen.')
            hashed = [hashlib.sha256(value.encode('ascii')).hexdigest() for value in recovery]
            conn.execute('UPDATE account_totp SET enabled=1,last_step=?,recovery=? WHERE username=?',
                         (step,json.dumps(hashed),username))
            conn.execute('DELETE FROM sessions WHERE username=?',(username,))
        return recovery

    def verify(self, username, token):
        token = token.strip()
        with self.db.transaction() as conn:
            row = conn.execute('SELECT * FROM account_totp WHERE username=?',(username,)).fetchone()
            if not row or not row['enabled']:
                return False
            step = self._step(self.store.decrypt(row['secret_enc']),token,row['last_step'])
            if step is not None:
                conn.execute('UPDATE account_totp SET last_step=? WHERE username=?',(step,username))
                return True
            recovery = json.loads(row['recovery'])
            hashed = hashlib.sha256(token.encode('utf-8')).hexdigest()
            found = next((value for value in recovery if hmac.compare_digest(value,hashed)),None)
            if found:
                recovery.remove(found)
                conn.execute('UPDATE account_totp SET recovery=? WHERE username=?',(json.dumps(recovery),username))
                return True
        return False

    def regenerate(self, username, token):
        if not self.verify(username,token):
            raise ValueError('Prüfcode oder Wiederherstellungscode falsch oder bereits verwendet.')
        codes = [secrets.token_hex(10) for _ in range(8)]
        hashed = [hashlib.sha256(value.encode('ascii')).hexdigest() for value in codes]
        with self.db.transaction() as conn:
            conn.execute('UPDATE account_totp SET recovery=? WHERE username=?',(json.dumps(hashed),username))
            conn.execute('DELETE FROM sessions WHERE username=?',(username,))
        return codes

    def disable(self, username, token):
        if not self.verify(username,token):
            raise ValueError('Prüfcode oder Wiederherstellungscode falsch oder bereits verwendet.')
        with self.db.transaction() as conn:
            conn.execute('DELETE FROM account_totp WHERE username=?',(username,))
            conn.execute('DELETE FROM sessions WHERE username=?',(username,))
