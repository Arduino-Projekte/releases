"""Filesystem accounting and conservative space reservations for portable deployments."""
import os
from pathlib import Path
import shutil


def bytes_used(path: Path) -> int:
    if path.is_symlink():
        return 0
    if path.is_file():
        return path.stat().st_size
    total = 0
    for directory, folders, files in os.walk(path, followlinks=False):
        folders[:] = [name for name in folders if not (Path(directory)/name).is_symlink()]
        for name in files:
            file = Path(directory)/name
            if not file.is_symlink():
                try:
                    total += file.stat().st_size
                except FileNotFoundError:
                    pass
    return total


def require_space(path: Path, needed: int, reserve: int = 1024**3) -> None:
    anchor = Path(path)
    while not anchor.exists():
        anchor = anchor.parent
    free = shutil.disk_usage(anchor).free
    if free < needed + reserve:
        raise ValueError(f'Nicht genug Speicherplatz: {free // 1024**2} MB frei, '
                         f'{needed // 1024**2} MB Arbeitsbereich plus {reserve // 1024**2} MB Reserve benötigt.')


def report(config):
    capacity = shutil.disk_usage(config.data_dir)
    paths = [('Datenbank', config.db_path), ('Sicherungen', config.backups_dir),
             ('Offline-Pakete', config.data_dir/'offline_updates/cache'),
             ('Firmwarecache', config.ota_cache_dir), ('Firmwareausgabe', config.ota_dir),
             ('Exporte', config.export_dir), ('Import-Vorschau', config.import_dir)]
    return {'free': capacity.free, 'total': capacity.total,
            'areas': [{'label': label, 'bytes': bytes_used(path)} for label, path in paths]}
