"""Move verified firmware between explicitly mapped OTA directories."""
import hashlib
import json
import os
from pathlib import Path
import tempfile

from .ota import LEGACY_BIN, MAX_FIRMWARE_BYTES, MAX_MANIFEST_BYTES, parse_manifest, version_key


class MirrorMigration:
    def __init__(self, trusted):
        self.trusted = trusted

    def folders(self, old_url, new_url):
        try:
            mapping = json.loads(os.environ.get('FCG_OTA_MIRROR_DIRS', '{}'))
            paths = [Path(mapping[url]) for url in (old_url, new_url)]
            if not all(path.is_absolute() and path.is_dir() for path in paths):
                raise ValueError()
            return tuple(path.resolve() for path in paths)
        except (ValueError, TypeError, KeyError, OSError):
            raise ValueError('Für die Übernahme müssen beide Updateadressen einem erreichbaren Ordner zugeordnet sein.') from None

    @staticmethod
    def digest(path, limit):
        if path.is_symlink() or not path.is_file():
            raise ValueError('Datei im Updateordner fehlt oder ist ein Verweis.')
        with path.open('rb') as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError('Datei im Updateordner ist zu groß.')
        return hashlib.sha256(data).hexdigest(), data

    def snapshot(self, folder):
        manifest_hash, raw = self.digest(folder / 'update.json', MAX_MANIFEST_BYTES)
        manifest = parse_manifest(raw, self.trusted)
        binary_hash, _ = self.digest(folder / manifest['file'], MAX_FIRMWARE_BYTES)
        if binary_hash != manifest['sha256']:
            raise ValueError('Firmware und Manifest im Updateordner stimmen nicht überein.')
        files = {manifest['file']: binary_hash, 'update.json': manifest_hash}
        legacy = folder / LEGACY_BIN
        if legacy.is_file() and not legacy.is_symlink() and legacy.stat().st_size <= MAX_FIRMWARE_BYTES:
            legacy_hash, _ = self.digest(legacy, MAX_FIRMWARE_BYTES)
            if legacy_hash == binary_hash:
                files[LEGACY_BIN] = legacy_hash
        return manifest['version'], files

    def offer(self, old_url, new_url):
        old, new = self.folders(old_url, new_url)
        if old == new or not (old / 'update.json').exists():
            return None
        version, files = self.snapshot(old)
        if (new / 'update.json').exists():
            current, _ = self.snapshot(new)
            if version_key(version) <= version_key(current):
                return None
        return {'old': old_url, 'new': new_url, 'version': version, 'files': files, 'phase': 'copy'}

    def copy(self, state):
        old, new = self.folders(state['old'], state['new'])
        if self.offer(state['old'], state['new']) != state:
            raise ValueError('Firmware oder Zielordner hat sich geändert. Updateadresse erneut prüfen.')
        # Stage all files before publishing the manifest. Its versioned image is immutable.
        with tempfile.TemporaryDirectory(prefix='.fcg-transfer-', dir=new) as temporary:
            stage = Path(temporary)
            for name, digest in state['files'].items():
                source = old / name
                limit = MAX_MANIFEST_BYTES if name == 'update.json' else MAX_FIRMWARE_BYTES
                actual, data = self.digest(source, limit)
                if actual != digest:
                    raise ValueError('Datei wurde seit der Prüfung geändert.')
                (stage / name).write_bytes(data)
                target = new / name
                if name not in ('update.json', LEGACY_BIN) and (target.exists() or target.is_symlink()):
                    if self.digest(target, limit)[0] != digest:
                        raise ValueError('Die gleichnamige Zieldatei hat einen anderen Inhalt.')
            for name in (*[f for f in state['files'] if f != 'update.json'], 'update.json'):
                os.replace(stage / name, new / name)

    def clean(self, state):
        old, new = self.folders(state['old'], state['new'])
        if old == new or self.snapshot(old) != (state['version'], state['files']):
            raise ValueError('Der alte Ordner hat sich geändert. Bereinigung abgebrochen.')
        version, files = self.snapshot(new)
        if version != state['version'] or any(files.get(name) != digest for name, digest in state['files'].items()):
            raise ValueError('Die übernommene Firmware fehlt am Ziel. Bereinigung abgebrochen.')
        for name in ('update.json', *[f for f in state['files'] if f != 'update.json']):
            (old / name).unlink()
