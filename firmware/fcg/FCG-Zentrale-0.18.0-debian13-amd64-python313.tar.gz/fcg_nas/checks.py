"""Zählerprüfung: passt die Historie einer Messstelle zu sich selbst?

Zwei Prüfungen über aufeinanderfolgende Einträge (nach Seq):
- Lücke: zwischen zwei Einträgen fehlen Seq-Nummern. Diese Einträge hat die
  Zentrale nie erhalten, z. B. weil der NVS-Ring des Gateways übergelaufen ist.
- Abweichung: der Zählerstand ist um etwas anderes gestiegen als der vom
  Gateway gemeldete Verbrauch. Mit Verbrauch 0 ist es ein bewusst gesetzter
  Zählerstand (Korrektur am Gateway), sonst ein echter Widerspruch.

Dazu kommen die vom Collector erkannten Neubeginne (site_restarts).
Rundung: Zählerstand und Verbrauch kommen auf mindestens 2 Nachkommastellen
gerundet. Je Eintrag sind das höchstens 0,015; erst darüber wird gemeldet.

Der Abgleich je Messstelle zerlegt die Zählerstand-Differenz vom ersten zum
letzten Eintrag vollständig in Verbrauch und die Ursachen oben. Der Rest
"ungeklärt" ist dann die Summe der echten Widersprüche.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from .alerts import Problem
from .db import Database

TOLERANCE = 0.02
ALERT_DAYS = 30
CONSUMPTION_SOURCES = ("api", "import", "legacy_delta")

KIND_TEXT = {
    "gap": "Lücke in der Seq-Folge",
    "mismatch": "Verbrauch passt nicht zum Zählerstand",
    "set": "Zählerstand gesetzt (ohne Verbrauch)",
    "restart": "Neubeginn der Zählung am Gateway",
    "unknown": "Verbrauch unbekannt",
}


@dataclass
class Finding:
    kind: str           # gap | mismatch | set | restart | unknown
    site_id: str
    seq: int
    prev_seq: int
    ts: str
    prev_ts: str
    total: float
    prev_total: float
    consumed: float | None
    collected_at: str
    detail: str = ""

    @property
    def delta(self) -> float:
        return self.total - self.prev_total

    @property
    def missing(self) -> int:
        return max(0, self.seq - self.prev_seq - 1)

    @property
    def unexplained(self) -> float:
        """Zählerstand-Differenz, die der gemeldete Verbrauch nicht erklärt."""
        return self.delta - (self.consumed or 0.0)

    @property
    def text(self) -> str:
        return KIND_TEXT[self.kind]


@dataclass
class Reconciliation:
    """Zählerstand-Differenz einer Messstelle, zerlegt nach Ursache."""

    site_id: str
    first_seq: int | None = None
    last_seq: int | None = None
    first_total: float = 0.0
    last_total: float = 0.0
    entries: int = 0
    consumed: float = 0.0
    parts: dict[str, float] = field(default_factory=lambda: {k: 0.0 for k in ("gap", "set", "restart", "unknown", "mismatch")})
    rounding: float = 0.0
    counts: dict[str, int] = field(default_factory=lambda: {k: 0 for k in ("gap", "set", "restart", "unknown", "mismatch")})
    missing: int = 0

    @property
    def difference(self) -> float:
        return self.last_total - self.first_total

    @property
    def ok(self) -> bool:
        return self.counts["gap"] == 0 and self.counts["mismatch"] == 0 and self.counts["restart"] == 0


def _restarts(conn, site: str) -> dict[tuple[str, int], dict]:
    return {(r["site_id"], int(r["first_seq"])): dict(r) for r in conn.execute(
        "SELECT * FROM site_restarts WHERE (? = '' OR site_id = ?)", (site, site))}


def classify(row: dict, prev: dict, restart: dict | None) -> str | None:
    """Art des Befunds zwischen prev und row, None = in Ordnung."""
    if restart is not None:
        return "restart"
    if int(row["seq"]) - int(prev["seq"]) > 1:
        return "gap"
    consumed = row["consumed_quantity"]
    if consumed is None or row["consumption_source"] not in CONSUMPTION_SOURCES:
        return "unknown"
    rest = (row["total_quantity"] - prev["total_quantity"]) - consumed
    if abs(rest) <= TOLERANCE:
        return None
    return "set" if abs(consumed) <= TOLERANCE else "mismatch"


def _finding(kind: str, row: dict, prev: dict, restart: dict | None) -> Finding:
    detail = ""
    if restart is not None:
        detail = (f"Gateway-Seq {restart['old_gateway_seq']} → {restart['new_gateway_seq']}, "
                  f"erkannt {restart['detected_at']}. {restart['reason']}")
    return Finding(kind=kind, site_id=row["site_id"], seq=int(row["seq"]), prev_seq=int(prev["seq"]),
                   ts=row["ts"] or "", prev_ts=prev["ts"] or "", total=float(row["total_quantity"]),
                   prev_total=float(prev["total_quantity"]), consumed=row["consumed_quantity"],
                   collected_at=row["collected_at"] or "", detail=detail)


def _pairs(conn, site: str, since: str | None):
    """Aufeinanderfolgende Einträge (row, prev); mit since nur die zuletzt übernommenen."""
    sql = """
        SELECT * FROM (
          SELECT site_id, seq, ts, total_quantity, consumed_quantity, consumption_source, collected_at,
            LAG(seq) OVER w AS p_seq, LAG(ts) OVER w AS p_ts, LAG(total_quantity) OVER w AS p_total
          FROM entries WHERE (? = '' OR site_id = ?)
          WINDOW w AS (PARTITION BY site_id ORDER BY seq))
        WHERE p_seq IS NOT NULL"""
    params: list = [site, site]
    if since is not None:
        sql += " AND collected_at >= ?"
        params.append(since)
    for r in conn.execute(sql + " ORDER BY site_id, seq", params):
        row = dict(r)
        yield row, {"seq": row["p_seq"], "ts": row["p_ts"], "total_quantity": row["p_total"]}


def findings(db: Database, site: str = "", since: str | None = None,
             kinds: tuple[str, ...] = ("gap", "mismatch", "set", "restart")) -> list[Finding]:
    result = []
    with db.connect() as conn:
        restarts = _restarts(conn, site)
        for row, prev in _pairs(conn, site, since):
            restart = restarts.get((row["site_id"], int(row["seq"])))
            kind = classify(row, prev, restart)
            if kind in kinds:
                result.append(_finding(kind, row, prev, restart))
    return result


def reconcile(db: Database, site: str = "") -> dict[str, Reconciliation]:
    """Abgleich Summe Verbrauch gegen Zählerstand-Differenz je Messstelle."""
    result: dict[str, Reconciliation] = {}
    with db.connect() as conn:
        restarts = _restarts(conn, site)
        for r in conn.execute("SELECT site_id, MIN(seq) AS a, MAX(seq) AS b, COUNT(*) AS n FROM entries "
                              "WHERE (? = '' OR site_id = ?) GROUP BY site_id", (site, site)):
            rec = Reconciliation(r["site_id"], first_seq=r["a"], last_seq=r["b"], entries=r["n"])
            ends = {e["seq"]: e["total_quantity"] for e in conn.execute(
                "SELECT seq, total_quantity FROM entries WHERE site_id = ? AND seq IN (?, ?)", (r["site_id"], r["a"], r["b"]))}
            rec.first_total, rec.last_total = ends[r["a"]], ends[r["b"]]
            result[r["site_id"]] = rec
        for row, prev in _pairs(conn, site, None):
            rec = result[row["site_id"]]
            restart = restarts.get((row["site_id"], int(row["seq"])))
            kind = classify(row, prev, restart)
            delta = row["total_quantity"] - prev["total_quantity"]
            consumed = row["consumed_quantity"] if kind != "unknown" else None
            if consumed is not None:
                rec.consumed += consumed
            if kind is None:
                rec.rounding += delta - consumed
                continue
            rec.counts[kind] += 1
            rec.parts[kind] += delta - (consumed or 0.0)
            if kind == "gap":
                rec.missing += int(row["seq"]) - int(prev["seq"]) - 1
    return result


def _count(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def _amount(value: float, unit: str) -> str:
    return f"{value:.2f}".replace(".", ",") + (f" {unit}" if unit else "")


def check_problems(db: Database, now: datetime | None = None) -> dict[str, Problem]:
    """Warnung je Messstelle für Befunde der letzten 30 Tage (nach Übernahme in die Zentrale).

    Gesetzte Zählerstände sind gewollte Korrekturen und warnen nicht; sie
    stehen nur auf der Seite Datenprüfung. Die Quittierung gilt, bis ein neuer
    Befund dazukommt.
    """
    now = now or datetime.now()
    since = (now - timedelta(days=ALERT_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
    found = findings(db, since=since, kinds=("gap", "mismatch", "restart"))
    if not found:
        return {}
    with db.connect() as conn:
        sites = {r["site_id"]: dict(r) for r in conn.execute(
            "SELECT s.site_id, s.counter_name, s.unit, g.label, g.host FROM sites s "
            "LEFT JOIN gateways g ON g.id = s.gateway_id")}
    by_site: dict[str, list[Finding]] = {}
    for item in found:
        by_site.setdefault(item.site_id, []).append(item)
    problems: dict[str, Problem] = {}
    for site_id, items in by_site.items():
        site = sites.get(site_id, {})
        unit = site.get("unit") or ""
        title = site.get("label") or site.get("counter_name") or site_id
        head = f"{title} ({site['host']})" if site.get("host") else title
        parts = []
        gaps = [i for i in items if i.kind == "gap"]
        if gaps:
            missing = sum(i.missing for i in gaps)
            parts.append(f"{_count(missing, 'Eintrag fehlt', 'Einträge fehlen')} in der Seq-Folge "
                         f"({_count(len(gaps), 'Lücke', 'Lücken')}), der Zählerstand stieg dort um "
                         f"{_amount(sum(i.unexplained for i in gaps), unit)} mehr als der gemeldete Verbrauch")
        mismatches = [i for i in items if i.kind == "mismatch"]
        if mismatches:
            parts.append(f"bei {_count(len(mismatches), 'Eintrag', 'Einträgen')} passt der Verbrauch nicht zur "
                         f"Zählerstand-Differenz (zusammen {_amount(sum(i.unexplained for i in mismatches), unit)})")
        restarts = [i for i in items if i.kind == "restart"]
        if restarts:
            parts.append(f"Gateway hat die Zählung neu begonnen (ab Seq {restarts[-1].seq}), die Zentrale zählt weiter")
        key = f"counting:{site_id}"
        text = "; ".join(parts)
        problems[key] = Problem(key, "warn", f"{head}: {text[0].upper()}{text[1:]}.",
                                fingerprint=str(max(i.seq for i in items)))
    return problems
