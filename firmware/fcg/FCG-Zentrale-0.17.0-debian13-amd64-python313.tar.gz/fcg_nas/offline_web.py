"""Admin UI for SMB sources, offline approvals and host-worker requests."""
import ipaddress
from urllib.parse import urlsplit

from fastapi import Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from .offline_updates import OfflineUpdates
from .gateway_client import GatewayAuth
from . import ota as ota_mod
from .docker_queue import status as docker_status
from .vm_queue import status as vm_status

NOTICES={'source_saved':'SMB-Updatefreigabe gespeichert.', 'source_deleted':'Updatefreigabe entfernt. Bereits eingelesene Pakete bleiben erhalten.',
         'credentials_cleared':'SMB-Zugangsdaten gelöscht und Updatefreigabe deaktiviert.',
         'scanning':'Paketprüfung gestartet.', 'approved':'Firmware freigegeben. Sie ist jetzt über den lokalen Updatepfad erreichbar.',
         'distributing':'Firmware freigegeben und Gateway-Verteilung gestartet.',
         'queued':'Zentralenupdate angefordert. Fortschritt und installierte Version nach dem Neustart prüfen.',
         'mirror_saved':'Lokale Gateway-Updateadresse gespeichert.'}


def mirror_url(value):
    value=value.strip()
    try:
        u=urlsplit(value)
        if (len(value)>500 or u.scheme!='http' or not u.hostname or u.username or u.password or u.query or u.fragment
                or not u.path.endswith('/update.json') or u.hostname.lower()=='localhost'):
            raise ValueError()
        _=u.port
        try:
            address=ipaddress.ip_address(u.hostname)
            if address.is_loopback or address.is_unspecified:raise ValueError('unreachable')
        except ValueError as exc:
            if str(exc)=='unreachable':raise
    except ValueError:
        raise ValueError('Eine von den Gateways erreichbare HTTP-Adresse zum lokalen update.json angeben, ohne Zugangsdaten oder Abfrageparameter.') from None
    return value


def add_routes(app, config, db, secrets, ota, updater, current, check_csrf, render):
    service=OfflineUpdates(db,secrets,config.data_dir,ota,config.deployment)

    def redirect(notice):return RedirectResponse('/admin/offline-updates?notice='+notice,status_code=303)

    def page(request,session,message=None,status=200):
        with db.connect() as conn:
            gateways=[dict(row) for row in conn.execute('SELECT * FROM gateways WHERE enabled=1 ORDER BY lower(label),host')]
        values=db.get_settings()
        worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
        worker['text']={'queued':'Installation angefordert','preparing':'Update wird vorbereitet','installed':'Installiert','failed':'Installation fehlgeschlagen','rolled_back':'Vorheriger Stand wiederhergestellt'}.get(worker.get('state'),'')
        packages=service.packages()
        for row in packages:
            if row['state']=='queued' and (worker.get('version')==row['version']):
                state=worker.get('state')
                if state in ('installed','failed','rolled_back'):
                    service.decide(row['id'],state,row['decided_by'] or 'admin')
                    row['state']=state
                    from .offline_updates import STATES
                    row['state_text']=STATES[state]
        if message is None and request.query_params.get('notice') in NOTICES:
            message=('ok',NOTICES[request.query_params['notice']])
        return render(request,'offline_updates.html',session,status_code=status,message=message,nav='ota',
            sources=service.sources(),packages=packages,job=service.job(),gateways=gateways,
            values=values,deployment=config.deployment,worker=worker,steps=updater.steps(),
            update_running=updater.running,gateway_admin_saved=bool(values.get('gw_admin_user') and values.get('gw_admin_password_enc')))

    @app.get('/admin/offline-updates')
    def overview(request: Request):return page(request,current(request,admin=True))

    @app.post('/admin/offline-updates/sources/save')
    def source_save(request: Request, csrf: str=Form(''), source_id: int=Form(0), name: str=Form(''),
                    server: str=Form(''), share: str=Form(''), subdir: str=Form(''), username: str=Form(''),
                    password: str=Form(''), encrypt: str=Form(''), enabled: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            source_id=service.save_source(source_id,dict(name=name,server=server,share=share,subdir=subdir,username=username,encrypt=encrypt=='1',enabled=enabled=='1'),password)
        except (ValueError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,ValueError) else 'Updatefreigabe konnte nicht gespeichert werden.'),400)
        db.audit(session.username,'offline_source_saved',str(source_id))
        return redirect('source_saved')

    @app.post('/admin/offline-updates/sources/{source_id}/action')
    def source_action(request: Request,source_id: int,csrf: str=Form(''),action: str=Form(''),confirm: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if action=='test':return page(request,session,('ok',service.test(source_id)))
            if confirm!='1':raise ValueError('Löschen zuerst mit dem Haken bestätigen.')
            if action=='delete':service.delete_source(source_id);notice='source_deleted'
            elif action=='clear':service.clear_credentials(source_id);notice='credentials_cleared'
            else:raise ValueError('Unbekannte Freigabeaktion.')
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_source_'+action,str(source_id))
        return redirect(notice)

    @app.post('/admin/offline-updates/mode')
    def mode(request: Request,csrf: str=Form(''),mode: str=Form('online')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
            if worker.get('state') in ('queued','preparing') or worker.get('pending'):
                raise ValueError('Updatebetrieb erst nach dem laufenden Zentralenupdate ändern.')
            service.set_mode(mode)
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_mode_saved',mode)
        return page(request,session,('ok','Updatebetrieb gespeichert.'))

    @app.post('/admin/offline-updates/scan')
    def scan(request: Request,csrf: str=Form(''),source_id: int=Form(0)):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if source_id:service.source(source_id)
            service.start_scan(source_id or None)
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.audit(session.username,'offline_scan_requested',str(source_id))
        return redirect('scanning')

    @app.post('/admin/offline-updates/mirror')
    def save_mirror(request: Request,csrf: str=Form(''),url: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:clean=mirror_url(url)
        except ValueError as exc:return page(request,session,('err',str(exc)),400)
        db.set_settings({'offline_mirror_url':clean})
        db.audit(session.username,'offline_mirror_saved','')
        return redirect('mirror_saved')

    @app.post('/admin/offline-updates/packages/{package_id}/approve')
    def approve(request: Request,package_id: str,csrf: str=Form(''),action: str=Form('approve'),confirm: str=Form(''),
                targets: list[str]=Form(default=[]),username: str=Form(''),password: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if confirm!='1':raise ValueError('Freigabe zuerst mit dem Haken bestätigen.')
            if action not in ('approve','distribute'):raise ValueError('Unbekannte Freigabeaktion.')
            gateways=[];auth=None;url=''
            if action=='distribute':
                values=db.get_settings();url=mirror_url(values.get('offline_mirror_url',''))
                if not username and not password and values.get('gw_admin_user') and values.get('gw_admin_password_enc'):
                    username,password=values['gw_admin_user'],secrets.decrypt(values['gw_admin_password_enc'])
                if not username.strip() or not password:raise ValueError('Gateway-Admin-Zugangsdaten eingeben oder unter Konten speichern.')
                auth=GatewayAuth(username.strip()[:64],password[:128])
                with db.connect() as conn:
                    enabled=[dict(row) for row in conn.execute('SELECT * FROM gateways WHERE enabled=1')]
                gateways=enabled if 'all' in targets else [g for g in enabled if str(g['id']) in targets]
                if not gateways:raise ValueError('Mindestens ein aktiviertes Gateway auswählen.')
            # Publication is pinned for the entire batch; another approval waits.
            with ota._lock:
                if updater.running:raise ValueError('Eine Gateway-Verteilung läuft bereits.')
                row=service.approve_gateway(package_id,session.username)
                if action=='distribute' and not updater.start(gateways,auth,session.username,row['version'],manifest_url=url):
                    raise ValueError('Verteilung konnte nicht gestartet werden. Firmware ist freigegeben; erneut verteilen.')
        except (ValueError,ota_mod.OtaError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,(ValueError,ota_mod.OtaError)) else 'Firmware konnte nicht bereitgestellt werden.'),400)
        db.audit(session.username,'offline_gateway_'+action,package_id)
        return redirect('distributing' if action=='distribute' else 'approved')

    @app.post('/admin/offline-updates/packages/{package_id}/install')
    def install(request: Request,package_id: str,csrf: str=Form(''),confirm: str=Form('')):
        session=current(request,admin=True);check_csrf(session,csrf)
        try:
            if confirm!='1':raise ValueError('Zentralenupdate und kurzen Neustart zuerst bestätigen.')
            worker=vm_status() if config.deployment=='vm' else docker_status(service.root)
            if worker.get('state') in ('queued','preparing') or worker.get('pending'):
                raise ValueError('Ein Zentralenupdate läuft oder wartet bereits.')
            if updater.running or service._running:raise ValueError('Zentralenupdate erst nach Paketprüfung und Gateway-Verteilung starten.')
            service.install(package_id,session.username)
        except (ValueError,OSError) as exc:
            return page(request,session,('err',str(exc) if isinstance(exc,ValueError) else 'Updatedienst ist nicht erreichbar. Einrichtung prüfen.'),400)
        db.audit(session.username,'offline_central_install_requested',package_id)
        return redirect('queued')

    return service
