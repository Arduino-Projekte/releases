// Ansicht Tag, Nacht oder Auto (nach Systemeinstellung). Wird im Browser gemerkt.
// Absichtlich ohne defer im <head> geladen, damit die Seite nicht erst hell aufblitzt.
(function () {
  var KEY = 'fcg-theme';
  var ORDER = ['auto', 'light', 'dark'];
  function tr(text) { return (window.FCG_I18N || {})[text] || text; }
  var TEXT = {auto:tr('◐ Auto'),light:tr('☀ Tag'),dark:tr('☾ Nacht')};

  function read() {
    try { return localStorage.getItem(KEY) || 'auto'; } catch (e) { return 'auto'; }
  }

  function apply(mode) {
    if (mode === 'dark' || mode === 'light') document.documentElement.setAttribute('data-theme', mode);
    else document.documentElement.removeAttribute('data-theme');
    var button = document.querySelector('[data-theme-toggle]');
    if (button) button.textContent = TEXT[mode] || TEXT.auto;
  }

  apply(read());
  document.addEventListener('DOMContentLoaded', function () {
    var button = document.querySelector('[data-theme-toggle]');
    if (!button) return;
    apply(read());
    button.addEventListener('click', function () {
      var next = ORDER[(ORDER.indexOf(read()) + 1) % ORDER.length];
      try { localStorage.setItem(KEY, next); } catch (e) { /* ohne Speicher gilt es nur für diese Seite */ }
      apply(next);
    });
  });
})();
