// Passwords stay in the form. This indicator never sends or stores their value.
(function () {
  function tr(text) { return (window.FCG_I18N || {})[text] || text; }
  var rule = 'Mindestens 8 Zeichen mit Großbuchstabe, Kleinbuchstabe, Zahl und Sonderzeichen.';
  document.querySelectorAll('[data-password-new]').forEach(function (input, index) {
    var meter = document.createElement('div');
    meter.className = 'password-strength'; meter.id = 'password-strength-' + index;
    meter.setAttribute('role', 'status'); meter.setAttribute('aria-live', 'polite');
    var lamps = document.createElement('span'); lamps.className = 'password-lamps'; lamps.setAttribute('aria-hidden', 'true');
    ['red', 'yellow', 'green'].forEach(function (color) {
      var lamp = document.createElement('span'); lamp.className = 'password-lamp ' + color; lamps.appendChild(lamp);
    });
    var message = document.createElement('span'); meter.appendChild(lamps); meter.appendChild(message);
    input.insertAdjacentElement('afterend', meter);
    input.setAttribute('aria-describedby', ((input.getAttribute('aria-describedby') || '') + ' ' + meter.id).trim());
    if (!input.title) input.title = tr(rule);
    function update() {
      var value = input.value, chars = Array.from(value);
      var valid = chars.length >= 8 && chars.length <= 128 && /\p{Lu}/u.test(value) && /\p{Ll}/u.test(value) &&
        /\p{Nd}/u.test(value) && /[^\p{L}\p{N}\s]/u.test(value) && !/\p{C}/u.test(value);
      var level = !value ? 'empty' : !valid ? 'red' : chars.length >= 12 && new Set(chars).size >= 8 ? 'green' : 'yellow';
      meter.dataset.level = level;
      message.textContent = tr(level === 'green' ? 'Grün – länger und vielfältiger.' :
        level === 'yellow' ? 'Gelb – Mindestanforderungen erfüllt; Passwort ist zulässig.' :
        level === 'red' ? 'Rot – Anforderungen noch nicht erfüllt.' : 'Passwort eingeben.');
      if (level === 'red' || level === 'empty') message.textContent += ' ' + tr(rule);
      input.setCustomValidity(value && !valid ? tr(rule) : '');
    }
    input.addEventListener('input', update); update();
  });
})();
