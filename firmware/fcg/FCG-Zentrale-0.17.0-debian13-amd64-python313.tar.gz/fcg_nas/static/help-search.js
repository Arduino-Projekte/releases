// Shared local search for the central application's and embedded gateway's help.
(function () {
  'use strict';
  var root = document.querySelector('[data-help-root]');
  var search = document.getElementById('help-search');
  var category = document.getElementById('help-category');
  var clear = document.getElementById('help-clear');
  var status = document.getElementById('help-search-status');
  if (!root || !search || !category || !clear) return;
  function english() { return document.documentElement.lang === 'en'; }
  function normalize(text) { return String(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  function sections() {
    return Array.from(root.querySelectorAll('.help-topic')).filter(function (section) {
      var language = section.closest('[data-help-language]');
      return !language || !language.hidden;
    });
  }
  function visibleText(section) {
    var copy = section.cloneNode(true);
    if (document.documentElement.dataset.adv !== '1') copy.querySelectorAll('.diag').forEach(function (el) { el.remove(); });
    return normalize(copy.textContent);
  }
  function apply() {
    var words = normalize(search.value.trim()).split(/\s+/).filter(Boolean);
    var count = 0;
    sections().forEach(function (section) {
      var text = words.length ? visibleText(section) : '';
      var matches = (!category.value || section.dataset.helpTopic === category.value) && words.every(function (word) { return text.includes(word); });
      section.hidden = !matches;
      if (matches) count++;
      if (words.length && matches) section.querySelectorAll('.help-field-list,.help-technical').forEach(function (details) { details.open = true; });
      document.querySelectorAll('.help-toc a[href="#' + section.id + '"]').forEach(function (link) { link.hidden = !matches; });
    });
    status.textContent = english() ? count + ' matching sections' : count + ' passende Abschnitte';
    document.getElementById('help-no-results').hidden = count !== 0;
  }
  function rebuild() {
    var previous = category.value;
    category.replaceChildren();
    var all = document.createElement('option'); all.value = ''; all.textContent = english() ? 'All topics' : 'Alle Themen'; category.appendChild(all);
    sections().forEach(function (section) {
      var option = document.createElement('option'); option.value = section.dataset.helpTopic; option.textContent = section.querySelector('h2').textContent; category.appendChild(option);
    });
    if (Array.from(category.options).some(function (option) { return option.value === previous; })) category.value = previous;
    search.placeholder = english() ? 'Search topics, fields and explanations' : 'Themen, Felder und Erklärungen durchsuchen';
    document.getElementById('help-search-label').textContent = english() ? 'Search help' : 'Hilfe durchsuchen';
    document.getElementById('help-category-label').textContent = english() ? 'Topic' : 'Thema';
    document.getElementById('help-no-results').textContent = english() ? 'No matches. Try a different term or clear the filters.' : 'Keine Treffer. Anderen Begriff versuchen oder die Filter zurücksetzen.';
    clear.textContent = english() ? 'Clear filters' : 'Filter zurücksetzen';
    apply();
  }
  function reset() { search.value = ''; category.value = ''; apply(); }
  search.addEventListener('input', apply); category.addEventListener('change', apply); clear.addEventListener('click', reset);
  document.addEventListener('fcg-help-language', rebuild);
  document.getElementById('adv')?.addEventListener('click', apply);
  window.addEventListener('hashchange', function () {
    var target = document.getElementById(location.hash.slice(1));
    var section = target && target.closest('.help-topic');
    if (section && section.hidden) { reset(); target.scrollIntoView({block:'center'}); }
  });
  window.fcgHelpSearch = {reset:reset};
  rebuild();
})();
