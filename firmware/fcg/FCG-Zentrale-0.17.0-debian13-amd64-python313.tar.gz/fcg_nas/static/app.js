// Arrange the header using the uploaded image's intrinsic proportions.
(function () {
  var logo = document.querySelector('[data-brand-logo]');
  var header = document.querySelector('[data-header]');
  if (!logo || !header) return;
  function arrange() {
    if (!logo.naturalWidth || !logo.naturalHeight) return;
    header.dataset.logoShape = logo.naturalWidth / logo.naturalHeight >= 2.4 ? 'wide' : 'compact';
  }
  logo.addEventListener('load', arrange);
  if (logo.complete) arrange();
})();

// Laufanzeige: fragt alle 3 s den Status ab. Endet eine Abholung, wird die
// Übersicht neu geladen (ohne Meldung aus der URL), damit die Kacheln die neuen Werte zeigen.
// Die Füllanzeige ([data-live-id]) bekommt dabei den aktuellen Text, [data-live-total] den Zählerstand.
(function () {
  var el = document.getElementById('run-indicator');
  if (!el) return;
  var text = el.querySelector('.text');
  var wasRunning = el.getAttribute('data-running') === 'true';
  function tr(message, values) {
    var text = (window.FCG_I18N || {})[message] || message;
    Object.keys(values || {}).forEach(function (key) { text = text.replace('{' + key + '}', String(values[key])); });
    return text;
  }

  function describe(run) {
    if (run.running) {
      var text = tr('Abholung läuft: Gateway {current} von {total}', {current:Math.min(run.gateways_done + 1, run.gateways_total), total:run.gateways_total});
      if (run.current_host) text += ' (' + run.current_host + ')';
      return text + tr(', bisher {count} neue Einträge', {count:run.added});
    }
    var result = tr('Keine Abholung aktiv');
    if (run.last_finished_at) result += tr(' · letzte: {at}', {at:run.last_finished_at});
    if (run.next_due_in_s !== null && run.next_due_in_s !== undefined) {
      var minutes = Math.ceil(run.next_due_in_s / 60);
      result += tr(' · nächste in {duration}', {duration:minutes <= 1 ? tr('unter 1 Minute') : tr('{count} Minuten', {count:minutes})});
    }
    return result;
  }

  function updateLive(gateways) {
    var byId = {};
    (gateways || []).forEach(function (g) { byId[g.id] = g.live; });
    document.querySelectorAll('[data-live-id]').forEach(function (node) {
      var live = byId[node.getAttribute('data-live-id')];
      if (!live) return;
      node.setAttribute('data-state', live.state);
      var t = node.querySelector('.text');
      if (t) t.textContent = live.text;
    });
    document.querySelectorAll('[data-live-total]').forEach(function (node) {
      var live = byId[node.getAttribute('data-live-total')];
      if (live && live.total_text) node.textContent = live.total_text;
    });
  }

  function poll() {
    fetch('/api/status', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (r.status === 401) { location.href = '/login'; return null; } return r.json(); })
      .then(function (data) {
        if (!data) return;
        var run = data.run;
        el.setAttribute('data-running', run.running ? 'true' : 'false');
        text.textContent = describe(run);
        updateLive(data.gateways);
        if (wasRunning && !run.running && location.pathname === '/') location.replace('/');
        wasRunning = run.running;
      })
      .catch(function () { text.textContent = tr('Status nicht abrufbar'); });
  }

  poll();
  setInterval(poll, 3000);
})();

// Seiten mit laufendem Hintergrundvorgang (z. B. Gateway-Update) neu laden, ohne Meldung aus der URL.
(function () {
  var el = document.querySelector('[data-reload-after]');
  if (!el) return;
  var seconds = parseInt(el.getAttribute('data-reload-after'), 10) || 5;
  setTimeout(function () { location.replace(location.pathname); }, seconds * 1000);
})();
