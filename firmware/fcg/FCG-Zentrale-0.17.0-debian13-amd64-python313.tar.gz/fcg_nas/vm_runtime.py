"""Idempotently update fixed, root-owned access components from installed vendor code.

The older VM updater can install the new application first. Its next path-triggered
worker invocation loads this version and synchronizes these resources; requests
never contain executable code, destination paths or new Linux credentials.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile
import time

SOURCE=Path(__file__).resolve().parent
BUNDLE=SOURCE/'appliance'
STATE=Path('/var/lib/fcg-update')
# Fix the watcher first, so a power interruption cannot preserve the old boot cycle.
FILES=(('appliance/fcg-access.path','/etc/systemd/system/fcg-access.path',0o644),
       ('appliance/fcg-access.service','/etc/systemd/system/fcg-access.service',0o644),
       ('password_policy.py','/usr/local/lib/fcg/password_policy.py',0o644),
       ('vm_defaults.py','/usr/local/lib/fcg/vm_defaults.py',0o644),
       ('appliance/access.py','/usr/local/lib/fcg/access.py',0o755))


def read_regular(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022 or info.st_size>1024**2:
            raise ValueError('Invalid installed VM component.')
        return stream.read(1024**2+1)


def fingerprint(installed=False):
    if not BUNDLE.is_dir():return None
    h=hashlib.sha256()
    for source,target,_ in FILES:
        h.update(source.encode()+b'\0')
        h.update(read_regular(Path(target) if installed else SOURCE/source))
    return h.hexdigest()


def status():
    try:expected=fingerprint()
    except (OSError,ValueError):return {'ready':False,'failed':True}
    if expected is None:return {'ready':True}
    try:installed=fingerprint(True)
    except (OSError,ValueError):installed=None
    if installed==expected:return {'ready':True}
    try:record=json.loads((STATE/'runtime.json').read_text())
    except (OSError,ValueError):record={}
    return {'ready':False,'failed':record.get('state')=='failed' and record.get('expected')==expected}


def request_sync(force=False):
    state=status()
    if state['ready'] or (state.get('failed') and not force):return
    from .vm_queue import enqueue_runtime
    try:enqueue_runtime()
    except OSError:pass  # Another update may already be queued; retry on the next status read.


def record_failure():
    try:expected=fingerprint()
    except (OSError,ValueError):expected=''
    atomic(STATE/'runtime.json',json.dumps({'state':'failed','expected':expected}).encode(),0o644)


def atomic(path,data,mode):
    fd,temporary=tempfile.mkstemp(prefix='.fcg-runtime-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno());os.fchmod(stream.fileno(),mode)
        os.replace(temporary,path)
    finally:Path(temporary).unlink(missing_ok=True)


def synchronize():
    if os.geteuid()!=0:raise PermissionError('Root required.')
    expected=fingerprint()
    if expected is None or status()['ready']:return
    contents={source:read_regular(SOURCE/source) for source,_,_ in FILES}
    for source,data in contents.items():
        if source.endswith('.py'):compile(data,source,'exec')
    previous={}
    for _,target,_ in FILES:
        path=Path(target)
        try:previous[target]=(read_regular(path),path.stat().st_mode&0o777)
        except FileNotFoundError:previous[target]=None
    def command(*args):return subprocess.run(args,check=True,capture_output=True,text=True,timeout=20)
    command('systemctl','stop','fcg-access.path')
    try:
        for _ in range(40):
            active=command('systemctl','show','fcg-access.service','-p','ActiveState','--value').stdout.strip()
            if active not in ('active','activating','deactivating','reloading'):break
            time.sleep(.5)
        else:raise RuntimeError('Access worker is still active.')
        for source,target,mode in FILES:atomic(Path(target),contents[source],mode)
        command('systemctl','daemon-reload')
        command('systemctl','start','fcg-access.path')
        if fingerprint(True)!=expected:raise ValueError('VM components do not match.')
        atomic(STATE/'runtime.json',json.dumps({'state':'ready','expected':expected}).encode(),0o644)
    except Exception:
        for target,value in previous.items():
            if value is None:Path(target).unlink(missing_ok=True)
            else:atomic(Path(target),*value)
        command('systemctl','daemon-reload');command('systemctl','start','fcg-access.path')
        atomic(STATE/'runtime.json',json.dumps({'state':'failed','expected':expected}).encode(),0o644)
        raise
