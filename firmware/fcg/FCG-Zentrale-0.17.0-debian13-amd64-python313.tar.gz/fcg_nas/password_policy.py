"""One password rule for web accounts and the root-owned Linux access worker."""
import unicodedata

MIN_PASSWORD_LENGTH = 8
MAX_PASSWORD_LENGTH = 128
PASSWORD_RULE = 'Mindestens 8 Zeichen mit Großbuchstabe, Kleinbuchstabe, Zahl und Sonderzeichen.'


def password_requirements(password):
    return {
        'length': isinstance(password, str) and MIN_PASSWORD_LENGTH <= len(password) <= MAX_PASSWORD_LENGTH,
        'upper': isinstance(password, str) and any(unicodedata.category(c) == 'Lu' for c in password),
        'lower': isinstance(password, str) and any(unicodedata.category(c) == 'Ll' for c in password),
        'number': isinstance(password, str) and any(unicodedata.category(c) == 'Nd' for c in password),
        'special': isinstance(password, str) and any(not c.isalnum() and not c.isspace() for c in password),
        'characters': isinstance(password, str) and not any(unicodedata.category(c).startswith('C') for c in password),
    }


def check_new_password(password):
    if not all(password_requirements(password).values()):
        raise ValueError(PASSWORD_RULE)


def password_strength(password):
    if not password:return 'empty'
    if not all(password_requirements(password).values()):return 'red'
    return 'green' if len(password) >= 12 and len(set(password)) >= 8 else 'yellow'
