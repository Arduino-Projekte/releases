"""Tagesbericht per Mail: was gestern je Messstelle befüllt wurde und was offen ist.

Geht einmal am Tag ab der eingestellten Stunde raus (Einstellung report_hour),
nur wenn Mail eingeschaltet ist. Der Tag des letzten Versands steht in
report_last_date, damit ein Neustart keinen zweiten Bericht auslöst.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta

from .alerts import LEVEL_TEXT
from .db import Database
from .mailer import MailError, Mailer

log = logging.getLogger("fcg_nas.report")


def _de(value: float, digits: int = 1) -> str:
    text = f"{value:,.{digits}f}"
    return text.replace(",", "_").replace(".", ",").replace("_", ".")


def build_report(db: Database, day: date, open_alerts: list[dict]) -> tuple[str, str]:
    """(Betreff, Text) für den Bericht über den Tag day."""
    with db.connect() as conn:
        rows = conn.execute(
            """
            SELECT s.site_id, s.counter_name, s.unit, g.label, g.host, g.enabled,
              (SELECT COALESCE(SUM(consumed_quantity), 0) FROM entries e
                 WHERE e.site_id = s.site_id AND e.entry_date = ?) AS quantity,
              (SELECT COUNT(*) FROM entries e WHERE e.site_id = s.site_id AND e.entry_date = ?) AS fills
            FROM sites s LEFT JOIN gateways g ON g.id = s.gateway_id
            WHERE g.id IS NOT NULL
            ORDER BY lower(COALESCE(NULLIF(g.label, ''), NULLIF(s.counter_name, ''), s.site_id))
            """,
            (day.isoformat(), day.isoformat()),
        ).fetchall()
    lines = [f"Füllvorgänge am {day.strftime('%d.%m.%Y')}:", ""]
    totals: dict[str, float] = {}
    for row in rows:
        unit = row["unit"] or "l"
        title = row["label"] or row["counter_name"] or row["site_id"]
        if row["fills"]:
            fills = "1 Füllvorgang" if row["fills"] == 1 else f"{row['fills']} Füllvorgängen"
            lines.append(f"- {title}: {_de(row['quantity'])} {unit} in {fills}")
            totals[unit] = totals.get(unit, 0.0) + float(row["quantity"])
        else:
            lines.append(f"- {title}: kein Füllvorgang")
    if not rows:
        lines.append("- keine Messstellen")
    if totals:
        lines += ["", "Zusammen: " + ", ".join(f"{_de(v)} {u}" for u, v in sorted(totals.items()))]
    lines += [""]
    if open_alerts:
        lines.append(f"Offene Warnungen ({len(open_alerts)}):")
        for alert in open_alerts:
            level = LEVEL_TEXT.get(alert["level"], "Warnung")
            lines.append(f"- {level}: {alert['text']} (seit {alert['opened_at']})")
    else:
        lines.append("Keine offenen Warnungen.")
    lines += ["", "FCG Zentrale"]
    total_text = ", ".join(f"{_de(v)} {u}" for u, v in sorted(totals.items())) or "nichts befüllt"
    warn_text = f", {len(open_alerts)} Warnung(en) offen" if open_alerts else ""
    subject = f"FCG Zentrale: Tagesbericht {day.strftime('%d.%m.%Y')} ({total_text}{warn_text})"
    return subject, "\n".join(lines)


class DailyReport:
    def __init__(self, db: Database, mailer: Mailer, open_alerts) -> None:
        self.db = db
        self.mailer = mailer
        self.open_alerts = open_alerts

    def due(self, now: datetime | None = None) -> bool:
        now = now or datetime.now()
        settings = self.db.get_settings()
        if settings.get("report_enabled") != "1" or settings.get("mail_enabled") != "1":
            return False
        hour = int(settings.get("report_hour") or 6)
        return now.hour >= hour and (settings.get("report_last_date") or "") < now.strftime("%Y-%m-%d")

    def send(self, now: datetime | None = None, force: bool = False) -> str:
        """Bericht über gestern senden. Liefert eine Meldung für Protokoll und Anzeige."""
        now = now or datetime.now()
        subject, body = build_report(self.db, (now - timedelta(days=1)).date(), self.open_alerts())
        self.mailer.send(subject, body, force=force)
        if not force:
            self.db.set_settings({"report_last_date": now.strftime("%Y-%m-%d")})
        return subject

    def tick(self) -> None:
        if not self.due():
            return
        try:
            self.send()
        except MailError as exc:
            # Nicht als erledigt merken: beim nächsten Durchlauf erneut versuchen.
            log.warning("Tagesbericht nicht gesendet: %s", exc)
