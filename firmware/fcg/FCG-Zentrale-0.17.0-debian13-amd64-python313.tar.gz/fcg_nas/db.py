"""SQLite-Datenbank mit versionierten Migrationen.

Die Datenbank ist die einzige Autoritaet: Der Cursor einer Messstelle ist die
höchste gespeicherte Seq. Jede Seite wird in einer Transaktion geschrieben,
ein Abbruch mitten im Lauf hinterlaesst daher keine halben Einträge.
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator

# Jede Migration bringt das Schema genau eine Version weiter. Bestehende
# Migrationen werden nie geändert, nur neue angehaengt.
MIGRATIONS: dict[int, str] = {
    1: """
    CREATE TABLE settings(
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    CREATE TABLE users(
        username TEXT PRIMARY KEY COLLATE NOCASE,
        role TEXT NOT NULL CHECK(role IN ('admin', 'reader')),
        pw_hash TEXT NOT NULL,
        failed_count INTEGER NOT NULL DEFAULT 0,
        locked_until REAL NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
    );
    CREATE TABLE sessions(
        token TEXT PRIMARY KEY,
        username TEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
        csrf TEXT NOT NULL,
        created_at REAL NOT NULL,
        expires_at REAL NOT NULL
    );
    CREATE TABLE gateways(
        id INTEGER PRIMARY KEY,
        host TEXT NOT NULL UNIQUE,
        label TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL DEFAULT '',
        password_enc TEXT NOT NULL DEFAULT '',
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        site_id TEXT,
        counter_name TEXT,
        device_label TEXT,
        location TEXT,
        fw_version TEXT,
        unit TEXT,
        demo_mode INTEGER NOT NULL DEFAULT 0,
        last_attempt_at TEXT,
        last_ok_at TEXT,
        last_error TEXT,
        last_added INTEGER
    );
    CREATE TABLE sites(
        site_id TEXT PRIMARY KEY,
        counter_name TEXT,
        device_label TEXT,
        location TEXT,
        unit TEXT,
        gateway_id INTEGER REFERENCES gateways(id) ON DELETE SET NULL,
        first_seen TEXT NOT NULL,
        last_seen TEXT NOT NULL
    );
    CREATE TABLE entries(
        site_id TEXT NOT NULL REFERENCES sites(site_id),
        seq INTEGER NOT NULL,
        ts TEXT NOT NULL,
        entry_date TEXT,
        total_quantity REAL NOT NULL,
        consumed_quantity REAL,
        consumption_source TEXT NOT NULL,
        fuel_type TEXT NOT NULL DEFAULT '',
        additional_aggregate INTEGER NOT NULL DEFAULT 0,
        collected_at TEXT NOT NULL,
        PRIMARY KEY(site_id, seq)
    ) WITHOUT ROWID;
    CREATE INDEX entries_by_date ON entries(site_id, entry_date);
    CREATE TABLE runs(
        id INTEGER PRIMARY KEY,
        trigger TEXT NOT NULL,
        started_by TEXT,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        status TEXT NOT NULL,
        gateways_total INTEGER NOT NULL DEFAULT 0,
        gateways_ok INTEGER NOT NULL DEFAULT 0,
        gateways_failed INTEGER NOT NULL DEFAULT 0,
        added INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE run_results(
        run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
        gateway_id INTEGER,
        host TEXT NOT NULL,
        ok INTEGER NOT NULL,
        added INTEGER NOT NULL,
        message TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX run_results_by_run ON run_results(run_id);
    CREATE TABLE audit(
        id INTEGER PRIMARY KEY,
        ts TEXT NOT NULL,
        username TEXT,
        action TEXT NOT NULL,
        detail TEXT NOT NULL DEFAULT ''
    );
    """,
    # Phase 2: stabiler CSV-Name je Messstelle (wie die Bindung in fcg_site_map.json)
    # und Protokoll der CSV-Importe.
    2: """
    ALTER TABLE sites ADD COLUMN csv_stem TEXT;
    CREATE UNIQUE INDEX sites_by_stem ON sites(csv_stem);
    CREATE TABLE imports(
        id INTEGER PRIMARY KEY,
        ts TEXT NOT NULL,
        username TEXT,
        file_name TEXT NOT NULL,
        site_id TEXT NOT NULL,
        added INTEGER NOT NULL,
        existing INTEGER NOT NULL,
        conflicts INTEGER NOT NULL,
        invalid INTEGER NOT NULL
    );
    """,
    # Phase 3: Ereignislogs der Gateways. Das RAM-Log hat keine Seq; ein Eintrag
    # ist eindeutig über Gateway, Bootzähler, Uptime, Level, Bereich und Text.
    3: """
    ALTER TABLE gateways ADD COLUMN log_boot INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE gateways ADD COLUMN log_last_uptime INTEGER;
    ALTER TABLE gateways ADD COLUMN log_last_ok_at TEXT;
    ALTER TABLE gateways ADD COLUMN log_error TEXT;
    CREATE TABLE gateway_logs(
        id INTEGER PRIMARY KEY,
        gateway_id INTEGER NOT NULL,
        host TEXT NOT NULL,
        boot INTEGER NOT NULL,
        uptime_ms INTEGER NOT NULL,
        ts_text TEXT NOT NULL,
        level TEXT NOT NULL,
        area TEXT NOT NULL,
        message TEXT NOT NULL,
        fetched_at TEXT NOT NULL,
        UNIQUE(gateway_id, boot, uptime_ms, level, area, message)
    );
    CREATE INDEX gateway_logs_by_gateway ON gateway_logs(gateway_id, id);
    CREATE INDEX gateway_logs_by_fetch ON gateway_logs(fetched_at);
    """,
    # Phase 4: Warnungen (offen = closed_at leer, je Schlüssel höchstens eine offene)
    # und die vom OTA-Spiegel gefundenen Firmware-Versionen.
    4: """
    CREATE TABLE alerts(
        id INTEGER PRIMARY KEY,
        key TEXT NOT NULL,
        level TEXT NOT NULL,
        text TEXT NOT NULL,
        opened_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        closed_at TEXT,
        mailed_open INTEGER NOT NULL DEFAULT 0,
        mailed_closed INTEGER NOT NULL DEFAULT 0
    );
    CREATE UNIQUE INDEX alerts_open_by_key ON alerts(key) WHERE closed_at IS NULL;
    CREATE TABLE ota_releases(
        version TEXT PRIMARY KEY,
        file TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        manifest TEXT NOT NULL,
        found_at TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('pending', 'published', 'rejected')),
        decided_by TEXT,
        decided_at TEXT
    );
    CREATE INDEX audit_by_ts ON audit(ts);
    """,
    # V0.6.0: Gerätezustand aus /api/collector (health, ab Firmware V0.21.46),
    # der zuletzt gelesene Auto-Install-Schalter (NULL = unbekannt) und die
    # Impulse pro Einheit aus /api/counter.
    5: """
    ALTER TABLE gateways ADD COLUMN health_json TEXT;
    ALTER TABLE gateways ADD COLUMN ota_auto_install INTEGER;
    ALTER TABLE gateways ADD COLUMN ota_state_at TEXT;
    ALTER TABLE gateways ADD COLUMN pulses_per_unit REAL;
    """,
    # V0.8.0: Leser-Konto heißt jetzt "user" (die Kollegen melden sich neu an).
    # Warnungen quittieren. fingerprint ändert sich, wenn etwas Neues
    # passiert (z. B. ein neuer Logfehler); dann gilt die Quittierung nicht mehr.
    6: """
    ALTER TABLE alerts ADD COLUMN acked_at TEXT;
    ALTER TABLE alerts ADD COLUMN acked_by TEXT;
    ALTER TABLE alerts ADD COLUMN fingerprint TEXT NOT NULL DEFAULT '';
    DELETE FROM sessions WHERE username = 'leser';
    UPDATE users SET username = 'user' WHERE username = 'leser';
    """,
    7: """
    CREATE TABLE update_sources(
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        server TEXT NOT NULL,
        share TEXT NOT NULL,
        subdir TEXT NOT NULL DEFAULT '',
        username TEXT NOT NULL,
        password_enc TEXT NOT NULL DEFAULT '',
        encrypt INTEGER NOT NULL DEFAULT 1,
        enabled INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE offline_packages(
        id TEXT PRIMARY KEY,
        source_id INTEGER REFERENCES update_sources(id) ON DELETE SET NULL,
        kind TEXT NOT NULL,
        version TEXT NOT NULL,
        target TEXT NOT NULL,
        filename TEXT NOT NULL,
        notes TEXT NOT NULL,
        imported_at TEXT NOT NULL,
        state TEXT NOT NULL DEFAULT 'checked',
        decided_by TEXT,
        decided_at TEXT
    );
    """,
}

SCHEMA_VERSION = max(MIGRATIONS)

DEFAULT_SETTINGS: dict[str, str] = {
    "poll_interval_min": "5",
    "limit": "25",
    "timeout_sec": "60",
    "offline_after_min": "15",
    "max_pages_per_gateway": "10000",
    # Statistik wie fcg_config.json des PowerShell-Collectors
    "stats_cutoff_month": "1",
    "stats_cutoff_day": "25",
    "stats_calendar_month": "1",
    "stats_annual": "0",
    "stats_annual_day_month": "01.01",
    "stats_include_open": "1",
    "stats_per_site": "1",
    "stats_overall": "1",
    "stats_policy": "skip_closed_overwrite_open",
    # Automatischer Export in den Freigabeordner
    "export_enabled": "1",
    # Phase 3: Füllanzeige und Ereignislogs
    "fueling_window_min": "10",
    "live_interval_sec": "30",
    "log_retention_days": "180",
    # Phase 4: Warnungen und Mail
    "alert_offline_hours": "2",
    "alert_disk_min_mb": "1024",
    "mail_enabled": "0",
    "smtp_host": "",
    "smtp_port": "587",
    "smtp_security": "starttls",
    "smtp_user": "",
    "smtp_password_enc": "",
    "mail_from": "",
    "mail_to": "",
    # Phase 4: Komplettsicherung
    "backup_enabled": "1",
    "backup_hour": "2",
    "backup_keep_days": "30",
    # Phase 4: OTA-Spiegel
    "guest_enabled": "0",
    "guest_networks": "",
    "guest_proxy_networks": "",
    "guest_allow_dashboard": "1",
    "guest_allow_stats": "1",
    "guest_allow_analysis": "1",
    "ota_enabled": "1",
    "ota_source_url": "",
    "ota_check_hours": "6",
    # V0.9.0: so viele Gateways gleichzeitig aktualisieren (Gruppen)
    "ota_parallel": "3",
    # V0.7.0: Tagesbericht, weitere Warnungen, Hallenanzeige, Zugriff von außen
    "report_enabled": "0",
    "report_hour": "6",
    "report_last_date": "",
    "alert_silence_factor": "3",
    "alert_silence_min_days": "2",
    "alert_log_errors": "1",
    "dashboard_refresh_sec": "30",
    "admin_lan_only": "1",
    # V0.9.0: Gateway-Admin für Firmware-Updates (Passwort verschlüsselt, leer = bei jedem Klick eingeben)
    "gw_admin_user": "",
    "gw_admin_password_enc": "",
}


def now_text() -> str:
    """Lokale Zeit des Containers (TZ), sekundengenau."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._migrate_lock = threading.Lock()

    def _open(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 30000")
        return conn

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Verbindung im Autocommit-Modus; Transaktionen über transaction()."""
        conn = self._open()
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self._open()
        try:
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except BaseException:
                conn.execute("ROLLBACK")
                raise
            conn.execute("COMMIT")
        finally:
            conn.close()

    def schema_version(self) -> int:
        """Schema der vorhandenen Datei, 0 wenn sie fehlt oder leer ist."""
        if not self.path.exists():
            return 0
        with self.connect() as conn:
            return conn.execute("PRAGMA user_version").fetchone()[0]

    def migrate(self) -> int:
        """Bringt das Schema auf SCHEMA_VERSION und legt fehlende Einstellungen an."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._migrate_lock, self.connect() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            current = conn.execute("PRAGMA user_version").fetchone()[0]
            if current > SCHEMA_VERSION:
                raise RuntimeError(
                    f"Datenbank hat Schema {current}, diese Version kennt nur {SCHEMA_VERSION}. "
                    "Bitte eine neuere Collector-Version verwenden."
                )
            for version in range(current + 1, SCHEMA_VERSION + 1):
                conn.execute("BEGIN IMMEDIATE")
                try:
                    for statement in _split_sql(MIGRATIONS[version]):
                        conn.execute(statement)
                    conn.execute(f"PRAGMA user_version = {version}")
                except BaseException:
                    conn.execute("ROLLBACK")
                    raise
                conn.execute("COMMIT")
            for key, value in DEFAULT_SETTINGS.items():
                conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)", (key, value))
            # Normalize legacy defaults to an empty selector; custom sources survive.
            from .update_source import DEFAULT_SOURCE
            conn.execute("UPDATE settings SET value = '' WHERE key = 'ota_source_url' AND rtrim(value, '/') = ?",
                         (DEFAULT_SOURCE.rstrip('/'),))
            return conn.execute("PRAGMA user_version").fetchone()[0]

    # --- Einstellungen -------------------------------------------------

    def get_settings(self) -> dict[str, str]:
        with self.connect() as conn:
            rows = conn.execute("SELECT key, value FROM settings").fetchall()
        values = dict(DEFAULT_SETTINGS)
        values.update({row["key"]: row["value"] for row in rows})
        from .update_source import custom_source
        values['ota_source_url'] = custom_source(values.get('ota_source_url', ''))
        return values

    def get_int_setting(self, key: str) -> int:
        try:
            return int(self.get_settings()[key])
        except (KeyError, ValueError):
            return int(DEFAULT_SETTINGS[key])

    def set_settings(self, values: dict[str, str]) -> None:
        with self.transaction() as conn:
            for key, value in values.items():
                conn.execute(
                    "INSERT INTO settings(key, value) VALUES(?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (key, value),
                )

    # --- Protokoll -----------------------------------------------------

    def audit(self, username: str | None, action: str, detail: str = "") -> None:
        from .update_source import public_text
        detail = public_text(detail)
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO audit(ts, username, action, detail) VALUES(?, ?, ?, ?)",
                (now_text(), username, action, detail),
            )


def _split_sql(script: str) -> list[str]:
    return [part.strip() for part in script.split(";") if part.strip()]
