"""Import der alten CSV-Historie des PowerShell-Collectors.

Ablauf: Dateien hochladen -> Vorschau (Zuordnung zur Messstelle, neue,
vorhandene und abweichende Einträge) -> bestätigen. Übernommen werden nur
Seqs, die in der Datenbank noch fehlen. Eine vorhandene Seq wird nie
überschrieben; weicht sie ab, steht das in der Vorschau.

Zuordnung zur site_id, in dieser Reihenfolge:
1. fcg_site_map.json oder *.state.json aus dem alten Ausgabeordner (mit hochladen)
2. CSV-Name gleich dem Namen einer bekannten Messstelle
3. Prüfsumme am Ende des Namens (FCG_..._<sha256(site_id)[:12]>)
4. alter Name <Zähler>_<IP>.csv über die Gateway-Adresse
5. sonst Auswahl von Hand
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from .collector import _number
from .db import Database, now_text

MAX_UPLOAD_BYTES = 50 * 1024 * 1024
MAX_FILES = 50
STAGING_MAX_AGE_S = 24 * 3600
TOKEN = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
DATE_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")
DATE_DE = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4})$")
TIME = re.compile(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$")
HASH_SUFFIX = re.compile(r"_([0-9a-f]{12})$")
LEGACY_IP = re.compile(r"_(\d{1,3}-\d{1,3}-\d{1,3}-\d{1,3})$")
EPS = 0.0005


@dataclass
class ImportRow:
    seq: int
    ts: str
    entry_date: str | None
    total: float
    consumed: float | None
    fuel: str
    aggregate: bool


@dataclass
class ParsedFile:
    name: str
    rows: list[ImportRow] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    invalid: int = 0
    duplicates: int = 0

    @property
    def stem(self) -> str:
        return self.name[:-4] if self.name.lower().endswith(".csv") else self.name


@dataclass
class Mapping:
    site_id: str
    counter_name: str
    source: str


def _decode(data: bytes) -> str:
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def _parse_date_time(datum: str, zeit: str) -> tuple[str, str | None]:
    match = DATE_ISO.match(datum) or None
    iso = None
    if match:
        iso = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
    else:
        match = DATE_DE.match(datum)
        if match:
            iso = f"{match.group(3)}-{match.group(2)}-{match.group(1)}"
    time_match = TIME.match(zeit)
    if iso and time_match:
        h, m, s = time_match.group(1), time_match.group(2), time_match.group(3) or "00"
        return f"{iso} {int(h):02d}:{m}:{s}", iso
    if iso and not zeit:
        return f"{iso} 00:00:00", iso
    return f"{datum} {zeit}".strip(), iso


def parse_csv(name: str, data: bytes) -> ParsedFile:
    result = ParsedFile(name=name)
    lines = _decode(data).splitlines()
    if not lines or not lines[0].strip().lower().startswith("seq;"):
        result.errors.append("Erste Zeile ist nicht die Kopfzeile Seq;Datum;Zeit;Zählerstand;… des Collectors.")
        return result
    seen: set[int] = set()
    for number, line in enumerate(lines[1:], start=2):
        if not line.strip():
            continue
        fields = [f.strip() for f in line.split(";")]
        if fields[0].lower() == "seq":
            continue  # wiederholte Kopfzeile
        fields += [""] * (7 - len(fields))
        error = None
        try:
            seq = int(fields[0])
            if seq < 1:
                raise ValueError
        except ValueError:
            seq, error = 0, "ungültige Seq"
        total = _number(fields[3])
        if error is None and total is None:
            error = "ungültiger Zählerstand"
        consumed = None
        if error is None and fields[4] != "":
            consumed = _number(fields[4])
            if consumed is None or consumed < 0:
                error = "ungültiger Verbrauch"
        if error:
            result.invalid += 1
            if len(result.errors) < 10:
                result.errors.append(f"Zeile {number}: {error}")
            continue
        if seq in seen:
            result.duplicates += 1
            continue
        seen.add(seq)
        ts, entry_date = _parse_date_time(fields[1], fields[2])
        result.rows.append(ImportRow(
            seq=seq, ts=ts, entry_date=entry_date, total=float(total), consumed=consumed,
            fuel=fields[5], aggregate=fields[6].lower() in {"ja", "true", "1", "yes"},
        ))
    result.rows.sort(key=lambda r: r.seq)
    return result


def _base_name(value) -> str:
    # Pfade können aus Windows stammen (C:\\FCG\\x.csv).
    return Path(str(value).replace("\\", "/")).name.lower()


def parse_mapping(name: str, data: bytes) -> dict[str, Mapping]:
    """CSV-Dateiname -> Mapping aus fcg_site_map.json oder *.state.json."""
    try:
        doc = json.loads(_decode(data))
    except json.JSONDecodeError:
        return {}
    result: dict[str, Mapping] = {}
    if isinstance(doc, dict) and isinstance(doc.get("sites"), list):
        for site in doc["sites"]:
            if isinstance(site, dict) and site.get("site_id") and site.get("csv_file"):
                result[_base_name(site["csv_file"])] = Mapping(
                    str(site["site_id"]).strip(), str(site.get("last_seen_counter_name") or ""), name)
    elif isinstance(doc, dict) and doc.get("site_id") and doc.get("csv_file"):
        result[_base_name(doc["csv_file"])] = Mapping(
            str(doc["site_id"]).strip(), str(doc.get("counter_name") or ""), name)
    return result


def site_hash(site_id: str) -> str:
    return hashlib.sha256(site_id.encode("utf-8")).hexdigest()[:12]


def guess_site(parsed: ParsedFile, mappings: dict[str, Mapping], sites: list[dict]) -> tuple[str | None, str]:
    """(site_id oder None, Begründung)."""
    mapped = mappings.get(parsed.name.lower())
    if mapped:
        return mapped.site_id, f"aus {mapped.source}"
    for site in sites:
        if site["csv_stem"] and site["csv_stem"].lower() == parsed.stem.lower():
            return site["site_id"], "gleicher Dateiname"
    match = HASH_SUFFIX.search(parsed.stem)
    if match:
        for site in sites:
            if site_hash(site["site_id"]) == match.group(1):
                return site["site_id"], "Prüfsumme im Dateinamen"
    match = LEGACY_IP.search(parsed.stem)
    if match:
        ip = match.group(1).replace("-", ".")
        for site in sites:
            if site["site_id"] == f"host:{ip}" or (site.get("host") or "").split(":")[0] == ip:
                return site["site_id"], f"Adresse {ip} im alten Dateinamen"
    return None, "keine Zuordnung gefunden, bitte von Hand wählen"


def own_site_id(parsed: ParsedFile) -> str:
    """Eigene Messstelle für eine Datei ohne Gateway (z. B. ausgemusterter Zähler)."""
    return f"import:{parsed.stem}"


def known_sites(db: Database) -> list[dict]:
    with db.connect() as conn:
        return [dict(r) for r in conn.execute(
            "SELECT s.site_id, s.csv_stem, s.counter_name, s.location, g.host, "
            "(SELECT COUNT(*) FROM entries e WHERE e.site_id = s.site_id) AS entry_count, "
            "(SELECT MAX(seq) FROM entries e WHERE e.site_id = s.site_id) AS max_seq "
            "FROM sites s LEFT JOIN gateways g ON g.id = s.gateway_id ORDER BY lower(COALESCE(s.counter_name, s.site_id))"
        ).fetchall()]


@dataclass
class Comparison:
    new: int = 0
    existing: int = 0
    conflicts: int = 0
    conflict_seqs: list[int] = field(default_factory=list)
    db_max_seq: int | None = None


def _same(row: ImportRow, existing) -> bool:
    if abs(row.total - existing["total_quantity"]) > EPS:
        return False
    if (row.consumed is None) != (existing["consumed_quantity"] is None):
        return False
    if row.consumed is not None and abs(row.consumed - existing["consumed_quantity"]) > EPS:
        return False
    return row.fuel == (existing["fuel_type"] or "") and row.aggregate == bool(existing["additional_aggregate"])


def compare(conn, site_id: str, rows: list[ImportRow]) -> Comparison:
    result = Comparison()
    existing = {
        r["seq"]: r for r in conn.execute(
            "SELECT seq, total_quantity, consumed_quantity, fuel_type, additional_aggregate FROM entries WHERE site_id = ?",
            (site_id,),
        )
    }
    result.db_max_seq = max(existing) if existing else None
    for row in rows:
        old = existing.get(row.seq)
        if old is None:
            result.new += 1
        elif _same(row, old):
            result.existing += 1
        else:
            result.conflicts += 1
            if len(result.conflict_seqs) < 10:
                result.conflict_seqs.append(row.seq)
    return result


def apply_import(db: Database, site_id: str, parsed: ParsedFile, username: str, counter_name: str = "",
                 adopt_name: bool = False) -> Comparison:
    """Übernimmt fehlende Seqs in einer Transaktion. Vorhandene bleiben unverändert."""
    now = now_text()
    with db.transaction() as conn:
        if not conn.execute("SELECT 1 FROM sites WHERE site_id = ?", (site_id,)).fetchone():
            # Messstelle aus der alten Zuordnung, Gateway wird später angelegt.
            conn.execute(
                "INSERT INTO sites(site_id, counter_name, device_label, location, unit, gateway_id, first_seen, last_seen) "
                "VALUES(?, ?, '', '', 'l', NULL, ?, ?)",
                (site_id, counter_name or parsed.stem, now, now),
            )
        result = compare(conn, site_id, parsed.rows)
        existing = {r[0] for r in conn.execute("SELECT seq FROM entries WHERE site_id = ?", (site_id,))}
        for row in parsed.rows:
            if row.seq in existing:
                continue
            conn.execute(
                "INSERT INTO entries(site_id, seq, ts, entry_date, total_quantity, consumed_quantity, "
                "consumption_source, fuel_type, additional_aggregate, collected_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (site_id, row.seq, row.ts, row.entry_date, row.total, row.consumed,
                 "import" if row.consumed is not None else "import_unknown", row.fuel, int(row.aggregate), now),
            )
        if adopt_name and not conn.execute(
            "SELECT 1 FROM sites WHERE csv_stem = ? AND site_id <> ?", (parsed.stem, site_id)
        ).fetchone():
            # Export schreibt dann weiter in die alte Datei, wie die Bindung im PS-Collector.
            conn.execute("UPDATE sites SET csv_stem = ? WHERE site_id = ?", (parsed.stem, site_id))
        conn.execute(
            "INSERT INTO imports(ts, username, file_name, site_id, added, existing, conflicts, invalid) "
            "VALUES(?, ?, ?, ?, ?, ?, ?, ?)",
            (now, username, parsed.name, site_id, result.new, result.existing, result.conflicts, parsed.invalid),
        )
    return result


# --- Zwischenablage für die Vorschau ---------------------------------------------


class Staging:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def cleanup(self) -> None:
        if not self.root.is_dir():
            return
        limit = time.time() - STAGING_MAX_AGE_S
        for item in self.root.iterdir():
            if item.is_dir() and item.stat().st_mtime < limit:
                shutil.rmtree(item, ignore_errors=True)

    def save(self, files: list[tuple[str, bytes]]) -> str:
        self.cleanup()
        token = secrets.token_urlsafe(18)
        folder = self.root / token
        folder.mkdir(parents=True)
        names = []
        for index, (name, data) in enumerate(files):
            (folder / f"{index}.bin").write_bytes(data)
            names.append(name)
        (folder / "files.json").write_text(json.dumps(names), encoding="utf-8")
        return token

    def load(self, token: str) -> list[tuple[str, bytes]]:
        if not TOKEN.match(token or ""):
            raise KeyError(token)
        folder = self.root / token
        names = json.loads((folder / "files.json").read_text(encoding="utf-8"))
        return [(name, (folder / f"{index}.bin").read_bytes()) for index, name in enumerate(names)]

    def drop(self, token: str) -> None:
        if TOKEN.match(token or ""):
            shutil.rmtree(self.root / token, ignore_errors=True)


def safe_upload_name(name: str) -> str:
    return Path((name or "").replace("\\", "/")).name[:200] or "unbenannt.csv"


def split_uploads(files: list[tuple[str, bytes]]) -> tuple[list[ParsedFile], dict[str, Mapping], list[str]]:
    """(CSV-Dateien, Zuordnungen, ignorierte Dateien)."""
    parsed, mappings, ignored = [], {}, []
    for name, data in files:
        lower = name.lower()
        if lower.startswith("fcg_statistik"):
            ignored.append(name)  # Statistikberichte werden neu berechnet
        elif lower.endswith(".csv"):
            parsed.append(parse_csv(name, data))
        elif lower.endswith(".json"):
            found = parse_mapping(name, data)
            if found:
                mappings.update(found)
            else:
                ignored.append(name)
        else:
            ignored.append(name)
    return parsed, mappings, ignored
