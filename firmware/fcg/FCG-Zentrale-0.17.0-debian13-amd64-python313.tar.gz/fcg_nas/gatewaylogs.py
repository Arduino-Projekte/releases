"""Ereignislogs der Gateways zentral sammeln.

/api/log liefert das RAM-Log (Ringpuffer, 100 Einträge, neueste zuerst)
ohne Seq. Ein Eintrag ist deshalb eindeutig über Gateway, Bootzähler,
Uptime in ms, Level, Bereich und Text. Das RAM-Log beginnt nach jedem
Neustart des Gateways leer: Ist die höchste Uptime einer Abfrage kleiner als
die zuletzt gesehene, zählt der Bootzähler hoch, damit gleiche Startmeldungen
des neuen Laufs nicht als Duplikate verworfen werden.

Die Zeitangabe wechselt am Gateway von Uptime auf Uhrzeit, sobald die Zeit
synchronisiert ist. Ein schon gespeicherter Eintrag bekommt dann die Uhrzeit.

Lief der Ringpuffer zwischen zwei Abfragen über, fehlen Einträge. Das wird
als eigener Eintrag (Bereich NAS) vermerkt, nicht still übergangen.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from .db import Database, now_text
from .gateway_client import GatewayAuth, GatewayError, JsonFn

LOG_TIMEOUT_S = 15.0
DATE_LIKE = re.compile(r"^\d{4}-\d{2}-\d{2}")
LEVELS = {"D": "Debug", "I": "Info", "W": "Warnung", "E": "Fehler"}


@dataclass
class LogEntry:
    uptime_ms: int
    ts_text: str
    level: str
    area: str
    message: str


def parse_log(data: Any) -> tuple[list[LogEntry], int, int]:
    """(Einträge älteste zuerst, stored_count, capacity)."""
    if not isinstance(data, dict) or not isinstance(data.get("entries"), list):
        raise GatewayError("Antwort von /api/log hat keine Einträge.")
    entries = []
    for raw in data["entries"]:
        if not isinstance(raw, dict):
            continue
        uptime = raw.get("uptime_ms64", raw.get("uptime_ms"))
        try:
            uptime_ms = int(str(uptime))
        except (TypeError, ValueError):
            continue
        level = str(raw.get("level") or "?")[:1].upper()
        entries.append(LogEntry(
            uptime_ms=uptime_ms,
            ts_text=str(raw.get("timestamp") or "")[:40],
            level=level,
            area=str(raw.get("area") or "")[:24],
            message=str(raw.get("message") or "")[:500],
        ))
    if data.get("newest_first", True):
        entries.reverse()
    entries.sort(key=lambda e: e.uptime_ms)  # stabil: gleiche Uptime behält die Reihenfolge
    try:
        stored = int(data.get("stored_count", len(entries)))
        capacity = int(data.get("capacity", 0))
    except (TypeError, ValueError):
        stored, capacity = len(entries), 0
    return entries, stored, capacity


def collect_logs(db: Database, gateway: sqlite3.Row, get_json: JsonFn, auth: GatewayAuth | None = None) -> tuple[int, str]:
    """Holt das RAM-Log eines Gateways. Liefert (neue Einträge, Fehlertext oder '')."""
    gateway_id, host = gateway["id"], gateway["host"]
    try:
        entries, stored, capacity = parse_log(get_json(host, "/api/log", auth or GatewayAuth(), LOG_TIMEOUT_S))
    except (GatewayError, ValueError) as exc:
        with db.connect() as conn:
            conn.execute("UPDATE gateways SET log_error = ? WHERE id = ?", (str(exc), gateway_id))
        return 0, str(exc)

    fetched_at = now_text()
    added = 0
    with db.transaction() as conn:
        row = conn.execute("SELECT log_boot, log_last_uptime FROM gateways WHERE id = ?", (gateway_id,)).fetchone()
        boot = row["log_boot"] if row else 0
        last_uptime = row["log_last_uptime"] if row else None
        if entries:
            newest = entries[-1].uptime_ms
            if last_uptime is not None and newest < last_uptime:
                boot += 1  # Gateway wurde neu gestartet, RAM-Log beginnt von vorn
                last_uptime = None
            oldest = entries[0].uptime_ms
            if last_uptime is not None and capacity and stored >= capacity and oldest > last_uptime:
                # Ringpuffer voll und der älteste Eintrag ist neuer als der zuletzt gesehene:
                # dazwischen wurden Einträge überschrieben.
                conn.execute(
                    "INSERT OR IGNORE INTO gateway_logs(gateway_id, host, boot, uptime_ms, ts_text, level, area, message, fetched_at) "
                    "VALUES(?, ?, ?, ?, ?, 'W', 'NAS', ?, ?)",
                    (gateway_id, host, boot, oldest - 1, fetched_at,
                     "Mögliche Lücke: Das Ereignislog des Gateways ist seit der letzten Abfrage übergelaufen. "
                     "Dazwischen können Einträge fehlen.", fetched_at),
                )
            for entry in entries:
                cursor = conn.execute(
                    "INSERT INTO gateway_logs(gateway_id, host, boot, uptime_ms, ts_text, level, area, message, fetched_at) "
                    "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) "
                    "ON CONFLICT(gateway_id, boot, uptime_ms, level, area, message) DO NOTHING",
                    (gateway_id, host, boot, entry.uptime_ms, entry.ts_text, entry.level, entry.area, entry.message, fetched_at),
                )
                if cursor.rowcount:
                    added += 1
                elif DATE_LIKE.match(entry.ts_text):
                    # Zeit inzwischen synchronisiert: Uptime-Angabe durch Uhrzeit ersetzen.
                    conn.execute(
                        "UPDATE gateway_logs SET ts_text = ? WHERE gateway_id = ? AND boot = ? AND uptime_ms = ? "
                        "AND level = ? AND area = ? AND message = ? AND ts_text NOT GLOB '[0-9][0-9][0-9][0-9]-*'",
                        (entry.ts_text, gateway_id, boot, entry.uptime_ms, entry.level, entry.area, entry.message),
                    )
            last_uptime = max(newest, last_uptime or 0)
        conn.execute(
            "UPDATE gateways SET log_boot = ?, log_last_uptime = ?, log_last_ok_at = ?, log_error = NULL WHERE id = ?",
            (boot, last_uptime, fetched_at, gateway_id),
        )
    return added, ""


def prune(db: Database, retention_days: int) -> int:
    limit = (datetime.now() - timedelta(days=retention_days)).strftime("%Y-%m-%d %H:%M:%S")
    with db.connect() as conn:
        return conn.execute("DELETE FROM gateway_logs WHERE fetched_at < ?", (limit,)).rowcount


def query(db: Database, gateway_id: int | None = None, level: str = "", area: str = "", text: str = "",
          day_from: str = "", day_to: str = "", limit: int = 200, offset: int = 0) -> tuple[list[dict], int]:
    where, params = [], []
    if gateway_id:
        where.append("l.gateway_id = ?")
        params.append(gateway_id)
    if level in LEVELS:
        # Mindestlevel: W zeigt Warnungen und Fehler
        order = "DIWE"
        where.append("l.level IN (%s)" % ",".join("?" for _ in order[order.index(level):]))
        params.extend(order[order.index(level):])
    if area:
        where.append("l.area = ?")
        params.append(area)
    if text:
        where.append("l.message LIKE ? ESCAPE '\\'")
        params.append("%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    if day_from:
        where.append("substr(l.fetched_at, 1, 10) >= ?")
        params.append(day_from)
    if day_to:
        where.append("substr(l.fetched_at, 1, 10) <= ?")
        params.append(day_to)
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    with db.connect() as conn:
        total = conn.execute(f"SELECT COUNT(*) FROM gateway_logs l{clause}", params).fetchone()[0]
        rows = [dict(r) for r in conn.execute(
            "SELECT l.*, COALESCE(NULLIF(g.label, ''), NULLIF(g.counter_name, ''), l.host) AS gateway_title "
            f"FROM gateway_logs l LEFT JOIN gateways g ON g.id = l.gateway_id{clause} "
            "ORDER BY l.id DESC LIMIT ? OFFSET ?",
            [*params, limit, offset],
        ).fetchall()]
    return rows, total


def areas(db: Database) -> list[str]:
    with db.connect() as conn:
        return [r[0] for r in conn.execute("SELECT DISTINCT area FROM gateway_logs ORDER BY area")]


def csv_text(rows: list[dict]) -> str:
    lines = ["Gateway;Adresse;Zeit;Uptime_ms;Level;Bereich;Meldung;Abgeholt"]
    for r in reversed(rows):
        message = r["message"].replace(";", ",").replace("\r", " ").replace("\n", " ")
        lines.append(";".join(str(v) for v in (
            r["gateway_title"], r["host"], r["ts_text"], r["uptime_ms"], r["level"], r["area"], message, r["fetched_at"])))
    return "﻿" + "\r\n".join(lines) + "\r\n"
