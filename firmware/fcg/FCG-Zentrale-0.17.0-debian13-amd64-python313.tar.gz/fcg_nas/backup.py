"""Komplettsicherung und Rücksicherung.

Eine Sicherung ist ein ZIP mit
- fcg_collector.sqlite3: konsistente Kopie über die SQLite-Backup-API, auch
  während der Collector läuft,
- secret.key: ohne ihn lassen sich die gespeicherten Gateway- und
  SMTP-Passwörter nach einer Rücksicherung auf einer neuen NAS nicht lesen,
- backup.json: Version, Schema, Zeitpunkt, Anlass und Zahlen zur Übersicht.

Der Sicherungsordner liegt im Datenordner (Hyper Backup sichert ihn mit) oder
per FCG_BACKUP_DIR auf einer eigenen Freigabe. Wegen secret.key gehört er
nicht in den Exportordner für die Kollegen.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sqlite3
import tempfile
import threading
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from . import __version__
from .db import SCHEMA_VERSION, Database, now_text

log = logging.getLogger("fcg_nas.backup")

DB_NAME = "fcg_collector.sqlite3"
KEY_NAME = "secret.key"
INFO_NAME = "backup.json"
NAME_PATTERN = re.compile(r"^FCG_Sicherung_(\d{4}-\d{2}-\d{2})_(\d{6})_([a-z_]+)\.zip$")
KINDS = {"auto": "nächtlich", "manuell": "von Hand", "vor_update": "vor Update", "vor_ruecksicherung": "vor Rücksicherung"}
KEEP_AT_LEAST = 3
MAX_RESTORE_BYTES = 1024 * 1024 * 1024
REQUIRED_TABLES = {"settings", "users", "gateways", "sites", "entries"}


class BackupError(Exception):
    pass


@dataclass
class BackupFile:
    name: str
    path: Path
    size: int
    created: str
    kind: str

    @property
    def kind_text(self) -> str:
        return KINDS.get(self.kind, self.kind)


@dataclass
class RestoreInfo:
    version: str = ""
    schema: int = 0
    created_at: str = ""
    kind: str = ""
    has_key: bool = False
    counts: dict[str, int] = field(default_factory=dict)
    problems: list[str] = field(default_factory=list)


def _counts(conn: sqlite3.Connection) -> dict[str, int]:
    result = {}
    for table in ("gateways", "sites", "entries", "gateway_logs", "runs"):
        try:
            result[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except sqlite3.Error:
            result[table] = 0
    return result


class BackupService:
    def __init__(self, db: Database, data_dir: Path, backup_dir: Path) -> None:
        self.db = db
        self.data_dir = Path(data_dir)
        self.backup_dir = Path(backup_dir)
        self.key_path = self.data_dir / KEY_NAME
        self._lock = threading.Lock()

    # --- Sichern -----------------------------------------------------------

    def create(self, kind: str) -> BackupFile:
        if kind not in KINDS:
            raise ValueError(kind)
        with self._lock:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now()
            name = f"FCG_Sicherung_{stamp.strftime('%Y-%m-%d_%H%M%S')}_{kind}.zip"
            target = self.backup_dir / name
            with tempfile.TemporaryDirectory(dir=self.backup_dir) as tmp:
                copy = Path(tmp) / DB_NAME
                with self.db.connect() as src:
                    dst = sqlite3.connect(copy)
                    try:
                        src.backup(dst)
                        counts = _counts(dst)
                        schema = dst.execute("PRAGMA user_version").fetchone()[0]
                    finally:
                        dst.close()
                info = {"schema_name": "fcg_nas_backup_v1", "version": __version__, "schema": schema,
                        "created_at": now_text(), "kind": kind, "counts": counts}
                partial = Path(tmp) / (name + ".part")
                with zipfile.ZipFile(partial, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                    zf.write(copy, DB_NAME)
                    if self.key_path.exists():
                        zf.write(self.key_path, KEY_NAME)
                    zf.writestr(INFO_NAME, json.dumps(info, ensure_ascii=False, indent=2))
                os.replace(partial, target)
            os.chmod(target, 0o600)
        log.info("Sicherung angelegt: %s", name)
        return self._entry(target)

    def _entry(self, path: Path) -> BackupFile:
        match = NAME_PATTERN.match(path.name)
        created = f"{match.group(1)} {match.group(2)[:2]}:{match.group(2)[2:4]}:{match.group(2)[4:]}" if match else ""
        return BackupFile(path.name, path, path.stat().st_size, created, match.group(3) if match else "")

    def list(self) -> list[BackupFile]:
        if not self.backup_dir.is_dir():
            return []
        files = [self._entry(p) for p in self.backup_dir.iterdir() if p.is_file() and NAME_PATTERN.match(p.name)]
        return sorted(files, key=lambda f: f.name, reverse=True)

    def path_of(self, name: str) -> Path:
        if not NAME_PATTERN.match(name or ""):
            raise BackupError("Unbekannte Sicherung.")
        path = self.backup_dir / name
        if not path.is_file():
            raise BackupError("Sicherung nicht gefunden.")
        return path

    def prune(self, keep_days: int) -> list[str]:
        """Löscht Sicherungen älter als keep_days; die neuesten drei bleiben immer."""
        limit = (datetime.now() - timedelta(days=keep_days)).strftime("%Y-%m-%d %H:%M:%S")
        removed = []
        for item in self.list()[KEEP_AT_LEAST:]:
            if item.created and item.created < limit:
                item.path.unlink(missing_ok=True)
                removed.append(item.name)
        return removed

    def last_auto_date(self) -> str:
        for item in self.list():
            if item.kind == "auto":
                return item.created[:10]
        return ""

    def due(self, now: datetime | None = None) -> bool:
        now = now or datetime.now()
        settings = self.db.get_settings()
        if settings.get("backup_enabled") != "1":
            return False
        hour = int(settings.get("backup_hour") or 2)
        return now.hour >= hour and self.last_auto_date() < now.strftime("%Y-%m-%d")

    def run_nightly(self) -> str:
        """Nächtliche Sicherung mit Aufräumen. Liefert '' oder den Fehler."""
        try:
            item = self.create("auto")
            removed = self.prune(self.db.get_int_setting("backup_keep_days"))
            summary = f"{item.name} ({item.size // 1024} KB)" + (f", {len(removed)} alte gelöscht" if removed else "")
            self._remember(True, summary)
            return ""
        except (OSError, sqlite3.Error, BackupError) as exc:
            log.exception("Sicherung fehlgeschlagen")
            self._remember(False, str(exc))
            return str(exc)

    def _remember(self, ok: bool, summary: str) -> None:
        self.db.set_settings({"backup_last_at": now_text(), "backup_last_ok": "1" if ok else "0",
                              "backup_last_summary": summary[:500]})

    def problem(self) -> str:
        values = self.db.get_settings()
        if values.get("backup_enabled") != "1":
            return ""
        if values.get("backup_last_ok") == "0":
            return values.get("backup_last_summary", "fehlgeschlagen")
        last = self.last_auto_date()
        if last and last < (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d"):
            return f"Letzte nächtliche Sicherung vom {last}."
        return ""

    # --- Zurücksichern ------------------------------------------------------

    def inspect(self, zip_path: Path, work_dir: Path) -> RestoreInfo:
        """Prüft ein hochgeladenes ZIP und entpackt die Datenbank nach work_dir."""
        info = RestoreInfo()
        try:
            with zipfile.ZipFile(zip_path) as zf:
                names = set(zf.namelist())
                if DB_NAME not in names:
                    raise BackupError("Im ZIP fehlt fcg_collector.sqlite3. Ist das eine Sicherung der FCG Zentrale?")
                unknown = names - {DB_NAME, KEY_NAME, INFO_NAME}
                if unknown:
                    info.problems.append(f"Unbekannte Dateien werden ignoriert: {', '.join(sorted(unknown))}")
                if zf.getinfo(DB_NAME).file_size > MAX_RESTORE_BYTES:
                    raise BackupError("Die Datenbank im ZIP ist unplausibel groß.")
                (work_dir / DB_NAME).write_bytes(zf.read(DB_NAME))
                if KEY_NAME in names:
                    key = zf.read(KEY_NAME)
                    if len(key) > 200:
                        raise BackupError("secret.key im ZIP ist ungültig.")
                    (work_dir / KEY_NAME).write_bytes(key)
                    info.has_key = True
                if INFO_NAME in names:
                    meta = json.loads(zf.read(INFO_NAME).decode("utf-8"))
                    info.version = str(meta.get("version", ""))
                    info.created_at = str(meta.get("created_at", ""))
                    info.kind = str(meta.get("kind", ""))
        except zipfile.BadZipFile as exc:
            raise BackupError("Die Datei ist kein gültiges ZIP.") from exc
        except (ValueError, KeyError) as exc:
            raise BackupError(f"backup.json im ZIP ist ungültig: {exc}") from exc
        try:
            conn = sqlite3.connect(f"file:{work_dir / DB_NAME}?mode=ro", uri=True)
            try:
                check = conn.execute("PRAGMA integrity_check").fetchone()[0]
                if check != "ok":
                    raise BackupError(f"Die Datenbank im ZIP ist beschädigt: {check}")
                tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
                missing = REQUIRED_TABLES - tables
                if missing:
                    raise BackupError(f"Die Datenbank im ZIP ist keine Collector-Datenbank (fehlt: {', '.join(sorted(missing))}).")
                info.schema = conn.execute("PRAGMA user_version").fetchone()[0]
                info.counts = _counts(conn)
            finally:
                conn.close()
        except sqlite3.DatabaseError as exc:
            raise BackupError(f"Die Datei im ZIP ist keine lesbare SQLite-Datenbank: {exc}") from exc
        if info.schema > SCHEMA_VERSION:
            raise BackupError(f"Die Sicherung hat Schema {info.schema}, diese Version kennt nur {SCHEMA_VERSION}. "
                              "Erst den Collector aktualisieren.")
        if not info.has_key:
            info.problems.append("Ohne secret.key bleiben die gespeicherten Gateway- und SMTP-Passwörter nur lesbar, "
                                 "wenn die Sicherung von dieser NAS stammt.")
        return info

    def restore(self, work_dir: Path) -> BackupFile:
        """Spielt eine geprüfte Sicherung ein. Vorher wird der jetzige Stand gesichert."""
        safety = self.create("vor_ruecksicherung")
        with self._lock:
            src = sqlite3.connect(work_dir / DB_NAME)
            try:
                with self.db.connect() as dst:
                    src.backup(dst)
            finally:
                src.close()
            key = work_dir / KEY_NAME
            if key.exists():
                partial = self.key_path.with_suffix(".key.part")
                partial.write_bytes(key.read_bytes())
                os.chmod(partial, 0o600)
                os.replace(partial, self.key_path)
        self.db.migrate()
        log.warning("Rücksicherung eingespielt, vorheriger Stand in %s", safety.name)
        return safety
