"""Public first-use credentials for new appliances, never reset on updates."""
WEB_USER = 'admin'
WEB_PASSWORD = 'FCGStart2026'
CONSOLE_USER = 'fcgadmin'
CONSOLE_PASSWORD = 'FCGKonsole2026'
MIN_NEW_PASSWORD = 8
