#!/usr/bin/env python3
"""Root-owned fixed-purpose worker. Never import code writable by the web service.

The web account cannot reset a privileged Linux password merely by forging a
request or changing its own database. Every operation reauthenticates against
root-owned /etc/shadow, independently of the application account.
"""
import ctypes
from datetime import datetime, timezone
import fcntl
import hmac
import json
import os
from pathlib import Path
import pwd
import stat
import subprocess
import sys
import tempfile
import time

from vm_defaults import CONSOLE_USER, CONSOLE_PASSWORD
from password_policy import check_new_password, PASSWORD_RULE

ROOT = Path('/var/lib/fcg-access')


def atomic(path, data, mode=0o600):
    fd, name = tempfile.mkstemp(prefix='.state-', dir=path.parent)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, 'w') as handle:
            json.dump(data, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def valid_password(value, *, new=False):
    if not isinstance(value, str) or not value or len(value) > 128 or any(c in value for c in '\r\n\x00'):
        raise ValueError('Passwort fehlt oder enthält unzulässige Zeichen.')
    if new:
        if value == CONSOLE_PASSWORD:raise ValueError('Das neue Linux-Passwort muss sich vom bisherigen unterscheiden.')
        check_new_password(value)
    return value


def crypt_library():
    library = ctypes.CDLL('libcrypt.so.1')
    library.crypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    library.crypt.restype = ctypes.c_char_p
    return library


class Linux:
    def run(self, *args, input=None):
        return subprocess.run(args, input=input, text=True, capture_output=True, check=True).stdout.strip()

    def machine_id(self):
        return Path("/etc/machine-id").read_text().strip()

    def shadow(self):
        for line in Path('/etc/shadow').read_text().splitlines():
            fields = line.split(':')
            if fields[0] == CONSOLE_USER:
                return fields
        raise ValueError('Linux-Konto ist nicht vorhanden.')

    def matches(self, password):
        stored = self.shadow()[1]
        if not stored or stored.startswith(('!', '*')):
            return False
        library = crypt_library()
        result = library.crypt(password.encode('utf-8'), stored.encode('ascii'))
        return bool(result) and hmac.compare_digest(result, stored.encode('ascii'))

    def needs_change(self):
        return self.shadow()[2] in ('', '0') or self.matches(CONSOLE_PASSWORD)

    def ssh_enabled(self):
        return any(subprocess.run(['/usr/bin/systemctl', 'is-active', '--quiet', name]).returncode == 0
                   for name in ('ssh.service', 'ssh.socket'))

    def set_password(self, password):
        self.run('/usr/sbin/chpasswd', input=CONSOLE_USER + ':' + password + '\n')

    def set_ssh(self, enabled):
        if self.run('/usr/bin/systemctl', 'show', 'ssh.socket', '-p', 'LoadState', '--value') != 'not-found':
            self.run('/usr/bin/systemctl', 'disable', '--now', 'ssh.socket')
        self.run('/usr/bin/systemctl', 'enable' if enabled else 'disable', '--now', 'ssh.service')


def process(value, linux, root=ROOT, now=None):
    now = time.time() if now is None else now
    action = value.get('action')
    if action not in ('password', 'ssh', 'refresh'):
        raise ValueError('Unbekannte Systemaktion.')
    if action == 'ssh' and not isinstance(value.get('enabled'), bool):
        raise ValueError('Ungültige SSH-Einstellung.')
    if action == 'password':
        valid_password(value.get('password'), new=True)
    password = valid_password(value.get('current_password'))
    authfile = root / 'private/auth.json'
    try:
        attempts = json.loads(authfile.read_text())
    except FileNotFoundError:
        attempts = {}
    if float(attempts.get('until', 0)) > now:
        raise ValueError('Linux-Anmeldung vorübergehend gesperrt; nach fünf Minuten erneut versuchen.')
    if not linux.matches(password):
        failures = int(attempts.get('failed', 0)) + 1
        atomic(authfile, {'failed': failures, 'until': now + 300 if failures >= 5 else 0})
        raise ValueError('Aktuelles Linux-Konsolenpasswort ist falsch.')
    atomic(authfile, {'failed': 0, 'until': 0})
    if action == 'password':
        if hmac.compare_digest(password.encode(), value['password'].encode()):
            raise ValueError('Das neue Linux-Passwort muss sich vom bisherigen unterscheiden.')
        linux.set_password(value['password'])
        return 'Linux-Konsolen- und SSH-Passwort geändert.'
    if action == 'ssh':
        if value['enabled'] and linux.needs_change():
            raise ValueError('Vor dem Einschalten von SSH zuerst ein eigenes Linux-Passwort setzen.')
        linux.set_ssh(value['enabled'])
        return 'SSH eingeschaltet.' if value['enabled'] else 'SSH ausgeschaltet.'
    return 'Linux-Zugangsstatus aktualisiert.'


def write_status(linux, root, **result):
    result.update(at=datetime.now(timezone.utc).isoformat(), machine_id=linux.machine_id(), ssh_enabled=linux.ssh_enabled(),
                  password_change_required=linux.needs_change())
    atomic(root / 'status.json', result, 0o644)


def consume(root=ROOT, expected_uid=None, linux=None):
    linux = linux or Linux()
    expected_uid = pwd.getpwnam('fcg').pw_uid if expected_uid is None else expected_uid
    request = root / 'inbox/request.json'
    with (root / 'private/worker.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        fd = None
        value = {}
        try:
            fd = os.open(request, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != expected_uid or info.st_nlink != 1 or info.st_size > 4096 or info.st_mode & 0o077:
                raise ValueError('Ungültige Systemanforderung.')
            with os.fdopen(fd, 'rb') as handle:
                fd = None
                raw = handle.read(4097)
                if len(raw) > 4096:
                    raise ValueError('Ungültige Systemanforderung.')
                value = json.loads(raw)
            if not isinstance(value, dict):
                raise ValueError('Ungültige Systemanforderung.')
            request.unlink(missing_ok=True)  # never retain passwords after consumption
            message = process(value, linux, root)
            write_status(linux, root, id=str(value.get('id', ''))[:32], ok=True, message=message)
        except (ValueError, OSError, subprocess.SubprocessError) as exc:
            # No command output, request data, hashes or passwords in public status/logs.
            # Log only fixed executable names, numeric error codes and whitelisted
            # system errors. Never emit raw subprocess output or request contents.
            diagnostic = type(exc).__name__
            if isinstance(exc, subprocess.CalledProcessError):
                executable = Path(exc.cmd[0]).name
                diagnostic += ':' + executable + ':' + str(exc.returncode)
                for phrase, code in [('Authentication token manipulation error', 'pam_token_error'),
                                     ('Permission denied', 'permission_denied'), ('cannot lock', 'lock_error')]:
                    if phrase in (exc.stderr or ''):diagnostic += ':' + code
            elif isinstance(exc, OSError):
                diagnostic += ':errno=' + str(exc.errno)
            print('FCG access failure: ' + diagnostic, file=sys.stderr)
            request.unlink(missing_ok=True)
            safe = ('Aktuelles Linux-Konsolenpasswort ist falsch.', 'Vor dem Einschalten von SSH zuerst ein eigenes Linux-Passwort setzen.', 'Linux-Anmeldung vorübergehend gesperrt; nach fünf Minuten erneut versuchen.', 'Das neue Linux-Passwort muss sich vom bisherigen unterscheiden.', PASSWORD_RULE)
            message = str(exc) if isinstance(exc, ValueError) and str(exc) in safe else 'Systemaktion fehlgeschlagen. Linux-Passwort, Erstwechsel und mögliche Anmeldesperre prüfen.'
            write_status(linux, root, id=str(value.get('id', ''))[:32] if isinstance(value, dict) else '', ok=False, message=message)
        finally:
            if fd is not None:
                os.close(fd)


if __name__ == '__main__':
    if os.geteuid() != 0:
        raise SystemExit('Root required.')
    if sys.argv[1:] == ['--status']:
        write_status(Linux(), ROOT, ok=True, message='Linux-Zugangsstatus bereit.')
    elif not sys.argv[1:]:
        consume()
    else:
        raise SystemExit('Invalid command.')
