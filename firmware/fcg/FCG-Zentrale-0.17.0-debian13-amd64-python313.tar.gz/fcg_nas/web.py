"""Webseite und JSON-Status des NAS-Collectors.

Start im Container: uvicorn --factory fcg_nas.web:create_app
"""
from __future__ import annotations

import hmac
import base64
import json
import ipaddress
import logging
import math
import re
import shutil
import sqlite3
import sys
import tempfile
import time
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.parse import quote

from starlette.datastructures import UploadFile as StarletteUploadFile

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import __version__
from . import backup as backup_mod
from . import exporter as export_mod
from . import gateway_import, gatewaylogs, importer
from . import mailer as mail_mod
from . import ota as ota_mod
from . import statistics as stats
from .alerts import LEVEL_TEXT, Alerts, Problem, log_error_problems, silence_problems, storage_problems
from .auth import ADMIN_USER, READER_USER, SESSION_SECONDS, AuthService, LoginLocked, Session, check_new_password
from .collector import Collector
from .config import AppConfig, load_config
from .db import SCHEMA_VERSION, Database, now_text
from .history import counter_snapshots, undated_entries
from .guest import GUEST_PATHS, GUEST_AREAS, guest_allowed, path_allowed as guest_path_allowed, permissions as guest_permissions, entry_path as guest_entry_path, networks as guest_networks
from . import i18n, help_docs
from jinja2 import pass_context
from .gateway_client import (FetchFn, GatewayAuth, GatewayError, JsonFn, PostFn, TextFn, fetch_collector_page,
                             http_get_json, http_get_text, http_post_json, normalize_host)
from .gateway_update import MAX_PARALLEL as MAX_PARALLEL_UPDATES, GatewayUpdater
from .live import LiveMonitor
from .report import DailyReport
from .scheduler import Housekeeper, Scheduler
from .secrets_store import SecretStore

log = logging.getLogger("fcg_nas.web")

PACKAGE_DIR = Path(__file__).resolve().parent
SESSION_COOKIE = "fcg_session"

# Warnungen ohne Gateway im Text: wohin der Link "→ …" führt.
ALERT_PAGES = {"ota_pending": ("/admin/ota", "Firmware"), "ota_check": ("/admin/ota", "Firmware"),
               "export": ("/export", "Export"), "backup": ("/admin/backup", "Sicherung"), "disk": ("/info", "Info"),
               "selfupdate": ("/info", "Info")}
FIRMWARE_ALERT_KEYS = ("ota_pending", "ota_check")

# Rückmeldungen nach Redirects; nur feste Texte, nichts aus der URL wird angezeigt.
FLASH = {
    "vm_access_queued": ("ok", "Systemaktion angefordert; Ergebnis nach wenigen Sekunden prüfen."),
    "run_started": ("ok", "Abholung gestartet."),
    "run_busy": ("warn", "Es läuft bereits eine Abholung."),
    "gw_added": ("ok", "Gateway angelegt."),
    "gw_saved": ("ok", "Gateway gespeichert."),
    "gw_deleted": ("ok", "Gateway entfernt. Die abgeholten Daten bleiben erhalten."),
    "settings_saved": ("ok", "Einstellungen gespeichert."),
    "reader_saved": ("ok", "Passwort für das Benutzer-Konto (user) gespeichert."),
    "gw_admin_saved": ("ok", "Gateway-Admin gespeichert. Firmware-Updates nehmen ihn, wenn die Felder leer bleiben."),
    "gw_admin_cleared": ("ok", "Gespeicherten Gateway-Admin gelöscht."),
    "admin_saved": ("ok", "Admin-Passwort geändert. Bitte neu anmelden."),
    "logged_out": ("ok", "Abgemeldet."),
    "export_done": ("ok", "Export in den Freigabeordner abgeschlossen."),
    "export_failed": ("err", "Export in den Freigabeordner mit Fehlern, Details unter Automatischer Export."),
    "import_done": ("ok", "Import abgeschlossen. Ergebnis unter Letzte Importe."),
    "import_expired": ("err", "Die Vorschau ist abgelaufen. Bitte die Dateien erneut hochladen."),
    "gw_imported": ("ok", "Gateway-Liste übernommen."),
    "alert_settings_saved": ("ok", "Einstellungen für Warnungen und Mail gespeichert."),
    "mail_sent": ("ok", "Testmail gesendet. Bitte im Postfach nachsehen."),
    "backup_done": ("ok", "Sicherung angelegt."),
    "backup_settings_saved": ("ok", "Einstellungen für die Sicherung gespeichert."),
    "restored": ("ok", "Rücksicherung eingespielt. Bitte mit den Zugangsdaten aus der Sicherung neu anmelden."),
    "ota_settings_saved": ("ok", "Einstellungen für den OTA-Spiegel gespeichert."),
    "ota_published": ("ok", "Firmware freigegeben. Die Gateways finden sie bei ihrer nächsten Prüfung."),
    "ota_rejected": ("ok", "Version wird nicht bereitgestellt."),
    "report_sent": ("ok", "Tagesbericht gesendet. Bitte im Postfach nachsehen."),
    "alert_acked": ("ok", "Warnung quittiert. Sie meldet sich wieder, wenn sie sich ändert oder schlimmer wird."),
    "alert_unacked": ("ok", "Quittierung zurückgenommen."),
    "alert_gone": ("warn", "Diese Warnung ist schon geschlossen."),
    "gw_update_started": ("ok", "Update gestartet. Die Gateways werden in Gruppen aktualisiert (Einstellung unten), der Stand steht unten."),
}

SETTING_LIMITS = {
    "poll_interval_min": ("Abrufintervall (Minuten)", 1, 1440),
    "limit": ("Einträge pro Abruf", 1, 100),
    "timeout_sec": ("Timeout (Sekunden)", 5, 600),
    "offline_after_min": ("Offline nach (Minuten)", 1, 10080),
}
LIVE_LIMITS = {
    "fueling_window_min": ("Wird befüllt: Impuls in den letzten (Minuten)", 1, 120),
    "live_interval_sec": ("Livewerte abfragen alle (Sekunden)", 10, 600),
    "log_retention_days": ("Gateway-Logs aufbewahren (Tage)", 7, 3650),
}
ACCESS_LIMITS = {
    "dashboard_refresh_sec": ("Hallenanzeige neu laden alle (Sekunden)", 10, 3600),
}
LOGS_PER_PAGE = 200


STATS_FLAGS = {
    "stats_cutoff_month": "Stichtagsmonat",
    "stats_calendar_month": "Kalendermonat",
    "stats_annual": "Jahr",
    "stats_include_open": "Laufenden Zeitraum mit ausgeben (_offen)",
    "stats_per_site": "Berichte je Messstelle",
    "stats_overall": "Gesamtbericht aller Messstellen",
    "export_enabled": "Nach jeder Abholung automatisch in den Freigabeordner exportieren",
}
POLICY_TEXT = {
    "skip_closed_overwrite_open": "Offene Zeiträume aktualisieren, abgeschlossene nicht mehr ändern (Standard)",
    "overwrite": "Immer überschreiben",
    "versioned": "Bei Abweichung neue Datei mit Zeitstempel",
    "skip": "Vorhandene Berichte nie ändern",
}
SOURCE_TEXT = {
    "api": "Gateway",
    "legacy_delta": "Differenz",
    "legacy_reset_unknown": "unbekannt (Zähler kleiner)",
    "first_unknown": "unbekannt (erster Eintrag)",
    "import": "Import",
    "import_unknown": "Import, unbekannt",
}
CHART_DAYS = (30, 90, 365)
ENTRIES_PER_PAGE = 100


class NeedLogin(Exception):
    pass


class NeedAdmin(Exception):
    pass


class AdminOnlyInLan(Exception):
    pass


def _ip(text: str):
    try:
        return ipaddress.ip_address(text.strip().strip('"').strip("[]"))
    except ValueError:
        return None


def client_addresses(request: Request) -> list[str]:
    """Adresse des Browsers und alle Adressen, die ein Reverse-Proxy weitergereicht hat."""
    found = [request.client.host] if request.client else []
    for header in ("x-forwarded-for", "x-real-ip"):
        found += [part.strip() for part in request.headers.get(header, "").split(",") if part.strip()]
    for part in request.headers.get("forwarded", "").replace(";", ",").split(","):
        key, _, value = part.strip().partition("=")
        if key.lower() == "for" and value:
            found.append(value.split("]:")[0].lstrip("[") if value.startswith(("[", '"[')) else value.split(":")[0])
    return found


def is_external(request: Request) -> bool:
    """True, wenn eine beteiligte Adresse nicht aus dem LAN stammt (Zugriff über das Internet)."""
    for text in client_addresses(request):
        address = _ip(text)
        if address is not None and not (address.is_private or address.is_loopback or address.is_link_local):
            return True
    return False


def setup_logging(config: AppConfig) -> None:
    root = logging.getLogger()
    if any(getattr(h, "_fcg", False) for h in root.handlers):
        return
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    try:
        config.log_dir.mkdir(parents=True, exist_ok=True)
        handlers.append(RotatingFileHandler(config.log_dir / "collector.log", maxBytes=1_000_000, backupCount=5, encoding="utf-8"))
    except OSError:
        pass
    for handler in handlers:
        handler.setFormatter(formatter)
        handler._fcg = True  # type: ignore[attr-defined]
        root.addHandler(handler)
    root.setLevel(logging.INFO)


def format_number(value, digits: int = 1) -> str:
    """Deutsche Zahl: 12.345,6"""
    if value is None:
        return "–"
    text = f"{float(value):,.{digits}f}"
    return text.replace(",", "_").replace(".", ",").replace("_", ".")


def format_decimal(value) -> str:
    """Zahl ohne überflüssige Nachkommastellen: 100, 100,5, 0,125"""
    if value is None:
        return "–"
    text = f"{float(value):,.4f}".rstrip("0").rstrip(".")
    return text.replace(",", "_").replace(".", ",").replace("_", ".")


def _parse_time(text: str | None) -> datetime | None:
    if not text:
        return None
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def gateway_status(row: sqlite3.Row, offline_after_min: int) -> tuple[str, str]:
    """(css-Klasse, Text) für die Statusanzeige eines Gateways."""
    if not row["enabled"]:
        return "dim", "deaktiviert"
    if not row["last_attempt_at"]:
        return "dim", "noch nicht abgeholt"
    last_ok = _parse_time(row["last_ok_at"])
    last_attempt = _parse_time(row["last_attempt_at"])
    if row["last_error"] and (last_ok is None or (last_attempt and last_attempt > last_ok)):
        return "err", "Fehler"
    if last_ok and datetime.now() - last_ok > timedelta(minutes=offline_after_min):
        return "warn", "offline"
    return "ok", "online"


def nice_ticks(maximum: float, count: int = 4) -> list[float]:
    """Runde Achsenwerte von 0 bis über das Maximum."""
    if maximum <= 0:
        return [0.0, 1.0]
    magnitude = 10 ** math.floor(math.log10(maximum / count))
    step = next(magnitude * f for f in (1, 2, 2.5, 5, 10) if magnitude * f * count >= maximum)
    return [round(step * i, 6) for i in range(count + 1) if step * (i - 1) < maximum]


def daily_chart(days: list[tuple[date, float, int, int]], lang: str = "de") -> dict:
    """Geometrie für das Balkendiagramm (SVG, ohne Skript): (Tag, Liter, Einträge, unbekannt)."""
    def number(value, digits=1):
        return format_number(value, digits) if lang == "de" else f"{float(value):,.{digits}f}"

    width, height = 960, 240
    left, right, top, bottom = 56, 8, 12, 28
    plot_w, plot_h = width - left - right, height - top - bottom
    ticks = nice_ticks(max([d[1] for d in days] + [0.0]))
    y_max = ticks[-1] or 1.0
    slot = plot_w / max(1, len(days))
    bar_w = max(1.0, slot - 2)  # 2 px Abstand zwischen den Balken
    bars = []
    for index, (day, liter, count, unknown) in enumerate(days):
        h = plot_h * liter / y_max
        x = left + index * slot + (slot - bar_w) / 2
        y = top + plot_h - h
        r = min(4.0, bar_w / 2, h)
        path = ""
        if h > 0:
            # oben abgerundet, unten bündig auf der Grundlinie
            path = (f"M{x:.1f},{top + plot_h:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} "
                    f"H{x + bar_w - r:.1f} Q{x + bar_w:.1f},{y:.1f} {x + bar_w:.1f},{y + r:.1f} V{top + plot_h:.1f} Z")
        tip = f"{day.strftime('%d.%m.%Y')}: {number(liter, 1)} l"
        if count:
            tip += f", {count} " + i18n.translate("Einträge", lang)
        if unknown:
            tip += i18n.translate(", davon {count} mit unbekanntem Verbrauch", lang).format(count=unknown)
        bars.append({"path": path, "tip": tip, "hit_x": left + index * slot, "hit_w": slot, "unknown": unknown and not h,
                     "cx": x + bar_w / 2})
    labels = []
    if days:
        last = len(days) - 1
        for index in sorted({0, len(days) // 2, last}):
            # Rand-Beschriftungen bündig, damit sie nicht abgeschnitten werden
            anchor = "start" if index == 0 and last else "end" if index == last and last else "middle"
            x = left if anchor == "start" else width - right if anchor == "end" else left + index * slot + slot / 2
            labels.append({"x": x, "text": days[index][0].strftime("%d.%m.%Y"), "anchor": anchor})
    grid = [{"y": top + plot_h - plot_h * t / y_max, "text": number(t, 0 if y_max >= 10 else 1)} for t in ticks]
    return {"width": width, "height": height, "left": left, "right": width - right, "top": top,
            "base": top + plot_h, "bars": bars, "labels": labels, "grid": grid}


def _bar_path(x: float, y: float, w: float, base: float) -> str:
    """Balken oben abgerundet, unten bündig auf der Grundlinie."""
    h = base - y
    if h <= 0:
        return ""
    r = min(4.0, w / 2, h)
    return (f"M{x:.1f},{base:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} "
            f"H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} V{base:.1f} Z")


def compare_chart(buckets: list[stats.Bucket], previous: list[stats.Bucket] | None, granularity: str,
                  unit: str = "l", lang: str = "de") -> dict:
    """Verlauf im Zeitraum, mit Vergleich als zweitem Balken je Abschnitt (SVG, ohne Skript)."""
    def number(value, digits=1):
        return format_number(value, digits) if lang == "de" else f"{float(value):,.{digits}f}"

    width, height = 960, 260
    left, right, top, bottom = 56, 8, 12, 28
    plot_w, plot_h = width - left - right, height - top - bottom
    base = top + plot_h
    count = max(len(buckets), len(previous or []), 1)
    values = [b.liter for b in buckets] + [b.liter for b in previous or []]
    ticks = nice_ticks(max(values + [0.0]))
    y_max = ticks[-1] or 1.0
    slot = plot_w / count
    gap = 2 if slot > 6 else 0.5
    bar_w = max(1.0, (slot - gap * 2) / (2 if previous else 1))
    bars = []
    for index in range(count):
        cur = buckets[index] if index < len(buckets) else None
        prev = previous[index] if previous and index < len(previous) else None
        x0 = left + index * slot + gap
        tip = []
        if cur:
            tip.append(f"{cur.label(granularity)} ({cur.start.strftime('%d.%m.%Y')} {i18n.translate('bis', lang)} {cur.end.strftime('%d.%m.%Y')}): "
                       f"{number(cur.liter, 1)} {unit}")
            if cur.unknown:
                tip.append(i18n.translate("{count} Einträge mit unbekanntem Verbrauch", lang).format(count=cur.unknown))
            if cur.anomalies:
                tip.append(i18n.translate("{count} auffällige(r) Tag(e)", lang).format(count=cur.anomalies))
        if prev:
            text = f"{i18n.translate('Vergleich', lang)} {prev.start.strftime('%d.%m.%Y')} {i18n.translate('bis', lang)} {prev.end.strftime('%d.%m.%Y')}: {number(prev.liter, 1)} {unit}"
            change = stats.percent_change(cur.liter, prev.liter) if cur else None
            if change is not None:
                text += f" ({'+' if change >= 0 else ''}{number(change, 0)} %)"
            tip.append(text)
        bar = {"hit_x": left + index * slot, "hit_w": slot, "tip": "\n".join(tip), "cur": "", "prev": "",
               "anomaly": bool(cur and cur.anomalies), "unknown": bool(cur and cur.unknown and cur.liter <= 0),
               "cx": x0 + bar_w / 2}
        if prev:
            bar["prev"] = _bar_path(x0, base - plot_h * max(0.0, prev.liter) / y_max, bar_w, base)
            x0 += bar_w
            bar["cx"] = x0 + bar_w / 2
        if cur:
            bar["cur"] = _bar_path(x0, base - plot_h * max(0.0, cur.liter) / y_max, bar_w, base)
        bars.append(bar)
    labels = []
    if buckets:
        last = len(buckets) - 1
        for index in sorted({0, len(buckets) // 2, last}):
            anchor = "start" if index == 0 and last else "end" if index == last and last else "middle"
            x = left if anchor == "start" else width - right if anchor == "end" else left + index * slot + slot / 2
            labels.append({"x": x, "text": buckets[index].label(granularity), "anchor": anchor})
    grid = [{"y": base - plot_h * t / y_max, "text": number(t, 0 if y_max >= 10 else 1)} for t in ticks]
    return {"width": width, "height": height, "left": left, "right": width - right, "top": top,
            "base": base, "bars": bars, "labels": labels, "grid": grid}


def create_app(config: AppConfig | None = None, fetch: FetchFn | None = None, get_json: JsonFn | None = None,
               get_text: TextFn | None = None, download: ota_mod.DownloadFn | None = None,
               send_mail: mail_mod.SendFn | None = None, post_json: PostFn | None = None,
               updater: GatewayUpdater | None = None) -> FastAPI:
    config = config or load_config()
    setup_logging(config)
    db = Database(config.db_path)
    backups = backup_mod.BackupService(db, config.data_dir, config.backups_dir)
    old_schema = db.schema_version()
    if 0 < old_schema < SCHEMA_VERSION:
        # Vor jeder Schema-Änderung den alten Stand sichern.
        backups.create("vor_update")
    db.migrate()
    secrets = SecretStore(config.secret_key_path)
    from .vm_defaults import WEB_PASSWORD
    from . import vm_access
    if config.deployment == 'vm':
        from .vm_runtime import request_sync
        request_sync(force=True)
    auth = AuthService(db, WEB_PASSWORD)
    generated = auth.ensure_admin(config.initial_admin_password or WEB_PASSWORD)
    if generated:
        log.warning("Erstes Admin-Passwort (Konto 'admin'): %s  -> bitte unter Verwaltung > Konten ändern.", generated)
    get_json = get_json or http_get_json
    get_text = get_text or http_get_text
    collector = Collector(db, secrets, fetch or fetch_collector_page, get_json)
    live = LiveMonitor(db, get_json)
    export_mod.ensure_all_stems(db)
    exporter = export_mod.Exporter(db, config.export_dir)
    collector.after_run.append(exporter.after_run)
    mailer = mail_mod.Mailer(db, secrets, send_mail or mail_mod.send_smtp)
    ota = ota_mod.OtaMirror(db, config.ota_cache_dir, config.ota_dir, download or ota_mod.download)
    from .central_updates import CentralUpdates, installed_release
    central_updates = CentralUpdates(db, download or ota_mod.download, config.deployment)
    alerts = Alerts(db, mailer, config.data_dir)

    def export_problem() -> dict:
        if db.get_settings().get("export_enabled") != "1":
            return {}
        last = exporter.last_result()
        problem = exporter.folder_problem() or (last["summary"] if last["ok"] == "0" else "")
        return {"export": problem} if problem else {}

    alerts.sources += [export_problem, lambda: {"backup": backups.problem()}, ota.problems,
                       lambda: storage_problems(db, live), lambda: silence_problems(db), lambda: log_error_problems(db)]
    report = DailyReport(db, mailer, alerts.open_alerts)
    updater = updater or GatewayUpdater(db, get_json, post_json or http_post_json)
    updater.publication_lock = ota._lock
    updater.published_version = lambda: ota.published().version
    ota.deployment_busy = lambda: updater.running
    collector.after_run.append(lambda _added: alerts.evaluate())
    housekeeper = Housekeeper(backups, ota, alerts, extra=[("Tagesbericht", report.tick)])
    staging = importer.Staging(config.import_dir)
    gw_staging = importer.Staging(config.import_dir / "gateways")
    scheduler = Scheduler(db, collector)
    log.info("NAS-Collector V%s gestartet, Datenbank-Schema %s, Daten in %s", __version__, SCHEMA_VERSION, config.data_dir)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        if config.start_scheduler:
            scheduler.start()
            live.start()
            housekeeper.start()
        yield
        scheduler.stop()
        live.stop()
        housekeeper.stop()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.db = db
    app.state.auth = auth
    app.state.collector = collector
    app.state.secrets = secrets
    app.state.exporter = exporter
    app.state.live = live
    app.state.backups = backups
    app.state.ota = ota
    app.state.central_updates = central_updates
    app.state.updater = updater
    app.state.report = report
    app.state.alerts = alerts
    app.state.mailer = mailer
    app.state.housekeeper = housekeeper
    app.mount("/static", StaticFiles(directory=PACKAGE_DIR / "static"), name="static")
    templates = Jinja2Templates(directory=PACKAGE_DIR / "templates")
    templates.env.filters["num"] = format_number
    templates.env.filters["dec"] = format_decimal
    templates.env.filters["bytes"] = format_bytes

    templates.env.filters["tr"] = i18n.translated

    @pass_context
    def localized_number(context, value, digits=1):
        if context.get("lang", "de") == "de":
            return format_number(value, digits)
        return "–" if value is None else f"{float(value):,.{digits}f}"

    templates.env.filters["num"] = localized_number

    @pass_context
    def localized_decimal(context, value):
        if context.get("lang", "de") == "de":
            return format_decimal(value)
        return "–" if value is None else f"{float(value):,.4f}".rstrip("0").rstrip(".")

    templates.env.filters["decimal"] = localized_decimal

    # --- Hilfen ----------------------------------------------------------

    def current(request: Request, admin: bool = False) -> Session:
        session = auth.session(request.cookies.get(SESSION_COOKIE))
        if session is None:
            if (not admin and request.method == "GET" and request.url.path in GUEST_PATHS
                    and guest_allowed(request, db.get_settings())):
                if not guest_path_allowed(request.url.path, db.get_settings()):
                    raise HTTPException(status_code=403, detail="Dieser Bereich ist für Gäste nicht freigegeben.")
                return Session(token="", username="Gast", role="guest", csrf="")
            raise NeedLogin()
        if admin and not session.is_admin:
            raise NeedAdmin()
        if session.is_admin and db.get_settings().get("admin_lan_only") == "1" and is_external(request):
            raise AdminOnlyInLan()
        return session

    def check_csrf(session: Session, token: str) -> None:
        if not hmac.compare_digest(session.csrf, token or ""):
            raise HTTPException(status_code=400, detail="Formular abgelaufen. Seite neu laden und erneut versuchen.")

    def render(request: Request, name: str, session: Session | None, status_code: int = 200, **context) -> HTMLResponse:
        lang = i18n.language(request)
        flash = FLASH.get(request.query_params.get("m", ""))
        context.setdefault("message", None)
        if context["message"] is None and flash:
            context["message"] = flash
        guest = bool(session and session.role == "guest")
        if lang != "de":
            if "gateways" in context:
                context["gateways"] = [{**g, "live": i18n.localized_live(g.get("live"), lang)} for g in context["gateways"]]
            if "live" in context:
                context["live"] = i18n.localized_live(context["live"], lang)
        current_alerts = alerts.open_alerts() if session and not guest else []
        firmware_alert = bool(session and session.is_admin
                              and any(a["key"] in FIRMWARE_ALERT_KEYS for a in current_alerts))
        return templates.TemplateResponse(
            request,
            name,
            {"session": session, "version": __version__, "schema": SCHEMA_VERSION, "deployment": config.deployment,
             "alert_count": len(current_alerts), "firmware_alert": firmware_alert,
             "custom_logo": bool(db.get_settings().get("brand_logo")), "guest": guest,
             "guest_available": guest_allowed(request, db.get_settings()),
             "guest_permissions": guest_permissions(db.get_settings()),
             "guest_entry_path": guest_entry_path(db.get_settings()),
             "lang": lang, "languages": {k: v["name"] for k, v in i18n.catalogs().items()},
             "t": lambda text: i18n.translate(text, lang),
             "help_summary": lambda topic: help_docs.summary(topic, lang),
             "field_help": lambda name: help_docs.field_summary(name, lang),
             "return_to": request.url.path + ("?" + request.url.query if request.url.query else ""), **context},
            status_code=status_code,
        )

    def redirect(path: str, flash: str | None = None) -> RedirectResponse:
        target = f"{path}?m={flash}" if flash else path
        return RedirectResponse(target, status_code=303)

    def gateway_rows() -> list[dict]:
        offline_after = db.get_int_setting("offline_after_min")
        today = datetime.now().strftime("%Y-%m-%d")
        with db.connect() as conn:
            rows = conn.execute(
                """
                SELECT g.*,
                  (SELECT total_quantity FROM entries e WHERE e.site_id = g.site_id ORDER BY seq DESC LIMIT 1) AS last_total,
                  (SELECT ts FROM entries e WHERE e.site_id = g.site_id ORDER BY seq DESC LIMIT 1) AS last_ts,
                  (SELECT SUM(consumed_quantity) FROM entries e WHERE e.site_id = g.site_id AND e.entry_date = ?) AS today,
                  (SELECT COUNT(*) FROM entries e WHERE e.site_id = g.site_id) AS entry_count
                FROM gateways g
                ORDER BY lower(COALESCE(NULLIF(g.label, ''), NULLIF(g.counter_name, ''), g.host))
                """,
                (today,),
            ).fetchall()
        result = []
        published_fw = ota.published().version
        for row in rows:
            item = dict(row)
            item["status_class"], item["status_text"] = gateway_status(row, offline_after)
            item["title"] = row["label"] or row["counter_name"] or row["host"]
            item["live"] = live.view(row["id"]) if row["enabled"] else None
            item["fw_update"] = (published_fw if published_fw and row["fw_version"]
                                 and ota_mod.version_key(row["fw_version"]) < ota_mod.version_key(published_fw) else "")
            result.append(item)
        return result

    def run_state_json() -> dict:
        state = collector.state()
        next_due_in = None
        if state.next_due_at is not None and not state.running:
            next_due_in = max(0, int(state.next_due_at - time.time()))
        return {
            "version": __version__,
            "running": state.running,
            "run_id": state.run_id,
            "trigger": state.trigger,
            "started_at": state.started_at,
            "gateways_total": state.gateways_total,
            "gateways_done": state.gateways_done,
            "current_host": state.current_host,
            "added": state.added,
            "last_finished_at": state.last_finished_at,
            "last_status": state.last_status,
            "next_due_in_s": next_due_in,
        }

    def read_gateway_form(host: str, label: str, username: str) -> tuple[str, str, str]:
        clean_host = normalize_host(host)
        clean_label = label.strip()[:80]
        clean_user = username.strip()[:64]
        return clean_host, clean_label, clean_user

    # --- Fehlerbehandlung --------------------------------------------------

    @app.exception_handler(NeedLogin)
    async def _need_login(request: Request, _exc: NeedLogin):
        if request.url.path.startswith("/api/"):
            return JSONResponse({"error": "login_required"}, status_code=401)
        return RedirectResponse(f"/login?next={quote(request.url.path)}", status_code=303)

    @app.exception_handler(NeedAdmin)
    async def _need_admin(request: Request, _exc: NeedAdmin):
        if request.url.path.startswith("/api/"):
            return JSONResponse({"error": "admin_required"}, status_code=403)
        return render(request, "error.html", None, status_code=403,
                      text="Diese Seite ist nur für den Admin.")

    @app.exception_handler(AdminOnlyInLan)
    async def _admin_lan(request: Request, _exc: AdminOnlyInLan):
        if request.url.path.startswith("/api/"):
            return JSONResponse({"error": "admin_lan_only"}, status_code=403)
        return render(request, "error.html", None, status_code=403,
                      text="Das Admin-Konto ist nur im LAN freigegeben. Von außen bitte mit dem Benutzer-Konto (user) anmelden.")

    @app.middleware("http")
    async def _security_headers(request: Request, call_next):
        path = request.url.path
        allowed = path in ('/login', '/logout', '/first-login', '/help', '/healthz', '/ui-language.js', '/favicon.ico', '/branding/logo') or path.startswith(('/static/', '/language/'))
        if not allowed and auth.needs_password_change():
            session = auth.session(request.cookies.get(SESSION_COOKIE))
            if path.startswith('/api/'):
                response = JSONResponse({'error': 'password_change_required'}, status_code=403)
            else:
                response = RedirectResponse('/first-login' if session and session.is_admin else '/login', status_code=303)
        else:
            response = await call_next(request)
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault(
            "Content-Security-Policy", "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'"
        )
        if not request.url.path.startswith("/static/"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    # --- Anmeldung -------------------------------------------------------

    def help_session(request: Request):
        session = auth.session(request.cookies.get(SESSION_COOKIE))
        if session and session.is_admin and db.get_settings().get("admin_lan_only") == "1" and is_external(request):
            return None
        if session:
            return session
        if guest_allowed(request, db.get_settings()):
            return Session(token="", username="Gast", role="guest", csrf="")
        return None

    @app.get("/help", response_class=HTMLResponse)
    def help_page(request: Request):
        session = help_session(request)
        return render(request, "help.html", session, nav="help",
                      topics=help_docs.topics(i18n.language(request), session.role if session else "guest"))

    @app.get("/help.pdf")
    def help_pdf(request: Request, installation: bool = False):
        session = help_session(request)
        lang = i18n.language(request)
        role = session.role if session else "guest"
        if installation and role != "admin":
            raise HTTPException(status_code=403)
        encoded = db.get_settings().get("brand_logo", "")
        try:
            logo = base64.b64decode(encoded, validate=True) if len(encoded) <= 700000 else None
        except (ValueError, base64.binascii.Error):
            logo = None
        return Response(help_docs.pdf(lang, role, logo=logo, installation_only=installation), media_type="application/pdf",
                        headers={"Content-Disposition": f'attachment; filename="FCG-Zentrale-{("Installation-" if installation else "")}{__version__}-{lang}.pdf"'})

    @app.get("/ui-language.js")
    def ui_language(request: Request, lang: str = ""):
        lang = lang or i18n.language(request)
        if lang not in i18n.catalogs():
            raise HTTPException(status_code=404)
        payload = {key: i18n.translate(key, lang) for key in i18n.JS_MESSAGES}
        body = "window.FCG_I18N = " + json.dumps(payload, ensure_ascii=True) + ";"
        return Response(body, media_type="application/javascript")

    @app.get("/language/{lang}")
    def select_language(request: Request, lang: str, next: str = "/"):
        if lang not in i18n.catalogs():
            raise HTTPException(status_code=404)
        response = redirect(_safe_next(next))
        response.set_cookie("fcg-language", lang, max_age=365*86400, httponly=True, samesite="lax")
        return response

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon():
        # Dasselbe Symbol wie in der Weboberfläche der Gateways.
        return Response((PACKAGE_DIR / "static" / "favicon.png").read_bytes(), media_type="image/png",
                        headers={"Cache-Control": "max-age=86400"})

    @app.get("/healthz")
    def healthz():
        return {"ok": True, "version": __version__, "schema": SCHEMA_VERSION, "running": collector.is_running()}

    @app.get("/login", response_class=HTMLResponse)
    def login_form(request: Request, next: str = "/"):
        return render(request, "login.html", None, next=_safe_next(next), reader_ready=auth.has_user(READER_USER), factory_password=WEB_PASSWORD if auth.needs_password_change() else None)

    @app.post("/login")
    def login(request: Request, username: str = Form(""), password: str = Form(""), next: str = Form("/")):
        error = None
        try:
            session = auth.login(username, password)
            if session is None:
                error = "Benutzer oder Passwort falsch."
        except LoginLocked as exc:
            session, error = None, str(exc)
        if session is None:
            db.audit(username.strip()[:64] or None, "login_failed", "")
            return render(request, "login.html", None, status_code=401, next=_safe_next(next),
                          reader_ready=auth.has_user(READER_USER), message=("err", error), username=username)
        external = is_external(request)
        if session.is_admin and external and db.get_settings().get("admin_lan_only") == "1":
            auth.logout(session.token)
            db.audit(session.username, "login_failed", "von außen, Admin nur im LAN")
            return render(request, "login.html", None, status_code=403, next=_safe_next(next),
                          reader_ready=auth.has_user(READER_USER), username=username,
                          message=("err", "Das Admin-Konto ist nur im LAN freigegeben. Von außen bitte mit dem Benutzer-Konto (user) anmelden."))
        db.audit(session.username, "login", "von außen" if external else "")
        response = RedirectResponse(_safe_next(next), status_code=303)
        https = request.url.scheme == "https" or request.headers.get("x-forwarded-proto", "").lower() == "https"
        response.set_cookie(
            SESSION_COOKIE, session.token, max_age=SESSION_SECONDS, httponly=True, samesite="lax", secure=https,
        )
        return response

    @app.post("/logout")
    def logout(request: Request, csrf: str = Form("")):
        session = current(request)
        check_csrf(session, csrf)
        auth.logout(session.token)
        response = redirect("/login", "logged_out")
        response.delete_cookie(SESSION_COOKIE)
        return response

    # --- Übersicht ------------------------------------------------------

    @app.get("/", response_class=HTMLResponse)
    def overview(request: Request):
        session = current(request)
        return render(request, "overview.html", session, gateways=gateway_rows(), run=run_state_json(),
                      open_alerts=alert_links(alerts.open_alerts()), nav="overview")

    @app.get('/first-login', response_class=HTMLResponse)
    def first_login(request: Request):
        session = current(request, admin=True)
        if not auth.needs_password_change():
            return redirect('/info')
        return render(request, 'first_login.html', session)

    @app.post('/first-login')
    def first_login_save(request: Request, csrf: str = Form(''), current_password: str = Form(''), password: str = Form(''), repeat: str = Form('')):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if not auth.needs_password_change():
            raise HTTPException(status_code=400)
        try:
            if (not auth.check_credentials(ADMIN_USER, current_password) or password != repeat
                    or password == WEB_PASSWORD):
                raise ValueError('Aktuelles Passwort prüfen und ein eigenes neues Passwort zweimal eingeben.')
            check_new_password(password)
        except ValueError as exc:
            return render(request, 'first_login.html', session, status_code=400, message=('err', str(exc)))
        auth.set_password(ADMIN_USER, password)
        db.audit(session.username, 'admin_first_password_changed', '')
        response = redirect('/login', 'admin_saved')
        response.delete_cookie(SESSION_COOKIE)
        return response

    @app.get('/admin/vm/access', response_class=HTMLResponse)
    def vm_access_page(request: Request):
        session = current(request, admin=True)
        if config.deployment != 'vm':
            raise HTTPException(status_code=404)
        return render(request, 'vm_access.html', session, access=vm_access.status(), nav='info')

    @app.get('/api/vm/access')
    def vm_access_status(request: Request):
        current(request, admin=True)
        if config.deployment != 'vm':
            raise HTTPException(status_code=404)
        return vm_access.status()

    @app.post('/admin/vm/access')
    def vm_access_save(request: Request, csrf: str = Form(''), action: str = Form(''),
                       current_password: str = Form(''), password: str = Form(''), repeat: str = Form(''), enabled: str = Form('')):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if config.deployment != 'vm':
            raise HTTPException(status_code=404)
        try:
            if not vm_access.status().get('runtime_ready',True):
                raise ValueError('Die Linux-Systemverwaltung wird vorbereitet. Bitte nach wenigen Sekunden erneut versuchen.')
            if action not in ('ssh', 'password', 'refresh') or not current_password or len(current_password) > 128:
                raise ValueError('Systemaktion und aktuelles Linux-Passwort prüfen.')
            if action == 'password':
                if password != repeat:raise ValueError('Die beiden Passwörter stimmen nicht überein.')
                check_new_password(password)
            if action == 'ssh' and enabled not in ('0', '1'):
                raise ValueError('SSH-Einstellung fehlt.')
            vm_access.enqueue(action, current_password=current_password, password=password, enabled=enabled == '1')
            db.audit(session.username, 'vm_access_requested', action)
        except (ValueError, OSError) as exc:
            message = str(exc) if isinstance(exc, ValueError) else 'Systemaktion kann gerade nicht angefordert werden.'
            return render(request, 'vm_access.html', session, access=vm_access.status(), nav='info', status_code=400, message=('err', message))
        return redirect('/admin/vm/access', 'vm_access_queued')

    @app.get("/api/status")
    def api_status(request: Request):
        current(request)
        gateways = [
            {
                "id": g["id"], "title": g["title"], "host": g["host"], "status": g["status_class"],
                "status_text": g["status_text"], "last_ok_at": g["last_ok_at"], "fw_version": g["fw_version"],
                "live": i18n.localized_live(g["live"], i18n.language(request)),
            }
            for g in gateway_rows()
        ]
        return {"run": run_state_json(), "gateways": gateways}

    @app.post("/run")
    def run(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        started = collector.start_run_async("manual", session.username)
        if started:
            db.audit(session.username, "run_started", "")
        return redirect("/", "run_started" if started else "run_busy")

    @app.get("/runs", response_class=HTMLResponse)
    def runs(request: Request):
        session = current(request)
        with db.connect() as conn:
            run_rows = [dict(r) for r in conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 50").fetchall()]
            ids = [r["id"] for r in run_rows[:20]]
            results: dict[int, list[dict]] = {}
            if ids:
                marks = ",".join("?" for _ in ids)
                for row in conn.execute(
                    f"SELECT * FROM run_results WHERE run_id IN ({marks}) ORDER BY run_id DESC, rowid", ids
                ).fetchall():
                    results.setdefault(row["run_id"], []).append(dict(row))
        for item in run_rows:
            item["results"] = results.get(item["id"], [])
        return render(request, "runs.html", session, runs=run_rows, run=run_state_json(), nav="runs")

    # --- Verwaltung: Gateways --------------------------------------------

    @app.get("/admin/gateways", response_class=HTMLResponse)
    def gateways_page(request: Request):
        session = current(request, admin=True)
        return render(request, "gateways.html", session, gateways=gateway_rows(), form={}, nav="gateways")

    @app.post("/admin/gateways")
    def gateway_add(request: Request, csrf: str = Form(""), host: str = Form(""), label: str = Form(""),
                    username: str = Form("User"), password: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        form = {"host": host, "label": label, "username": username}
        try:
            clean_host, clean_label, clean_user = read_gateway_form(host, label, username)
            with db.connect() as conn:
                conn.execute(
                    "INSERT INTO gateways(host, label, username, password_enc, enabled, created_at) VALUES(?, ?, ?, ?, 1, ?)",
                    (clean_host, clean_label, clean_user, secrets.encrypt(password), now_text()),
                )
        except ValueError as exc:
            return render(request, "gateways.html", session, status_code=400, gateways=gateway_rows(), form=form,
                          message=("err", str(exc)), nav="gateways")
        except sqlite3.IntegrityError:
            return render(request, "gateways.html", session, status_code=400, gateways=gateway_rows(), form=form,
                          message=("err", "Diese Adresse ist schon angelegt."), nav="gateways")
        db.audit(session.username, "gateway_added", clean_host)
        live.poke()
        return redirect("/admin/gateways", "gw_added")

    def load_gateway(gateway_id: int) -> sqlite3.Row:
        with db.connect() as conn:
            row = conn.execute("SELECT * FROM gateways WHERE id = ?", (gateway_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Gateway nicht gefunden.")
        return row

    @app.get("/admin/gateways/{gateway_id}", response_class=HTMLResponse)
    def gateway_edit_page(request: Request, gateway_id: int):
        session = current(request, admin=True)
        return render(request, "gateway_edit.html", session, gw=load_gateway(gateway_id), nav="gateways")

    @app.post("/admin/gateways/{gateway_id}")
    def gateway_save(request: Request, gateway_id: int, csrf: str = Form(""), host: str = Form(""),
                     label: str = Form(""), username: str = Form(""), password: str = Form(""),
                     enabled: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        gateway = load_gateway(gateway_id)
        try:
            clean_host, clean_label, clean_user = read_gateway_form(host, label, username)
            password_enc = secrets.encrypt(password) if password else gateway["password_enc"]
            with db.connect() as conn:
                conn.execute(
                    "UPDATE gateways SET host = ?, label = ?, username = ?, password_enc = ?, enabled = ? WHERE id = ?",
                    (clean_host, clean_label, clean_user, password_enc, 1 if enabled else 0, gateway_id),
                )
        except (ValueError, sqlite3.IntegrityError) as exc:
            text = "Diese Adresse ist schon angelegt." if isinstance(exc, sqlite3.IntegrityError) else str(exc)
            return render(request, "gateway_edit.html", session, status_code=400, gw=gateway,
                          message=("err", text), nav="gateways")
        db.audit(session.username, "gateway_saved", clean_host)
        live.poke()
        return redirect("/admin/gateways", "gw_saved")

    @app.post("/admin/gateways/{gateway_id}/test", response_class=HTMLResponse)
    def gateway_test(request: Request, gateway_id: int, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        gateway = load_gateway(gateway_id)
        try:
            info = collector.test_connection(gateway["host"], collector.auth_for(gateway))
            text = (f"Verbindung ok in {info['duration_ms']} ms: {info['counter_name'] or 'ohne Namen'}, "
                    f"Firmware {info['fw_version'] or 'unbekannt'}, site_id {info['site_id']}")
            if info["demo_mode"]:
                text += ". Achtung: Gateway liefert Demo-Daten."
            message = ("warn" if info["demo_mode"] else "ok", text)
        except (GatewayError, ValueError) as exc:
            message = ("err", f"Verbindung fehlgeschlagen: {exc}")
        db.audit(session.username, "gateway_tested", f"{gateway['host']}: {message[0]}")
        return render(request, "gateway_edit.html", session, gw=gateway, message=message, nav="gateways")

    @app.post("/admin/gateways/{gateway_id}/delete")
    def gateway_delete(request: Request, gateway_id: int, csrf: str = Form(""), confirm: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        gateway = load_gateway(gateway_id)
        if confirm != "1":
            return render(request, "gateway_edit.html", session, status_code=400, gw=gateway,
                          message=("err", "Bitte das Entfernen mit dem Haken bestätigen."), nav="gateways")
        with db.connect() as conn:
            conn.execute("DELETE FROM gateways WHERE id = ?", (gateway_id,))
        db.audit(session.username, "gateway_deleted", gateway["host"])
        return redirect("/admin/gateways", "gw_deleted")

    # --- Verwaltung: Konten und Einstellungen ------------------------------

    @app.get("/admin/users", response_class=HTMLResponse)
    def users_page(request: Request):
        session = current(request, admin=True)
        return render(request, "users.html", session, **users_context())

    def users_context() -> dict:
        values = db.get_settings()
        return {"reader_ready": auth.has_user(READER_USER), "nav": "users",
                "guest_values": values,
                "gw_admin_user": values.get("gw_admin_user", ""),
                "gw_admin_saved": bool(values.get("gw_admin_password_enc"))}

    @app.get("/guest")
    def guest_entry(request: Request):
        if not guest_allowed(request, db.get_settings()):
            raise HTTPException(status_code=403, detail="Gastzugang ist für dieses Netz nicht freigegeben.")
        return redirect(guest_entry_path(db.get_settings()))

    @app.post("/admin/users/guest")
    async def guest_settings(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        enabled = form.get("guest_enabled") == "1"
        try:
            allowed = guest_networks(str(form.get("guest_networks", "")))
            proxies = guest_networks(str(form.get("guest_proxy_networks", "")))
            if enabled and not allowed:
                raise ValueError("Mindestens ein erlaubtes Netz eintragen.")
        except ValueError as exc:
            return render(request, "users.html", session, status_code=400,
                          message=("err", str(exc)), **users_context())
        db.set_settings({"guest_enabled": "1" if enabled else "0",
                         "guest_networks": "\n".join(map(str, allowed)),
                         "guest_proxy_networks": "\n".join(map(str, proxies)),
                         **{'guest_allow_' + area: '1' if form.get('guest_allow_' + area) == '1' else '0'
                            for area in GUEST_AREAS}})
        db.audit(session.username, "guest_access_saved", ("aktiv" if enabled else "aus") +
                 "; networks=" + ",".join(map(str, allowed)) + "; proxies=" + ",".join(map(str, proxies)))
        return redirect("/admin/users")

    @app.get("/admin/gateway-import/example")
    def gateway_import_example(request: Request):
        current(request, admin=True)
        content = "# " + i18n.translate("Eine Gateway-Adresse je Zeile; Leerzeilen und # Kommentare sind erlaubt.", i18n.language(request)) + "\n192.0.2.15\n192.0.2.18\nfcg-pruefstand.example:8080\n"
        return Response(content, media_type="text/plain; charset=utf-8",
                        headers={"Content-Disposition": 'attachment; filename="fcg_ips.txt"'})

    @app.post("/admin/users/gateway")
    def gateway_admin_account(request: Request, csrf: str = Form(""), username: str = Form(""),
                              password: str = Form(""), clear: str = Form("")):
        # Gateway-Admin für Firmware-Updates: Passwort verschlüsselt wie die Collector-Logins.
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if clear == "1":
            db.set_settings({"gw_admin_user": "", "gw_admin_password_enc": ""})
            db.audit(session.username, "gateway_admin_cleared", "")
            return redirect("/admin/users", "gw_admin_cleared")
        username = username.strip()[:64]
        stored_enc = db.get_settings().get("gw_admin_password_enc", "")
        if not username or not (password or stored_enc):
            return render(request, "users.html", session, status_code=400, **users_context(),
                          message=("err", "Bitte Benutzer und Passwort des Gateway-Admins eingeben."))
        values = {"gw_admin_user": username}
        if password:
            values["gw_admin_password_enc"] = secrets.encrypt(password[:128])
        db.set_settings(values)
        db.audit(session.username, "gateway_admin_saved", username + (", Passwort geändert" if password else ""))
        return redirect("/admin/users", "gw_admin_saved")

    @app.post("/admin/users/reader")
    def reader_password(request: Request, csrf: str = Form(""), password: str = Form(""), repeat: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            if password != repeat:
                raise ValueError("Die beiden Passwörter stimmen nicht überein.")
            check_new_password(password)
        except ValueError as exc:
            return render(request, "users.html", session, status_code=400, message=("err", str(exc)),
                          **users_context())
        auth.set_password(READER_USER, password)
        db.audit(session.username, "reader_password_set", "")
        return redirect("/admin/users", "reader_saved")

    @app.post("/admin/users/admin")
    def admin_password(request: Request, csrf: str = Form(""), current_password: str = Form(""),
                       password: str = Form(""), repeat: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            if not auth.check_credentials(ADMIN_USER, current_password):
                raise ValueError("Aktuelles Passwort ist falsch.")
            if password != repeat:
                raise ValueError("Die beiden Passwörter stimmen nicht überein.")
            check_new_password(password)
            if password == WEB_PASSWORD:
                raise ValueError('Bitte ein eigenes Passwort statt des öffentlichen Erstpassworts verwenden.')
        except ValueError as exc:
            return render(request, "users.html", session, status_code=400, message=("err", str(exc)),
                          **users_context())
        auth.set_password(ADMIN_USER, password)
        db.audit(session.username, "admin_password_changed", "")
        response = redirect("/login", "admin_saved")
        response.delete_cookie(SESSION_COOKIE)
        return response

    def settings_context(values: dict) -> dict:
        return {"values": values, "limits": SETTING_LIMITS, "live_limits": LIVE_LIMITS, "flags": STATS_FLAGS,
                "access_limits": ACCESS_LIMITS,
                "policies": POLICY_TEXT,
                "nav": "settings", "data_dir": str(config.data_dir), "export_dir": str(config.export_dir)}

    @app.get("/admin/settings", response_class=HTMLResponse)
    def settings_page(request: Request):
        session = current(request, admin=True)
        return render(request, "settings.html", session, **settings_context(db.get_settings()))

    @app.post("/admin/settings")
    async def settings_save(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        values: dict[str, str] = {}
        try:
            for key, (title, low, high) in SETTING_LIMITS.items():
                raw = str(form.get(key, "")).strip()
                if not raw.isdigit() or not low <= int(raw) <= high:
                    raise ValueError(f"{title}: Wert zwischen {low} und {high} eingeben.")
                values[key] = str(int(raw))
            current_values = db.get_settings()
            for key, (title, low, high) in (LIVE_LIMITS | ACCESS_LIMITS).items():
                raw = str(form.get(key, current_values[key])).strip()
                if not raw.isdigit() or not low <= int(raw) <= high:
                    raise ValueError(f"{title}: Wert zwischen {low} und {high} eingeben.")
                values[key] = str(int(raw))
            cutoff = str(form.get("stats_cutoff_day", current_values["stats_cutoff_day"])).strip()
            if not cutoff.isdigit() or not 1 <= int(cutoff) <= 28:
                raise ValueError("Stichtag: Tag zwischen 1 und 28 eingeben, damit jeder Monat gültig bleibt.")
            values["stats_cutoff_day"] = str(int(cutoff))
            day, month = stats.parse_annual(str(form.get("stats_annual_day_month", current_values["stats_annual_day_month"])))
            values["stats_annual_day_month"] = f"{day:02d}.{month:02d}"
            policy = str(form.get("stats_policy", current_values["stats_policy"]))
            if policy not in POLICY_TEXT:
                raise ValueError("Unbekannte Regel für vorhandene Berichte.")
            values["stats_policy"] = policy
            if form.get("stats_form"):  # Checkboxen fehlen im Formular, wenn sie aus sind
                for key in STATS_FLAGS:
                    values[key] = "1" if form.get(key) else "0"
                values["admin_lan_only"] = "1" if form.get("admin_lan_only") else "0"
        except ValueError as exc:
            return render(request, "settings.html", session, status_code=400, message=("err", str(exc)),
                          **settings_context({**db.get_settings(), **{k: str(v) for k, v in form.items()}}))
        db.set_settings(values)
        db.audit(session.username, "settings_saved", ", ".join(f"{k}={v}" for k, v in values.items()))
        return redirect("/admin/settings", "settings_saved")

    # --- Messstellen ------------------------------------------------------

    def site_rows() -> list[dict]:
        with db.connect() as conn:
            rows = conn.execute(
                """
                SELECT s.*, g.host, g.label AS gateway_label, g.id AS gw_id, g.pulses_per_unit,
                  (SELECT COUNT(*) FROM entries e WHERE e.site_id = s.site_id) AS entry_count,
                  (SELECT MIN(entry_date) FROM entries e WHERE e.site_id = s.site_id) AS first_date,
                  (SELECT MAX(entry_date) FROM entries e WHERE e.site_id = s.site_id) AS last_date,
                  (SELECT total_quantity FROM entries e WHERE e.site_id = s.site_id ORDER BY seq DESC LIMIT 1) AS last_total
                FROM sites s LEFT JOIN gateways g ON g.id = s.gateway_id
                ORDER BY lower(COALESCE(NULLIF(g.label, ''), NULLIF(s.counter_name, ''), s.site_id))
                """
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["title"] = row["gateway_label"] or row["counter_name"] or row["csv_stem"] or row["site_id"]
            result.append(item)
        return result

    def load_site(site_id: str) -> dict:
        for item in site_rows():
            if item["site_id"] == site_id:
                return item
        raise HTTPException(status_code=404, detail="Messstelle nicht gefunden.")

    @app.get("/sites", response_class=HTMLResponse)
    def sites_page(request: Request):
        session = current(request)
        sites = site_rows()
        for item in sites:
            item["live"] = live.view(item["gw_id"]) if item["gw_id"] else None
        return render(request, "sites.html", session, sites=sites, run=run_state_json(), nav="sites")

    @app.get("/site", response_class=HTMLResponse)
    def site_page(request: Request, id: str = "", days: int = 30, page: int = 1):
        session = current(request)
        site = load_site(id)
        days = days if days in CHART_DAYS else 30
        page = max(1, page)
        with db.connect() as conn:
            last_date = conn.execute("SELECT MAX(entry_date) FROM entries WHERE site_id = ?", (id,)).fetchone()[0]
            end = date.today()
            if last_date and date.fromisoformat(last_date) < end - timedelta(days=days - 1):
                end = date.fromisoformat(last_date)  # nur alte (importierte) Daten: Zeitraum davor zeigen
            start = end - timedelta(days=days - 1)
            sums = {
                r["entry_date"]: r for r in conn.execute(
                    "SELECT entry_date, COALESCE(SUM(consumed_quantity), 0) AS liter, COUNT(*) AS n, "
                    "SUM(consumed_quantity IS NULL) AS unknown FROM entries "
                    "WHERE site_id = ? AND entry_date BETWEEN ? AND ? GROUP BY entry_date",
                    (id, start.isoformat(), end.isoformat()),
                )
            }
            entries = [dict(r) for r in conn.execute(
                "SELECT * FROM entries WHERE site_id = ? ORDER BY seq DESC LIMIT ? OFFSET ?",
                (id, ENTRIES_PER_PAGE, (page - 1) * ENTRIES_PER_PAGE),
            ).fetchall()]
            period_total = sum(r["liter"] for r in sums.values())
        chart_days = []
        for offset in range(days):
            day = start + timedelta(days=offset)
            row = sums.get(day.isoformat())
            chart_days.append((day, float(row["liter"]) if row else 0.0, row["n"] if row else 0, row["unknown"] if row else 0))
        pages = max(1, -(-site["entry_count"] // ENTRIES_PER_PAGE))
        for entry in entries:
            entry["source_text"] = SOURCE_TEXT.get(entry["consumption_source"], entry["consumption_source"])
        site_live = live.view(site["gw_id"]) if site["gw_id"] else None
        return render(request, "site.html", session, site=site, live=site_live, chart=daily_chart(chart_days, i18n.language(request)), days=days,
                      chart_days=CHART_DAYS, start=start, end=end, period_total=period_total, entries=entries,
                      page=page, pages=pages, run=run_state_json(), nav="sites")

    def csv_response(name: str, content: bytes) -> Response:
        return Response(content, media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})

    @app.get("/site/csv")
    def site_csv(request: Request, id: str = ""):
        current(request)
        site = load_site(id)
        with db.connect() as conn:
            content = export_mod.to_bytes(export_mod.site_csv_text(conn, id))
        return csv_response(f"{site['csv_stem']}.csv", content)

    @app.get("/branding/logo")
    def brand_logo(request: Request):
        values = db.get_settings()
        encoded = values.get("brand_logo", "")
        if not encoded:
            raise HTTPException(status_code=404)
        return Response(base64.b64decode(encoded), media_type=values["brand_logo_type"],
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})

    @app.post("/admin/branding")
    async def branding_save(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        if form.get("remove"):
            db.set_settings({"brand_logo": "", "brand_logo_type": ""})
        else:
            upload = form.get("logo")
            if not isinstance(upload, StarletteUploadFile):
                raise HTTPException(status_code=400, detail="Bitte ein Logo auswählen.")
            content = await upload.read(512 * 1024 + 1)
            mime = ("image/png" if content.startswith(b"\x89PNG\r\n\x1a\n") else
                    "image/jpeg" if content.startswith(b"\xff\xd8\xff") else
                    "image/webp" if content[:4] == b"RIFF" and content[8:12] == b"WEBP" else "")
            if not mime or len(content) > 512 * 1024:
                raise HTTPException(status_code=400, detail="PNG, JPEG oder WebP bis 512 KiB verwenden.")
            db.set_settings({"brand_logo": base64.b64encode(content).decode("ascii"), "brand_logo_type": mime})
        db.audit(session.username, "branding_saved", "Logo geändert")
        return redirect("/admin/settings")

    @app.get("/counter-history", response_class=HTMLResponse)
    def counter_history(request: Request, day: str = "", site: str = ""):
        session = current(request)
        selected = parse_iso(day) if day else date.today()
        if selected is None:
            raise HTTPException(status_code=400, detail="Ungültiges Datum.")
        if site:
            load_site(site)
        return render(request, "counter_history.html", session, day=selected.isoformat(), site=site,
                      sites=site_rows(), snapshots=counter_snapshots(db, selected, site), nav="stats")

    @app.get("/data-quality", response_class=HTMLResponse)
    def data_quality(request: Request, site: str = ""):
        session = current(request)
        if site:
            load_site(site)
        return render(request, "data_quality.html", session, issues=undated_entries(db, site), nav="stats")

    # --- Statistik ------------------------------------------------------------

    def stats_view(kind: str, site_id: str) -> tuple[stats.StatsSettings, list[stats.Period], list[stats.StatRow], str, str, int]:
        s = stats.settings_from_values(db.get_settings())
        rows_by_source, names, undated = stats.load_rows(db, site_id or None)
        rows = [row for source in sorted(rows_by_source) for row in rows_by_source[source]]
        if site_id:
            source = next(iter(rows_by_source), "")
            scope, counter = "Counter", names.get(source) or source
        else:
            scope, counter = "Gesamt", "Alle_Counter"
        periods: list[stats.Period] = []
        if rows:
            dates = [r.day for r in rows]
            periods = stats.statistics_periods(min(dates), max(dates), s, date.today(), [kind])
        return s, periods, rows, scope, counter, undated

    @app.get("/stats", response_class=HTMLResponse)
    def stats_page(request: Request, kind: str = "Stichtagsmonat", site: str = "", all: int = 0):
        session = current(request)
        kind = kind if kind in stats.KINDS else "Stichtagsmonat"
        if site:
            load_site(site)
        s, periods, rows, scope, counter, undated = stats_view(kind, site)
        shown = list(reversed(periods))
        limited = not all and len(shown) > 12
        if limited:
            shown = shown[:12]
        reports = []
        for period in shown:
            groups = stats.measure(period, rows)
            all_groups = [g for g in groups.values() if g.name == stats.GROUP_ALL]
            reports.append({"period": period, "groups": list(groups.values()),
                            "total": sum(g.liter for g in all_groups),
                            "unknown": sum(g.unknown for g in all_groups)})
        return render(request, "stats.html", session, kind=kind, kinds=stats.KINDS, site=site, sites=site_rows(),
                      reports=reports, limited=limited, settings=s, counter=counter, scope=scope, undated=undated,
                      run=run_state_json(), nav="stats")

    @app.get("/stats/csv")
    def stats_csv(request: Request, kind: str = "Stichtagsmonat", site: str = "", start: str = ""):
        current(request)
        if kind not in stats.KINDS:
            raise HTTPException(status_code=404, detail="Unbekannte Berichtsart.")
        if site:
            load_site(site)
        _s, periods, rows, scope, counter, _undated = stats_view(kind, site)
        period = next((p for p in periods if p.start.isoformat() == start), None)
        if period is None:
            raise HTTPException(status_code=404, detail="Zeitraum nicht gefunden.")
        lines = stats.format_lines(period, stats.measure(period, rows), scope, counter)
        part = stats.safe_file_name(rows[0].source if site and rows else "Alle_Counter")
        return csv_response(f"{stats.REPORT_PREFIX}_{part}_{period.label}.csv",
                            export_mod.to_bytes(export_mod.encode_lines_text(lines)))

    # --- Auswertung: freier Zeitraum mit Vergleich ------------------------------

    def parse_iso(text: str) -> date | None:
        try:
            return date.fromisoformat((text or "").strip())
        except ValueError:
            return None

    def analysis_presets(today: date) -> list[dict]:
        month_start = date(today.year, today.month, 1)
        last_month_end = month_start - timedelta(days=1)
        return [
            {"text": "Letzte 30 Tage", "von": today - timedelta(days=29), "bis": today},
            {"text": "Dieser Monat", "von": month_start, "bis": today},
            {"text": "Letzter Monat", "von": date(last_month_end.year, last_month_end.month, 1), "bis": last_month_end},
            {"text": "Letzte 12 Monate", "von": stats.add_months(month_start, -11), "bis": today},
            {"text": "Dieses Jahr", "von": date(today.year, 1, 1), "bis": today},
            {"text": "Letztes Jahr", "von": date(today.year - 1, 1, 1), "bis": date(today.year - 1, 12, 31)},
        ]

    def analysis_view(site: str, von: str, bis: str, vergleich: str, vvon: str, vbis: str, einteilung: str,
                      faktor: str) -> dict:
        today = date.today()
        problems = []
        start, end = parse_iso(von), parse_iso(bis)
        if start is None or end is None:
            if von or bis:
                problems.append("Von und Bis bitte als gültiges Datum angeben. Gezeigt werden die letzten 30 Tage.")
            start, end = today - timedelta(days=29), today
        if start > end:
            problems.append("Von lag nach Bis, die beiden Daten wurden getauscht.")
            start, end = end, start
        if (end - start).days + 1 > stats.MAX_RANGE_DAYS:
            problems.append("Der Zeitraum ist auf 10 Jahre begrenzt.")
            start = end - timedelta(days=stats.MAX_RANGE_DAYS - 1)
        mode = vergleich if vergleich in stats.COMPARE_MODES else "vorjahr"
        compare_to = None
        if mode == "eigener":
            cs, ce = parse_iso(vvon), parse_iso(vbis)
            if cs is None or ce is None:
                problems.append("Für den eigenen Vergleichszeitraum Von und Bis angeben.")
            else:
                if cs > ce:
                    cs, ce = ce, cs
                if (ce - cs).days + 1 > stats.MAX_RANGE_DAYS:
                    cs = ce - timedelta(days=stats.MAX_RANGE_DAYS - 1)
                compare_to = (cs, ce)
        else:
            compare_to = stats.compare_range(mode, start, end)
        chosen = einteilung if einteilung in stats.GRANULARITIES else "auto"
        granularity = stats.auto_granularity(start, end) if chosen == "auto" else chosen
        factor = int(faktor) if faktor.isdigit() and int(faktor) in stats.ANOMALY_FACTORS else 3

        if site:
            load_site(site)
        rows_by_source, names, undated = stats.load_rows(db, site or None)
        rows = [row for source in sorted(rows_by_source) for row in rows_by_source[source]]
        if site:
            source = next(iter(rows_by_source), "")
            scope, counter, part = "Counter", names.get(source) or source, source
        else:
            scope, counter, part = "Gesamt", "Alle_Counter", "Alle_Counter"
        period = stats.custom_period(start, end, today)
        groups = stats.measure(period, rows)
        previous = stats.custom_period(*compare_to, today) if compare_to else None
        previous_groups = stats.measure(previous, rows) if previous else {}
        anomalies = stats.find_anomalies(rows, start, end, factor)
        buckets = stats.make_buckets(start, end, granularity)
        while len(buckets) > 500 and granularity != "monat":  # zu viele Balken: gröber einteilen
            granularity = "woche" if granularity == "tag" else "monat"
            buckets = stats.make_buckets(start, end, granularity)
        stats.fill_buckets(buckets, rows, {a.day for a in anomalies})
        previous_buckets = None
        if previous:
            previous_buckets = stats.fill_buckets(stats.make_buckets(previous.start, previous.end, granularity), rows)

        def totals(gs: dict[str, stats.Group]) -> dict:
            all_groups = [g for g in gs.values() if g.name == stats.GROUP_ALL]
            days = set().union(*[g.day_liter.keys() for g in all_groups]) if all_groups else set()
            liter = sum(g.liter for g in all_groups)
            return {"liter": liter, "days": len(days), "average": liter / len(days) if days else 0.0,
                    "entries": sum(g.entries for g in all_groups), "unknown": sum(g.unknown for g in all_groups)}

        current_totals = totals(groups)
        previous_totals = totals(previous_groups) if previous else None
        params = {"site": site, "von": start.isoformat(), "bis": end.isoformat(), "vergleich": mode,
                  "vvon": compare_to[0].isoformat() if mode == "eigener" and compare_to else vvon,
                  "vbis": compare_to[1].isoformat() if mode == "eigener" and compare_to else vbis,
                  "einteilung": chosen, "faktor": str(factor)}
        return {
            "params": params, "start": start, "end": end, "period": period, "previous": previous, "mode": mode,
            "granularity": granularity, "factor": factor, "rows": rows, "names": names, "undated": undated,
            "scope": scope, "counter": counter, "part": stats.safe_file_name(part),
            "groups": groups, "compares": stats.compare_groups(groups, previous_groups),
            "totals": current_totals, "previous_totals": previous_totals,
            "change": stats.percent_change(current_totals["liter"], previous_totals["liter"]) if previous_totals else None,
            "anomalies": anomalies, "buckets": buckets, "previous_buckets": previous_buckets,
            "problems": problems, "today": today,
        }

    @app.get("/analysis", response_class=HTMLResponse)
    def analysis_page(request: Request, site: str = "", von: str = "", bis: str = "", vergleich: str = "vorjahr",
                      vvon: str = "", vbis: str = "", einteilung: str = "auto", faktor: str = "3"):
        session = current(request)
        view = analysis_view(site, von, bis, vergleich, vvon, vbis, einteilung, faktor)
        unit = "l"
        if site:
            unit = load_site(site)["unit"] or "l"
        chart = compare_chart(view["buckets"], view["previous_buckets"], view["granularity"], unit, i18n.language(request))
        query = "&".join(f"{k}={quote(str(v))}" for k, v in view["params"].items())
        # Schnellwahl: anderer Zeitraum, sonst gleiche Auswahl; ein eigener Vergleich passt dann nicht mehr.
        preset_mode = "vorjahr" if view["mode"] == "eigener" else view["mode"]
        presets = []
        for p in analysis_presets(view["today"]):
            values = {**view["params"], "von": p["von"].isoformat(), "bis": p["bis"].isoformat(),
                      "vergleich": preset_mode, "vvon": "", "vbis": ""}
            presets.append({**p, "query": "&".join(f"{k}={quote(str(v))}" for k, v in values.items()),
                            "active": p["von"] == view["start"] and p["bis"] == view["end"]})
        return render(request, "analysis.html", session, v=view, chart=chart, unit=unit, query=query, presets=presets,
                      sites=site_rows(), modes=stats.COMPARE_MODES, granularities=stats.GRANULARITIES,
                      factors=stats.ANOMALY_FACTORS, run=run_state_json(), nav="analysis")

    @app.get("/analysis/csv")
    def analysis_csv(request: Request, typ: str = "bericht", site: str = "", von: str = "", bis: str = "",
                     vergleich: str = "vorjahr", vvon: str = "", vbis: str = "", einteilung: str = "auto",
                     faktor: str = "3"):
        current(request)
        view = analysis_view(site, von, bis, vergleich, vvon, vbis, einteilung, faktor)
        span = f"{view['start'].isoformat()}_bis_{view['end'].isoformat()}"
        part = view["part"]
        if typ == "bericht":
            name = f"{stats.REPORT_PREFIX}_{part}_{view['period'].label}.csv"
            lines = stats.format_lines(view["period"], view["groups"], view["scope"], view["counter"])
        elif typ == "vergleich":
            previous = view["previous"]
            if previous is None:
                raise HTTPException(status_code=404, detail="Kein Vergleichszeitraum gewählt.")
            name = f"FCG_Vergleich_{part}_{span}_mit_{previous.start.isoformat()}_bis_{previous.end.isoformat()}.csv"
            lines = stats.compare_lines(view["period"], previous, view["compares"], view["scope"], view["counter"])
        elif typ == "verlauf":
            name = f"FCG_Verlauf_{part}_{span}_{view['granularity']}.csv"
            lines = stats.trend_lines(view["buckets"], view["previous_buckets"], view["granularity"])
        elif typ == "auffaellig":
            name = f"FCG_Auffaellig_{part}_{span}.csv"
            lines = stats.anomaly_lines(view["anomalies"], view["names"])
        elif typ == "eintraege":
            with db.connect() as conn:
                text = export_mod.period_csv_text(conn, site or None, view["start"].isoformat(), view["end"].isoformat())
            stem = load_site(site)["csv_stem"] if site else "FCG_Eintraege_Alle_Counter"
            return csv_response(f"{stem}_{span}.csv", export_mod.to_bytes(text))
        else:
            raise HTTPException(status_code=404, detail="Unbekannter Export.")
        return csv_response(name, export_mod.to_bytes(export_mod.encode_lines_text(lines)))

    # --- Export und Import -------------------------------------------------------

    def last_imports() -> list[dict]:
        with db.connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT i.*, s.counter_name FROM imports i LEFT JOIN sites s ON s.site_id = i.site_id "
                "ORDER BY i.id DESC LIMIT 20").fetchall()]

    def export_context() -> dict:
        settings = db.get_settings()
        return {
            "sites": site_rows(), "export_dir": str(config.export_dir), "folder_problem": exporter.folder_problem(),
            "export_enabled": settings.get("export_enabled") == "1", "last_export": exporter.last_result(),
            "imports": last_imports(), "run": run_state_json(), "nav": "export",
        }

    @app.get("/export", response_class=HTMLResponse)
    def export_page(request: Request):
        session = current(request)
        return render(request, "export.html", session, **export_context())

    @app.get("/export/alle.zip")
    def export_zip(request: Request):
        current(request)
        name = f"FCG_Export_{datetime.now().strftime('%Y-%m-%d_%H%M')}.zip"
        return Response(export_mod.zip_all(db), media_type="application/zip",
                        headers={"Content-Disposition": f"attachment; filename={name}"})

    @app.post("/admin/export/run")
    def export_run(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        result = exporter.write_folder(f"manuell ({session.username})")
        db.audit(session.username, "export_run", result.summary())
        return redirect("/export", "export_done" if result.ok else "export_failed")

    def import_preview(request: Request, session: Session, token: str, choices: dict[int, str] | None,
                       adopt: dict[int, bool] | None, status_code: int = 200):
        message = ("warn", "Die Zuordnung wurde geändert. Bitte die neue Vorschau prüfen und dann importieren.") \
            if status_code == 409 else None
        try:
            files = staging.load(token)
        except (KeyError, OSError, ValueError):
            return redirect("/export", "import_expired")
        parsed, mappings, ignored = importer.split_uploads(files)
        sites = importer.known_sites(db)
        site_ids = {site["site_id"] for site in sites}
        extra = {m.site_id: m for m in mappings.values() if m.site_id not in site_ids}
        items = []
        with db.connect() as conn:
            for index, item in enumerate(parsed):
                guess, reason = importer.guess_site(item, mappings, sites)
                own = importer.own_site_id(item)
                chosen = guess if choices is None else choices.get(index, "")
                if chosen and chosen not in site_ids and chosen not in extra and chosen != own:
                    chosen = ""
                comparison = importer.compare(conn, chosen, item.rows) if chosen else None
                dates = [r.entry_date for r in item.rows if r.entry_date]
                items.append({
                    "index": index, "file": item, "guess": guess, "reason": reason, "chosen": chosen,
                    "cmp": comparison, "first_date": min(dates) if dates else None,
                    "last_date": max(dates) if dates else None,
                    "adopt": (adopt or {}).get(index, True) if adopt is not None else True,
                    "own": own, "own_known": own in site_ids,
                    "is_new_site": bool(chosen) and chosen not in site_ids,
                })
        return render(request, "import_preview.html", session, status_code=status_code, token=token, items=items,
                      sites=sites, extra=list(extra.values()), ignored=ignored, nav="export", run=run_state_json(),
                      message=message)

    def read_choices(form) -> tuple[dict[int, str], dict[int, bool]]:
        choices, adopt = {}, {}
        for key, value in form.multi_items():
            if key.startswith("site_") and key[5:].isdigit():
                choices[int(key[5:])] = str(value)
            if key.startswith("adopt_") and key[6:].isdigit():
                adopt[int(key[6:])] = True
        return choices, adopt

    @app.post("/admin/import", response_class=HTMLResponse)
    async def import_upload(request: Request, csrf: str = Form(""), files: list[UploadFile] = File(default=[])):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        uploads, total = [], 0
        for upload in files[: importer.MAX_FILES]:
            data = await upload.read(importer.MAX_UPLOAD_BYTES + 1)
            total += len(data)
            if total > importer.MAX_UPLOAD_BYTES:
                return render(request, "export.html", session, status_code=400,
                              message=("err", "Zusammen höchstens 50 MB pro Import."), **export_context())
            if data:
                uploads.append((importer.safe_upload_name(upload.filename or ""), data))
        if not any(name.lower().endswith(".csv") for name, _ in uploads):
            return render(request, "export.html", session, status_code=400,
                          message=("err", "Bitte mindestens eine CSV-Datei des alten Collectors auswählen."),
                          **export_context())
        token = staging.save(uploads)
        return import_preview(request, session, token, None, None)

    @app.post("/admin/import/preview", response_class=HTMLResponse)
    async def import_refresh(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        choices, adopt = read_choices(form)
        return import_preview(request, session, str(form.get("token", "")), choices, adopt)

    @app.post("/admin/import/confirm")
    async def import_confirm(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        token = str(form.get("token", ""))
        try:
            files = staging.load(token)
        except (KeyError, OSError, ValueError):
            return redirect("/export", "import_expired")
        choices, adopt = read_choices(form)
        shown = {int(k[6:]): str(v) for k, v in form.multi_items() if k.startswith("shown_") and k[6:].isdigit()}
        if any(choices.get(i, "") != shown.get(i, "") for i in set(choices) | set(shown)):
            # Zuordnung nach der Vorschau geändert: erst die neue Vorschau zeigen.
            response = import_preview(request, session, token, choices, adopt, status_code=409)
            return response
        parsed, mappings, _ignored = importer.split_uploads(files)
        site_ids = {site["site_id"] for site in importer.known_sites(db)}
        extra = {m.site_id: m for m in mappings.values()}
        for index, item in enumerate(parsed):
            target = choices.get(index, "")
            own = importer.own_site_id(item)
            if not target or (target not in site_ids and target not in extra and target != own) or not item.rows:
                continue
            counter_name = extra[target].counter_name if target in extra else ""
            result = importer.apply_import(db, target, item, session.username, counter_name, adopt.get(index, False))
            db.audit(session.username, "import", f"{item.name} -> {target}: {result.new} neu, "
                                                 f"{result.existing} vorhanden, {result.conflicts} abweichend")
        staging.drop(token)
        export_mod.ensure_all_stems(db)
        return redirect("/export", "import_done")

    # --- Gateway-Logs ---------------------------------------------------

    def gateway_choices() -> list[dict]:
        with db.connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT id, host, COALESCE(NULLIF(label, ''), NULLIF(counter_name, ''), host) AS title, "
                "log_last_ok_at, log_error FROM gateways ORDER BY lower(title)").fetchall()]

    def read_log_filter(params) -> dict:
        def day(value: str) -> str:
            try:
                return date.fromisoformat(value).isoformat() if value else ""
            except ValueError:
                return ""
        gateway = str(params.get("gateway", ""))
        level = str(params.get("level", ""))
        return {
            "gateway": int(gateway) if gateway.isdigit() else 0,
            "level": level if level in gatewaylogs.LEVELS else "",
            "area": str(params.get("area", ""))[:24],
            "q": str(params.get("q", "")).strip()[:100],
            "von": day(str(params.get("von", ""))),
            "bis": day(str(params.get("bis", ""))),
        }

    def query_logs(flt: dict, limit: int, offset: int = 0) -> tuple[list[dict], int]:
        return gatewaylogs.query(db, flt["gateway"] or None, flt["level"], flt["area"], flt["q"], flt["von"],
                                 flt["bis"], limit, offset)

    def logs_context(flt: dict, page: int) -> dict:
        rows, total = query_logs(flt, LOGS_PER_PAGE, (page - 1) * LOGS_PER_PAGE)
        params = {k: v for k, v in flt.items() if v}
        return {"rows": rows, "total": total, "flt": flt, "page": page,
                "pages": max(1, -(-total // LOGS_PER_PAGE)), "query": "&".join(f"{k}={quote(str(v))}" for k, v in params.items()),
                "gateways": gateway_choices(), "areas": gatewaylogs.areas(db), "levels": gatewaylogs.LEVELS,
                "run": run_state_json(), "nav": "logs"}

    @app.get("/logs", response_class=HTMLResponse)
    def logs_page(request: Request, page: int = 1):
        session = current(request)
        return render(request, "logs.html", session, **logs_context(read_log_filter(request.query_params), max(1, page)))

    @app.get("/logs/csv")
    def logs_csv(request: Request):
        current(request)
        rows, _total = query_logs(read_log_filter(request.query_params), 100000)
        name = f"FCG_Gateway_Logs_{datetime.now().strftime('%Y-%m-%d_%H%M')}.csv"
        return csv_response(name, gatewaylogs.csv_text(rows).encode("utf-8"))

    @app.get("/logs/sd", response_class=HTMLResponse)
    def logs_sd(request: Request, gateway: int = 0):
        session = current(request)
        gw = load_gateway(gateway)
        content, message = "", None
        try:
            data = get_json(gw["host"], "/api/sd/eventlog", GatewayAuth(), 15.0)
            content = str(data.get("content") or "") if isinstance(data, dict) else ""
            if not content:
                message = ("warn", "Das Gateway hat kein Ereignislog auf der SD-Karte geliefert.")
        except GatewayError as exc:
            message = ("err", f"SD-Ereignislog nicht abrufbar: {exc}")
        return render(request, "logs_sd.html", session, gw=gw, content=content, message=message,
                      run=run_state_json(), nav="logs")

    @app.post("/admin/logs/detail")
    def logs_detail(request: Request, csrf: str = Form(""), gateway: str = Form(""), username: str = Form(""),
                    password: str = Form("")):
        # Der Gateway-Admin-Login wird nur für diesen einen Abruf verwendet:
        # nicht gespeichert, nicht protokolliert.
        session = current(request, admin=True)
        check_csrf(session, csrf)
        gw = load_gateway(int(gateway) if gateway.isdigit() else 0)
        try:
            text = get_text(gw["host"], "/api/log.txt", GatewayAuth(username.strip()[:64], password), 30.0)
        except GatewayError as exc:
            detail = str(exc)
            if detail.startswith("HTTP 401"):
                detail = "HTTP 401: Gateway-Admin-Login abgelehnt. Benutzer und Passwort des Gateway-Admins prüfen."
            db.audit(session.username, "gateway_detail_log", f"{gw['host']}: Fehler")
            flt = read_log_filter({"gateway": str(gw["id"])})
            return render(request, "logs.html", session, status_code=502,
                          message=("err", f"Detail-Log von {gw['host']} nicht abrufbar: {detail}"), **logs_context(flt, 1))
        db.audit(session.username, "gateway_detail_log", f"{gw['host']}: ok")
        name = f"FCG_Detail_Log_{gw['host'].replace(':', '_')}_{datetime.now().strftime('%Y-%m-%d_%H%M')}.txt"
        return Response(text.encode("utf-8"), media_type="text/plain; charset=utf-8",
                        headers={"Content-Disposition": f"attachment; filename={name}"})

    # --- Gateway-Liste importieren ----------------------------------------

    @app.post("/admin/gateway-import", response_class=HTMLResponse)
    async def gateways_import(request: Request, csrf: str = Form(""), files: list[UploadFile] = File(default=[])):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        uploads = []
        for upload in files[:5]:
            data = await upload.read(1024 * 1024 + 1)
            if len(data) > 1024 * 1024:
                return render(request, "gateways.html", session, status_code=400, gateways=gateway_rows(), form={},
                              message=("err", "Datei zu groß, erwartet werden fcg_ips.txt und fcg_config.json."),
                              nav="gateways")
            if data:
                uploads.append((importer.safe_upload_name(upload.filename or ""), data))
        parsed = gateway_import.read_uploads(uploads)
        if not parsed.hosts and not parsed.settings:
            return render(request, "gateways.html", session, status_code=400, gateways=gateway_rows(), form={},
                          message=("err", " ".join(parsed.problems) or "Keine Gateways gefunden."), nav="gateways")
        token = gw_staging.save([("gateways.json", gateway_import.to_staged(parsed, secrets.encrypt))])
        return gateways_import_preview(request, session, token)

    def gateways_import_preview(request: Request, session: Session, token: str):
        try:
            staged = gateway_import.from_staged(gw_staging.load(token)[0][1])
        except (KeyError, OSError, ValueError, IndexError):
            return redirect("/admin/gateways", "import_expired")
        rows = gateway_import.preview_rows(db, staged["hosts"])
        current_values = db.get_settings()
        settings = [{"key": k, "value": setting_text(k, v), "current": setting_text(k, current_values.get(k, "")),
                     "changed": v != current_values.get(k, ""), "title": setting_title(k)}
                    for k, v in staged["settings"].items()]
        return render(request, "gateway_import.html", session, token=token, rows=rows, staged=staged,
                      settings=settings, nav="gateways",
                      new_count=sum(1 for r in rows if r["status"] == "new"))

    def setting_text(key: str, value: str) -> str:
        if key == "stats_policy":
            return POLICY_TEXT.get(value, value)
        if key in STATS_FLAGS:
            return "an" if value == "1" else "aus"
        return value

    def setting_title(key: str) -> str:
        if key in SETTING_LIMITS:
            return SETTING_LIMITS[key][0]
        return {"max_pages_per_gateway": "Max. Seiten pro Gateway", "stats_cutoff_day": "Stichtag",
                "stats_annual_day_month": "Jahresbeginn", "stats_policy": "Vorhandene Berichte"}.get(key) \
            or STATS_FLAGS.get(key, key)

    @app.post("/admin/gateway-import/confirm")
    async def gateways_import_confirm(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        token = str(form.get("token", ""))
        try:
            staged = gateway_import.from_staged(gw_staging.load(token)[0][1])
        except (KeyError, OSError, ValueError, IndexError):
            return redirect("/admin/gateways", "import_expired")
        chosen = {str(v) for k, v in form.multi_items() if k == "host"}
        use_auth = bool(form.get("use_auth")) and staged["has_auth"]
        username = staged["username"] if use_auth else "User"
        password_enc = staged["password_enc"] if use_auth else secrets.encrypt("")
        added = []
        with db.connect() as conn:
            for row in gateway_import.preview_rows(db, staged["hosts"]):
                if row["status"] != "new" or row["host"] not in chosen:
                    continue
                try:
                    conn.execute(
                        "INSERT INTO gateways(host, label, username, password_enc, enabled, created_at) VALUES(?, '', ?, ?, 1, ?)",
                        (row["host"], username, password_enc, now_text()),
                    )
                    added.append(row["host"])
                except sqlite3.IntegrityError:
                    pass
        applied = {}
        if form.get("use_settings"):
            applied = dict(staged["settings"])
            if applied:
                db.set_settings(applied)
        gw_staging.drop(token)
        live.poke()
        db.audit(session.username, "gateways_imported",
                 f"{len(added)} neu: {', '.join(added)}; Login übernommen: {'ja' if use_auth else 'nein'}; "
                 f"Einstellungen: {', '.join(f'{k}={v}' for k, v in applied.items()) or 'keine'}")
        return redirect("/admin/gateways", "gw_imported")

    # --- Warnungen und Mail ----------------------------------------------

    ALERT_LIMITS = {
        "alert_offline_hours": ("Warnung, wenn ein Gateway so lange nicht abgeholt wurde (Stunden)", 1, 720),
        "alert_disk_min_mb": ("Warnung, wenn im Datenordner weniger frei ist (MB, 0 = aus)", 0, 1_000_000),
        "alert_silence_factor": ("Warnung „kein Füllvorgang“ ab Faktor × üblichem Abstand (0 = aus)", 0, 30),
        "alert_silence_min_days": ("… frühestens nach (Tagen)", 1, 365),
        "report_hour": ("Tagesbericht ab (Uhr)", 0, 23),
    }

    def alert_links(rows: list[dict]) -> list[dict]:
        """Zu jeder Warnung Messstelle und Gateway aus dem Schlüssel suchen.

        Die Texte beginnen mit "Titel (host)"; daraus werden in der Anzeige
        Links auf die Messstelle und auf die Weboberfläche des Gateways.
        """
        with db.connect() as conn:
            by_gw = {str(r["id"]): dict(r) for r in conn.execute("SELECT id, host, site_id FROM gateways")}
            by_site = {r["site_id"]: dict(r) for r in conn.execute(
                "SELECT s.site_id, g.host, g.id FROM sites s LEFT JOIN gateways g ON g.id = s.gateway_id")}
        result = []
        for row in rows:
            link, link_text = ALERT_PAGES.get(row["key"], ("", ""))
            item = dict(row, level_text=LEVEL_TEXT.get(row["level"], row["level"]),
                        site_id="", host="", head="", rest=row["text"], link=link, link_text=link_text)
            kind, _, ident = row["key"].partition(":")
            target = by_site.get(ident) if kind == "silent" else by_gw.get(ident) if ident else None
            if target:
                item["site_id"] = target.get("site_id") or ""
                item["host"] = target.get("host") or ""
                marker = f" ({item['host']})"
                if item["host"] and marker in row["text"]:
                    head, _, rest = row["text"].partition(marker)
                    item["head"], item["rest"] = head, rest
            result.append(item)
        return result

    def alerts_context(values: dict | None = None) -> dict:
        values = values or db.get_settings()
        current_alerts = alert_links(alerts.open_alerts())
        counts = {level: sum(1 for a in current_alerts if a["level"] == level) for level in ("err", "warn", "info")}
        return {"open_alerts": current_alerts, "acked_alerts": alert_links(alerts.open_alerts(acked=True)),
                "counts": counts, "closed_alerts": alerts.recent_closed(), "values": values,
                "limits": ALERT_LIMITS, "security": mail_mod.SECURITY,
                "has_smtp_password": bool(db.get_settings().get("smtp_password_enc")),
                "run": run_state_json(), "nav": "alerts"}

    @app.get("/alerts", response_class=HTMLResponse)
    def alerts_page(request: Request):
        session = current(request)
        return render(request, "alerts.html", session, **alerts_context())

    @app.post("/admin/alerts/settings")
    async def alerts_settings(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        values: dict[str, str] = {}
        stored = db.get_settings()
        try:
            for key, (title, low, high) in ALERT_LIMITS.items():
                raw = str(form.get(key, stored.get(key, ""))).strip()
                if not raw.isdigit() or not low <= int(raw) <= high:
                    raise ValueError(f"{title}: Wert zwischen {low} und {high} eingeben.")
                values[key] = str(int(raw))
            values["mail_enabled"] = "1" if form.get("mail_enabled") else "0"
            values["report_enabled"] = "1" if form.get("report_enabled") else "0"
            values["alert_log_errors"] = "1" if form.get("alert_log_errors") else "0"
            values["smtp_host"] = str(form.get("smtp_host", "")).strip()[:200]
            port = str(form.get("smtp_port", "")).strip()
            if not port.isdigit() or not 1 <= int(port) <= 65535:
                raise ValueError("SMTP-Port: Zahl zwischen 1 und 65535 eingeben.")
            values["smtp_port"] = port
            security = str(form.get("smtp_security", "starttls"))
            if security not in mail_mod.SECURITY:
                raise ValueError("Unbekannte Verschlüsselung.")
            values["smtp_security"] = security
            values["smtp_user"] = str(form.get("smtp_user", "")).strip()[:200]
            sender = str(form.get("mail_from", "")).strip()[:200]
            recipients = mail_mod.split_addresses(str(form.get("mail_to", "")))
            for address in ([sender] if sender else []) + recipients:
                if not mail_mod.valid_address(address):
                    raise ValueError(f"Ungültige Mailadresse: {address}")
            values["mail_from"] = sender
            values["mail_to"] = ", ".join(recipients)
            if values["mail_enabled"] == "1":
                problem = mail_mod.MailSettings(True, values["smtp_host"], int(port), security, "", "", sender,
                                                recipients).problem()
                if problem:
                    raise ValueError(f"Mail einschalten geht erst mit allen Angaben: {problem}")
            password = str(form.get("smtp_password", ""))
            if form.get("smtp_password_clear"):
                values["smtp_password_enc"] = ""
            elif password:
                values["smtp_password_enc"] = secrets.encrypt(password)
        except ValueError as exc:
            shown = {**db.get_settings(), **{k: str(v) for k, v in form.items() if k != "smtp_password"}}
            return render(request, "alerts.html", session, status_code=400, message=("err", str(exc)),
                          **alerts_context(shown))
        db.set_settings(values)
        db.audit(session.username, "alert_settings_saved",
                 ", ".join(f"{k}={v}" for k, v in values.items() if k != "smtp_password_enc")
                 + (", SMTP-Passwort geändert" if "smtp_password_enc" in values else ""))
        return redirect("/alerts", "alert_settings_saved")

    @app.post("/admin/alerts/ack")
    def alerts_ack(request: Request, csrf: str = Form(""), alert_id: int = Form(0), undo: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if undo == "1":
            row = alerts.unacknowledge(alert_id)
        else:
            row = alerts.acknowledge(alert_id, session.username)
        if row is None:
            return redirect("/alerts", "alert_gone")
        db.audit(session.username, "alert_unacked" if undo == "1" else "alert_acked", row["text"][:200])
        return redirect("/alerts", "alert_unacked" if undo == "1" else "alert_acked")

    @app.post("/admin/alerts/testmail")
    def alerts_testmail(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            mailer.send("FCG Zentrale: Testmail",
                        f"Diese Testmail hat {session.username} am {now_text()} in der FCG Zentrale V{__version__} ausgelöst.\n"
                        "Warnungen kommen an diese Adresse(n).", force=True)
        except mail_mod.MailError as exc:
            db.audit(session.username, "test_mail", f"Fehler: {exc}")
            return render(request, "alerts.html", session, status_code=502, message=("err", str(exc)),
                          **alerts_context())
        db.audit(session.username, "test_mail", "ok")
        return redirect("/alerts", "mail_sent")

    @app.post("/admin/alerts/report")
    def alerts_report(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            subject = report.send(force=True)
        except mail_mod.MailError as exc:
            db.audit(session.username, "report_sent", f"Fehler: {exc}")
            return render(request, "alerts.html", session, status_code=502, message=("err", str(exc)),
                          **alerts_context())
        db.audit(session.username, "report_sent", subject)
        return redirect("/alerts", "report_sent")

    # --- Hallenanzeige ----------------------------------------------------

    @app.get("/dashboard", response_class=HTMLResponse)
    def dashboard(request: Request):
        session = current(request)
        return render(request, "dashboard.html", session, gateways=[g for g in gateway_rows() if g["enabled"]],
                      open_alerts=[] if session.role == "guest" else alert_links(alerts.open_alerts()), now=datetime.now(), kiosk=True,
                      refresh=db.get_int_setting("dashboard_refresh_sec"))

    # --- Sicherung --------------------------------------------------------

    BACKUP_LIMITS = {
        "backup_hour": ("Nächtliche Sicherung ab (Uhr)", 0, 23),
        "backup_keep_days": ("Sicherungen aufbewahren (Tage)", 1, 3650),
    }
    restore_staging = importer.Staging(config.import_dir / "restore")

    def backup_context() -> dict:
        values = db.get_settings()
        return {"backups": backups.list(), "values": values, "limits": BACKUP_LIMITS,
                "backup_dir": str(config.backups_dir), "run": run_state_json(), "nav": "backup",
                "last": {"at": values.get("backup_last_at", ""), "ok": values.get("backup_last_ok", ""),
                         "summary": values.get("backup_last_summary", "")}}

    @app.get("/admin/backup", response_class=HTMLResponse)
    def backup_page(request: Request):
        session = current(request, admin=True)
        return render(request, "backup.html", session, **backup_context())

    @app.post("/admin/backup/run")
    def backup_run(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            item = backups.create("manuell")
        except (OSError, backup_mod.BackupError) as exc:
            return render(request, "backup.html", session, status_code=500,
                          message=("err", f"Sicherung fehlgeschlagen: {exc}"), **backup_context())
        db.audit(session.username, "backup_created", item.name)
        return redirect("/admin/backup", "backup_done")

    @app.get("/admin/backup/download")
    def backup_download(request: Request, name: str = ""):
        session = current(request, admin=True)
        try:
            path = backups.path_of(name)
        except backup_mod.BackupError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        db.audit(session.username, "backup_downloaded", name)
        return Response(path.read_bytes(), media_type="application/zip",
                        headers={"Content-Disposition": f"attachment; filename={path.name}"})

    @app.post("/admin/backup/settings")
    async def backup_settings(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        values = {"backup_enabled": "1" if form.get("backup_enabled") else "0"}
        for key, (title, low, high) in BACKUP_LIMITS.items():
            raw = str(form.get(key, "")).strip()
            if not raw.isdigit() or not low <= int(raw) <= high:
                return render(request, "backup.html", session, status_code=400,
                              message=("err", f"{title}: Wert zwischen {low} und {high} eingeben."), **backup_context())
            values[key] = str(int(raw))
        db.set_settings(values)
        db.audit(session.username, "backup_settings_saved", ", ".join(f"{k}={v}" for k, v in values.items()))
        return redirect("/admin/backup", "backup_settings_saved")

    def restore_preview(request: Request, session: Session, token: str):
        try:
            name, data = restore_staging.load(token)[0]
        except (KeyError, OSError, ValueError, IndexError):
            return redirect("/admin/backup", "import_expired")
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = Path(tmp) / "upload.zip"
            zip_path.write_bytes(data)
            try:
                info = backups.inspect(zip_path, Path(tmp))
            except backup_mod.BackupError as exc:
                restore_staging.drop(token)
                return render(request, "backup.html", session, status_code=400,
                              message=("err", f"{name}: {exc}"), **backup_context())
        with db.connect() as conn:
            now_counts = backup_mod._counts(conn)
        return render(request, "restore_preview.html", session, token=token, file_name=name, info=info,
                      now_counts=now_counts, kinds=backup_mod.KINDS, nav="backup", run=run_state_json())

    @app.post("/admin/restore", response_class=HTMLResponse)
    async def restore_upload(request: Request, csrf: str = Form(""), file: UploadFile = File(...)):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        data = await file.read(backup_mod.MAX_RESTORE_BYTES + 1)
        if not data or len(data) > backup_mod.MAX_RESTORE_BYTES:
            return render(request, "backup.html", session, status_code=400,
                          message=("err", "Bitte eine Sicherung (ZIP, höchstens 1 GB) auswählen."), **backup_context())
        token = restore_staging.save([(importer.safe_upload_name(file.filename or "sicherung.zip"), data)])
        return restore_preview(request, session, token)

    @app.post("/admin/restore/confirm")
    def restore_confirm(request: Request, csrf: str = Form(""), token: str = Form(""), confirm: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if confirm != "1":
            response = restore_preview(request, session, token)
            if isinstance(response, HTMLResponse):
                response.status_code = 400
            return response
        try:
            name, data = restore_staging.load(token)[0]
        except (KeyError, OSError, ValueError, IndexError):
            return redirect("/admin/backup", "import_expired")
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = Path(tmp) / "upload.zip"
            zip_path.write_bytes(data)
            try:
                backups.inspect(zip_path, Path(tmp))
                with collector.paused():
                    safety = backups.restore(Path(tmp))
            except (backup_mod.BackupError, RuntimeError, OSError, sqlite3.Error) as exc:
                return render(request, "backup.html", session, status_code=500,
                              message=("err", f"Rücksicherung nicht eingespielt: {exc}"), **backup_context())
        restore_staging.drop(token)
        secrets.reload()
        app.state.offline_updates._sync_mode()
        export_mod.ensure_all_stems(db)
        live.poke()
        db.audit(session.username, "backup_restored", f"{name}; vorheriger Stand in {safety.name}")
        response = redirect("/login", "restored")
        response.delete_cookie(SESSION_COOKIE)
        return response

    from .offline_web import add_routes as add_offline_routes
    app.state.offline_updates = add_offline_routes(app, config, db, secrets, ota, updater,
                                                   current, check_csrf, render)

    # --- OTA-Spiegel ----------------------------------------------------------

    def ota_context() -> dict:
        values = db.get_settings()
        return {"releases": ota.releases(), "published": ota.published(), "folder_problem": ota.folder_problem(),
                "last_check": ota.last_check(), "values": values, "ota_dir": str(config.ota_dir),
                "gateways": gateway_rows(), "run": run_state_json(), "nav": "ota",
                "update_steps": updater.steps(), "update_running": updater.running, "gw_states": {},
                "cleanup": ota.cleanup_candidates(), "gw_admin_user": values.get("gw_admin_user", ""),
                "gw_admin_saved": bool(values.get("gw_admin_password_enc"))}

    @app.get("/admin/ota", response_class=HTMLResponse)
    def ota_page(request: Request):
        session = current(request, admin=True)
        return render(request, "ota.html", session, **ota_context())

    @app.post("/admin/ota/check")
    def ota_check(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if db.get_settings().get("update_mode")=="offline":
            return RedirectResponse("/admin/offline-updates",status_code=303)
        try:
            message = ("ok", ota.check())
        except ota_mod.OtaError as exc:
            message = ("err", str(exc))
        db.audit(session.username, "ota_checked", message[1])
        alerts.evaluate()
        return render(request, "ota.html", session, message=message, **ota_context())

    @app.post("/admin/ota/approve")
    def ota_approve(request: Request, csrf: str = Form(""), version: str = Form(""), confirm: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if confirm != "1":
            return render(request, "ota.html", session, status_code=400,
                          message=("err", "Bitte die Freigabe mit dem Haken bestätigen."), **ota_context())
        try:
            ota.approve(version, session.username)
        except (ota_mod.OtaError, OSError) as exc:
            db.audit(session.username, "ota_approve_failed", f"{version}: {exc}")
            return render(request, "ota.html", session, status_code=400, message=("err", str(exc)), **ota_context())
        db.audit(session.username, "ota_published", version)
        alerts.evaluate()
        return redirect("/admin/ota", "ota_published")

    @app.post("/admin/ota/cleanup")
    def ota_cleanup(request: Request, csrf: str = Form(""), confirm: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if confirm != "1":
            return render(request, "ota.html", session, status_code=400,
                          message=("err", "Bitte das Bereinigen mit dem Haken bestätigen."), **ota_context())
        count, freed = ota.cleanup()
        text = (f"{count} alte Version(en) gelöscht, {format_bytes(freed)} frei." if count
                else "Nichts zu bereinigen.")
        db.audit(session.username, "ota_cleanup", text)
        return render(request, "ota.html", session, message=("ok", text), **ota_context())

    @app.post("/admin/ota/reject")
    def ota_reject(request: Request, csrf: str = Form(""), version: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        try:
            ota.reject(version, session.username)
        except ota_mod.OtaError as exc:
            return render(request, "ota.html", session, status_code=400, message=("err", str(exc)), **ota_context())
        db.audit(session.username, "ota_rejected", version)
        alerts.evaluate()
        return redirect("/admin/ota", "ota_rejected")

    @app.post("/admin/ota/settings")
    async def ota_settings(request: Request):
        session = current(request, admin=True)
        form = await request.form()
        check_csrf(session, str(form.get("csrf", "")))
        from .update_source import custom_source
        if form.get('source_action') == 'default':
            db.set_settings({'ota_source_url': ''})
            db.audit(session.username, 'ota_source_reset', 'Standardquelle')
            return redirect('/admin/ota', 'ota_settings_saved')
        source = custom_source(str(form.get("ota_source_url", "")))
        hours = str(form.get("ota_check_hours", "")).strip()
        parallel = str(form.get("ota_parallel", db.get_settings().get("ota_parallel", "3"))).strip()
        problem = ""
        if source and (not source.startswith("https://") or len(source) > 300 or any(c in source for c in ' "<>')):
            problem = "Quelle: eine https://-Adresse eingeben."
        elif not hours.isdigit() or not 1 <= int(hours) <= 168:
            problem = "Prüfintervall: 1 bis 168 Stunden."
        elif not parallel.isdigit() or not 1 <= int(parallel) <= MAX_PARALLEL_UPDATES:
            problem = f"Gleichzeitig aktualisieren: 1 bis {MAX_PARALLEL_UPDATES} Gateways."
        if problem:
            return render(request, "ota.html", session, status_code=400, message=("err", problem), **ota_context())
        values = {"ota_enabled": "1" if form.get("ota_enabled") else "0", "ota_source_url": source,
                  "ota_check_hours": str(int(hours)), "ota_parallel": str(int(parallel))}
        db.set_settings(values)
        db.audit(session.username, "ota_settings_saved", ", ".join(f"{k}={v}" for k, v in values.items()))
        alerts.evaluate()
        return redirect("/admin/ota", "ota_settings_saved")

    # --- Gateways aktualisieren ---------------------------------------------------

    @app.post("/admin/ota/gateways")
    def ota_gateways(request: Request, csrf: str = Form(""), action: str = Form(""), username: str = Form(""),
                     password: str = Form(""), confirm: str = Form(""), force: str = Form("")):
        # Der Gateway-Admin-Login gilt nur für diesen einen Durchgang:
        # nicht gespeichert, nicht protokolliert.
        session = current(request, admin=True)
        check_csrf(session, csrf)

        def page(level: str, text: str, status: int = 200, **extra):
            return render(request, "ota.html", session, status_code=status, message=(level, text),
                          **{**ota_context(), **extra})

        if not username.strip() and not password:
            # Leer gelassen: das unter Konten gespeicherte Gateway-Admin-Konto nehmen.
            stored = db.get_settings()
            if stored.get("gw_admin_user") and stored.get("gw_admin_password_enc"):
                username, password = stored["gw_admin_user"], secrets.decrypt(stored["gw_admin_password_enc"])
        if not username.strip() or not password:
            return page("err", "Bitte Benutzer und Passwort des Gateway-Admins eingeben "
                               "oder unter Konten das Gateway-Admin-Konto speichern.", 400)
        gw_auth = GatewayAuth(username.strip()[:64], password[:128])
        with db.connect() as conn:
            enabled = conn.execute("SELECT * FROM gateways WHERE enabled = 1 ORDER BY id").fetchall()
        parts = action.split(":")

        if action == "state":
            results = updater.read_states(enabled, gw_auth)
            failed = [f"{gw['host']}: {error}" for gw, _state, error in results if error]
            db.audit(session.username, "gateway_ota_state", f"{len(results) - len(failed)} von {len(results)} gelesen")
            states = {gw["id"]: {"state": st, "error": error} for gw, st, error in results}
            text = "Zustand der Gateways gelesen." if not failed else "Nicht alle Gateways lesbar: " + "; ".join(failed)
            return page("ok" if not failed else "warn", text, gw_states=states)

        if len(parts) == 3 and parts[0] == "auto" and parts[1].isdigit() and parts[2] in ("0", "1"):
            gw = load_gateway(int(parts[1]))
            wanted = parts[2] == "1"
            word = "an" if wanted else "aus"
            try:
                updater.set_auto_install(gw, gw_auth, wanted)
            except GatewayError as exc:
                db.audit(session.username, "gateway_auto_install", f"{gw['host']}: {word} fehlgeschlagen")
                return page("err", f"Auto-Install von {gw['host']} nicht geändert: {exc}", 502)
            db.audit(session.username, "gateway_auto_install", f"{gw['host']}: {word}")
            return page("ok", f"Auto-Install von {gw['host']} ist jetzt {word}.")

        if len(parts) == 2 and parts[0] == "update":
            target = ota.published().version
            if not target:
                return page("err", "Es ist keine Firmware freigegeben. Erst oben eine Version freigeben.", 400)
            if confirm != "1":
                return page("err", "Bitte das Update mit dem Haken bestätigen.", 400)
            if parts[1] == "all":
                # Gateways ohne bekannte Version waren noch nie erreichbar und bleiben außen vor.
                chosen = [g for g in enabled
                          if g["fw_version"] and ota_mod.version_key(g["fw_version"]) < ota_mod.version_key(target)]
                if not chosen:
                    return page("ok", f"Alle Gateways laufen schon mit {target} oder neuer.")
            elif parts[1].isdigit():
                chosen = [load_gateway(int(parts[1]))]
            else:
                return page("err", "Unbekannte Aktion.", 400)
            if not updater.start(chosen, gw_auth, session.username, target, force=force == "1"):
                return page("warn", "Es läuft bereits ein Update. Bitte warten, bis es fertig ist.", 409)
            db.audit(session.username, "gateway_update_started",
                     f"{target} für " + ", ".join(g["host"] for g in chosen)
                     + (" (erzwungen, auch wenn nicht in Ruhe)" if force == "1" else ""))
            return redirect("/admin/ota", "gw_update_started")

        return page("err", "Unbekannte Aktion.", 400)

    # --- Protokoll ---------------------------------------------------------------

    AUDIT_PER_PAGE = 100

    @app.get("/admin/audit", response_class=HTMLResponse)
    def audit_page(request: Request, page: int = 1, user: str = "", action: str = "", q: str = ""):
        session = current(request, admin=True)
        page = max(1, page)
        where, params = [], []
        if user:
            where.append("username = ?")
            params.append(user[:64])
        if action:
            where.append("action = ?")
            params.append(action[:64])
        if q:
            where.append("detail LIKE ? ESCAPE '\\'")
            params.append("%" + q[:100].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        with db.connect() as conn:
            total = conn.execute(f"SELECT COUNT(*) FROM audit{clause}", params).fetchone()[0]
            rows = [dict(r) for r in conn.execute(
                f"SELECT * FROM audit{clause} ORDER BY id DESC LIMIT ? OFFSET ?",
                [*params, AUDIT_PER_PAGE, (page - 1) * AUDIT_PER_PAGE])]
            users = [r[0] for r in conn.execute("SELECT DISTINCT username FROM audit WHERE username IS NOT NULL ORDER BY 1")]
            actions = [r[0] for r in conn.execute("SELECT DISTINCT action FROM audit ORDER BY 1")]
        from .update_source import public_text
        for row in rows:
            row['detail'] = public_text(row['detail'])
        flt = {"user": user, "action": action, "q": q}
        query = "&".join(f"{k}={quote(v)}" for k, v in flt.items() if v)
        return render(request, "audit.html", session, rows=rows, total=total, page=page,
                      pages=max(1, -(-total // AUDIT_PER_PAGE)), users=users, actions=actions, flt=flt, query=query,
                      run=run_state_json(), nav="audit")

    def auto_update_status() -> dict | None:
        """Ergebnis des letzten Laufs von auto_update.sh (schreibt data/auto_update.json), sonst None."""
        try:
            data = json.loads((config.data_dir / "auto_update.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        if not isinstance(data, dict):
            return None
        return {key: str(data.get(key, ""))[:300] for key in ("at", "result", "message", "version")}

    def auto_update_problem() -> dict:
        status = auto_update_status()
        if status and status["result"] == "failed":
            return {"selfupdate": Problem("selfupdate", "warn", f"Auto-Update der Zentrale ({status['at']}): "
                                                               f"{status['message']}")}
        return {}

    alerts.sources.append(auto_update_problem)

    @app.get("/fcg_update/{filename}")
    def vm_firmware_mirror(filename: str):
        if not (filename in ("update.json", "fcg_main.ino.bin")
                or re.fullmatch(r"fcg_main_V[0-9]+\.[0-9]+\.[0-9]+\.bin", filename)):
            raise HTTPException(status_code=404)
        target = config.ota_dir / filename
        if not target.is_file() or target.is_symlink():
            raise HTTPException(status_code=404)
        from fastapi.responses import FileResponse
        return FileResponse(target, media_type="application/json" if filename == "update.json" else "application/octet-stream",
                            headers={"Cache-Control": "no-store"})

    @app.post("/admin/system/update-check")
    def central_update_check(request: Request, csrf: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if db.get_settings().get("update_mode")=="offline":
            return RedirectResponse("/admin/offline-updates",status_code=303)
        central_updates.check()
        return RedirectResponse("/info#central-updates", status_code=303)

    def vm_status():
        from .vm_queue import status
        return status()

    @app.post("/admin/system/update-install")
    def vm_update_install(request: Request, csrf: str = Form(""), confirm: str = Form("")):
        session = current(request, admin=True)
        check_csrf(session, csrf)
        if config.deployment != "vm":
            raise HTTPException(status_code=404)
        if db.get_settings().get("update_mode")=="offline":
            raise HTTPException(status_code=400,detail="Offline-Paketliste verwenden.")
        if updater.running:
            raise HTTPException(status_code=409,detail="Gateway-Verteilung erst abschließen.")
        if vm_status().get("state") in ("queued", "preparing"):
            raise HTTPException(status_code=409, detail="Ein Update wird bereits vorbereitet.")
        checked = central_updates.status()
        if confirm != "1" or not checked.get('available') or checked.get('error'):
            raise HTTPException(status_code=400, detail="Erst prüfen und das Update bestätigen.")
        from .vm_queue import enqueue
        try:
            enqueue(checked['release']['version'], db.get_settings().get('ota_source_url', ''))
        except FileExistsError:
            raise HTTPException(status_code=409, detail="Ein Update wartet bereits auf Verarbeitung.")
        except OSError:
            raise HTTPException(status_code=503, detail="Der VM-Updatedienst ist nicht eingerichtet.")
        db.audit(session.username, 'vm_update_requested', checked['release']['version'])
        return RedirectResponse('/info#central-updates', status_code=303)

    @app.get("/info", response_class=HTMLResponse)
    def info(request: Request):
        session = current(request)
        with db.connect() as conn:
            counts = {
                "gateways": conn.execute("SELECT COUNT(*) FROM gateways").fetchone()[0],
                "sites": conn.execute("SELECT COUNT(*) FROM sites").fetchone()[0],
                "entries": conn.execute("SELECT COUNT(*) FROM entries").fetchone()[0],
                "runs": conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0],
                "logs": conn.execute("SELECT COUNT(*) FROM gateway_logs").fetchone()[0],
            }
        return render(request, "info.html", session, counts=counts, nav="info", python=sys.version.split()[0],
                      auto_update=auto_update_status(),
                      installed_release=installed_release() if session.is_admin else None,
                      central_update=central_updates.status() if session.is_admin else {},
                      vm_deployment=config.deployment == "vm",
                      vm_update_status=vm_status() if session.is_admin and config.deployment == "vm" else {},
                      storage=storage_info(), external=is_external(request), addresses=client_addresses(request),
                      scheme=request.headers.get("x-forwarded-proto") or request.url.scheme)

    def storage_info() -> dict:
        """Platzbedarf der Zentrale und freier Platz, für die Info-Seite."""
        db_file = config.db_path
        database = sum(_file_size(Path(f"{db_file}{suffix}")) for suffix in ("", "-wal", "-shm"))
        backup_files = list(config.backups_dir.glob("*.zip")) if config.backups_dir.is_dir() else []
        folders = [
            {"name": "Datenbank", "path": str(db_file), "bytes": database, "note": ""},
            {"name": "Sicherungen", "path": str(config.backups_dir), "bytes": sum(_file_size(f) for f in backup_files),
             "note": f"{len(backup_files)} Dateien, alte werden nach {db.get_settings().get('backup_keep_days', '30')} Tagen gelöscht"},
            {"name": "Programmlog", "path": str(config.log_dir), "bytes": _folder_size(config.log_dir), "note": "höchstens 6 MB"},
            {"name": "Export für die Kollegen", "path": str(config.export_dir), "bytes": _folder_size(config.export_dir), "note": ""},
        ]
        volumes = []
        for name, folder in (("Datenordner", config.data_dir), ("Exportordner", config.export_dir)):
            try:
                usage = shutil.disk_usage(folder)
            except OSError:
                continue
            volumes.append({"name": name, "path": str(folder), "free": usage.free, "total": usage.total,
                            "percent": round(100 * (usage.total - usage.free) / usage.total) if usage.total else 0})
        limit_mb = int(db.get_settings().get("alert_disk_min_mb") or 0)
        return {"folders": folders, "volumes": volumes, "alert_mb": limit_mb}

    return app


def _file_size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def _folder_size(folder: Path) -> int:
    total = 0
    try:
        for path in folder.rglob("*"):
            if path.is_file():
                total += _file_size(path)
    except OSError:
        pass
    return total


def format_bytes(value) -> str:
    """Deutsche Größenangabe: 812 KB, 12,3 MB, 1,4 GB"""
    size = float(value or 0)
    for unit in ("Bytes", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            break
        size /= 1024
    if unit in ("Bytes", "KB"):
        return f"{size:,.0f} {unit}".replace(",", ".")
    return format_number(size, 1) + " " + unit


def _safe_next(target: str) -> str:
    # Nur lokale Pfade, damit der Login nicht auf fremde Seiten umleitet.
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return "/"
    return target
