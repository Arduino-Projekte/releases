"""Unprivileged VM access requests; Linux authentication happens in the root worker."""
import fcntl
import json
import os
from pathlib import Path
import secrets
import tempfile

ROOT = Path('/var/lib/fcg-access')


def enqueue(action, *, current_password, password=None, enabled=None, root=ROOT):
    if action not in ('password', 'ssh', 'refresh'):
        raise ValueError('Unbekannte Systemaktion.')
    value = {'id': secrets.token_hex(16), 'action': action, 'current_password': current_password}
    if action == 'password':
        value['password'] = password
    if action == 'ssh':
        value['enabled'] = enabled
    request = root / 'inbox/request.json'
    with (request.parent / 'queue.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if os.path.lexists(request):
            raise FileExistsError('Eine Systemaktion wird bereits verarbeitet.')
        fd, name = tempfile.mkstemp(prefix='.request-', dir=request.parent)
        try:
            with os.fdopen(fd, 'w') as handle:
                json.dump(value, handle)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, request)
        finally:
            Path(name).unlink(missing_ok=True)
    return value['id']


def status(root=ROOT):
    try:
        data = json.loads((root / 'status.json').read_text())
        result = {k: data[k] for k in ('id', 'ok', 'message', 'at', 'ssh_enabled', 'password_change_required', 'machine_id') if k in data}
    except (OSError, ValueError, TypeError):
        result = {}
    result['pending'] = (root / 'inbox/request.json').exists()
    from .vm_runtime import request_sync,status as runtime_status
    request_sync()
    runtime=runtime_status()
    result['runtime_ready']=runtime['ready']
    result['runtime_failed']=runtime.get('failed',False)
    return result
