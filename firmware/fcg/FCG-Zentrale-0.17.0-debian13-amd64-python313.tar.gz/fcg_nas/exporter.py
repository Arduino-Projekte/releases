"""CSV-Export im Format des PowerShell-Collectors und automatischer Export.

Je Messstelle eine CSV `Seq;Datum;Zeit;Zählerstand;Verbraucht;Kraftstoffart;Aggregate`
(UTF-8 mit BOM, Semikolon, drei Nachkommastellen mit Komma, Aggregate Ja/Nein,
leeres Verbraucht = unbekannt). Der Dateiname bleibt an der Messstelle hängen
(sites.csv_stem), wie die Bindung in fcg_site_map.json. Statistikberichte liegen
wie beim PS-Collector unter _Statistik/.
"""
from __future__ import annotations

import hashlib
import io
import logging
import os
import sqlite3
import threading
import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

from . import statistics as stats
from .db import Database, now_text

log = logging.getLogger("fcg_nas.exporter")

CSV_HEADER = "Seq;Datum;Zeit;Zählerstand;Verbraucht;Kraftstoffart;Aggregate"
NEWLINE = "\r\n"
BOM = "﻿"


# --- Dateinamen -------------------------------------------------------------


def readable_stem(site_id: str, device_label: str, location: str, counter_name: str) -> str:
    """Wie Get-FcgReadableSiteStem: FCG_<Gerät>_<Standort>_<Zähler>_<sha256(site_id)[:12]>."""
    parts = []
    for value in (device_label, location, counter_name):
        part = stats.safe_file_name(value if value and value.strip() else "Unbekannt")
        parts.append(part[:40])
    digest = hashlib.sha256(site_id.encode("utf-8")).hexdigest()
    return "FCG_" + "_".join(parts) + "_" + digest[:12]


def ensure_stem(conn: sqlite3.Connection, site_id: str) -> str:
    """Vergibt einer Messstelle einmalig ihren CSV-Namen; danach bleibt er fest."""
    row = conn.execute(
        "SELECT csv_stem, device_label, location, counter_name FROM sites WHERE site_id = ?", (site_id,)
    ).fetchone()
    if row is None:
        raise KeyError(site_id)
    if row["csv_stem"]:
        return row["csv_stem"]
    base = readable_stem(site_id, row["device_label"] or "", row["location"] or "", row["counter_name"] or "")
    stem, n = base, 1
    while conn.execute("SELECT 1 FROM sites WHERE csv_stem = ?", (stem,)).fetchone():
        n += 1
        stem = f"{base}_{n}"
    conn.execute("UPDATE sites SET csv_stem = ? WHERE site_id = ?", (stem, site_id))
    return stem


def ensure_all_stems(db: Database) -> None:
    with db.transaction() as conn:
        for row in conn.execute("SELECT site_id FROM sites WHERE csv_stem IS NULL").fetchall():
            ensure_stem(conn, row["site_id"])


# --- CSV je Messstelle -------------------------------------------------------


def entry_line(row: sqlite3.Row) -> str:
    ts = row["ts"] or ""
    if row["entry_date"]:
        datum, zeit = row["entry_date"], ts[11:19]
    elif len(ts) >= 19:
        datum, zeit = ts[:10], ts[11:19]
    else:
        datum, zeit = ts, ""
    consumed = "" if row["consumed_quantity"] is None else stats.decimal3(row["consumed_quantity"])
    aggregate = "Ja" if row["additional_aggregate"] else "Nein"
    return f"{row['seq']};{datum};{zeit};{stats.decimal3(row['total_quantity'])};{consumed};{row['fuel_type'] or ''};{aggregate}"


def site_csv_text(conn: sqlite3.Connection, site_id: str) -> str:
    lines = [CSV_HEADER]
    for row in conn.execute(
        "SELECT seq, ts, entry_date, total_quantity, consumed_quantity, fuel_type, additional_aggregate "
        "FROM entries WHERE site_id = ? ORDER BY seq",
        (site_id,),
    ):
        lines.append(entry_line(row))
    return encode_lines_text(lines)


def period_csv_text(conn: sqlite3.Connection, site_id: str | None, start: str, end: str) -> str:
    """Einträge eines Zeitraums im alten CSV-Format; für alle Messstellen mit Spalte Counter davor."""
    sql = ("SELECT s.counter_name, s.csv_stem, e.seq, e.ts, e.entry_date, e.total_quantity, e.consumed_quantity, "
           "e.fuel_type, e.additional_aggregate FROM entries e JOIN sites s ON s.site_id = e.site_id "
           "WHERE e.entry_date BETWEEN ? AND ?")
    params: tuple = (start, end)
    if site_id:
        sql += " AND e.site_id = ?"
        params += (site_id,)
    sql += " ORDER BY s.csv_stem, e.seq"
    lines = [CSV_HEADER if site_id else "Counter;" + CSV_HEADER]
    for row in conn.execute(sql, params):
        line = entry_line(row)
        lines.append(line if site_id else f"{(row['counter_name'] or row['csv_stem']).replace(';', ',')};{line}")
    return encode_lines_text(lines)


def encode_lines_text(lines: list[str]) -> str:
    return BOM + NEWLINE.join(lines) + NEWLINE


def to_bytes(text: str) -> bytes:
    return text.encode("utf-8")


def site_csvs(db: Database) -> list[tuple[str, str, bytes]]:
    """[(site_id, Dateiname, Inhalt)] aller Messstellen mit Einträgen."""
    ensure_all_stems(db)
    result = []
    with db.connect() as conn:
        sites = conn.execute(
            "SELECT s.site_id, s.csv_stem FROM sites s WHERE EXISTS (SELECT 1 FROM entries e WHERE e.site_id = s.site_id) "
            "ORDER BY s.csv_stem"
        ).fetchall()
        for site in sites:
            result.append((site["site_id"], f"{site['csv_stem']}.csv", to_bytes(site_csv_text(conn, site["site_id"]))))
    return result


def stats_reports(db: Database, today: date | None = None) -> list[stats.Report]:
    s = stats.settings_from_values(db.get_settings())
    rows, names, _undated = stats.load_rows(db)
    return stats.build_reports(rows, names, s, today or date.today())


def report_bytes(report: stats.Report) -> bytes:
    return to_bytes(encode_lines_text(report.lines))


def zip_all(db: Database, today: date | None = None) -> bytes:
    """Alle CSVs und Statistikberichte als ZIP, gleiche Ordnerstruktur wie im Freigabeordner."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for _site_id, name, content in site_csvs(db):
            archive.writestr(name, content)
        for report in stats_reports(db, today):
            archive.writestr(report.path, report_bytes(report))
    return buffer.getvalue()


# --- Freigabeordner ------------------------------------------------------------


def _write_atomic(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_bytes(content)
        os.replace(tmp, path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig", errors="replace")


def report_decision(path: Path, report: stats.Report, policy: str, now: datetime | None = None) -> Path | None:
    """Wie Get-FcgReportDecision: Ziel zum Schreiben oder None (unverändert lassen)."""
    if not path.exists():
        return path
    if policy == "overwrite":
        return path
    if policy == "skip":
        return None
    old_text = _read_text(path)
    old_lines = old_text.splitlines()
    if stats.fingerprint(old_lines) == stats.fingerprint(report.lines):
        return None
    if policy == "versioned":
        stamp = (now or datetime.now()).strftime("%Y%m%d_%H%M%S")
        return path.with_name(f"{path.stem}_neu_{stamp}{path.suffix}")
    if not report.period.closed:
        return path
    # Ein Bericht aus dem noch offenen Zeitraum wird einmal abschließend neu geschrieben.
    end_next_day = datetime.combine(report.period.end + timedelta(days=1), datetime.min.time())
    written_while_open = datetime.fromtimestamp(path.stat().st_mtime) < end_next_day or "_offen;" in old_text
    if written_while_open:
        return path
    log.warning("Abgeschlossener Bericht weicht von den aktuellen Daten ab und bleibt laut Richtlinie unverändert: %s", path)
    return None


@dataclass
class ExportResult:
    ok: bool = True
    at: str = ""
    trigger: str = ""
    csv_written: int = 0
    reports_written: int = 0
    errors: list[str] = field(default_factory=list)

    def summary(self) -> str:
        text = f"{self.csv_written} CSV, {self.reports_written} Statistikberichte geschrieben"
        if self.errors:
            text += f", {len(self.errors)} Fehler: " + "; ".join(self.errors[:3])
        return text


class Exporter:
    def __init__(self, db: Database, export_dir: Path) -> None:
        self.db = db
        self.export_dir = Path(export_dir)
        self._lock = threading.Lock()
        self._last_auto_day: date | None = None

    def folder_problem(self) -> str | None:
        """Grund, warum nicht exportiert werden kann, oder None."""
        if not self.export_dir.is_dir():
            return (f"Exportordner {self.export_dir} ist im Container nicht vorhanden. "
                    "In der docker-compose.yml einen Freigabeordner nach /export einbinden.")
        if not os.access(self.export_dir, os.W_OK):
            return f"Exportordner {self.export_dir} ist nicht beschreibbar (Rechte der Freigabe prüfen)."
        return None

    def last_result(self) -> dict[str, str]:
        values = self.db.get_settings()
        return {
            "at": values.get("export_last_at", ""),
            "ok": values.get("export_last_ok", ""),
            "summary": values.get("export_last_summary", ""),
        }

    def write_folder(self, trigger: str, today: date | None = None) -> ExportResult:
        result = ExportResult(at=now_text(), trigger=trigger)
        with self._lock:
            problem = self.folder_problem()
            if problem:
                result.ok = False
                result.errors.append(problem)
            else:
                self._write(result, today or date.today())
        self.db.set_settings({
            "export_last_at": result.at,
            "export_last_ok": "1" if result.ok else "0",
            "export_last_summary": result.summary(),
        })
        level = logging.INFO if result.ok else logging.WARNING
        log.log(level, "Export (%s) nach %s: %s", trigger, self.export_dir, result.summary())
        return result

    def _write(self, result: ExportResult, today: date) -> None:
        for _site_id, name, content in site_csvs(self.db):
            path = self.export_dir / name
            try:
                if path.exists() and path.read_bytes() == content:
                    continue
                _write_atomic(path, content)
                result.csv_written += 1
            except OSError as exc:
                result.ok = False
                result.errors.append(f"{name}: {exc.strerror or exc}")
        policy = stats.settings_from_values(self.db.get_settings()).policy
        for report in stats_reports(self.db, today):
            path = self.export_dir / report.path
            try:
                target = report_decision(path, report, policy)
                if target is None:
                    continue
                _write_atomic(target, report_bytes(report))
                result.reports_written += 1
            except OSError as exc:
                # z. B. in Excel geöffnet: die übrigen Berichte trotzdem schreiben.
                result.ok = False
                result.errors.append(f"{report.path}: {exc.strerror or exc}")

    def after_run(self, added: int) -> None:
        """Nach jedem Abhollauf: exportieren, wenn neue Einträge kamen oder ein neuer Tag begann."""
        if self.db.get_settings().get("export_enabled", "1") != "1":
            return
        today = date.today()
        if added <= 0 and self._last_auto_day == today:
            return
        if self.folder_problem() and self._last_auto_day == today:
            return
        self._last_auto_day = today
        try:
            self.write_folder("auto", today)
        except Exception:  # Export darf die Abholung nie stören
            log.exception("Automatischer Export fehlgeschlagen")
