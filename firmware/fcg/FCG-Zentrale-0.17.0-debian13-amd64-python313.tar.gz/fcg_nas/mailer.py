"""Mailversand über einen SMTP-Server (z. B. den Mailserver der Firma).

Die NAS selbst ist kein Mailserver; DSM nutzt für seine Benachrichtigungen
ebenfalls einen externen SMTP-Server. Dessen Daten werden hier eingetragen.
Das Passwort liegt verschlüsselt in den Einstellungen (wie Gateway-Passwörter).
"""
from __future__ import annotations

import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from typing import Callable

from .db import Database
from .secrets_store import SecretStore

SMTP_TIMEOUT_S = 20
SECURITY = {"starttls": "STARTTLS (Port 587)", "ssl": "SSL/TLS (Port 465)", "none": "ohne Verschlüsselung (Port 25)"}


class MailError(Exception):
    pass


@dataclass
class MailSettings:
    enabled: bool
    host: str
    port: int
    security: str
    user: str
    password: str
    sender: str
    recipients: list[str]

    def problem(self) -> str:
        if not self.host:
            return "Kein SMTP-Server eingetragen."
        if not self.recipients:
            return "Kein Empfänger eingetragen."
        if not self.sender:
            return "Kein Absender eingetragen."
        return ""


def split_addresses(text: str) -> list[str]:
    parts = [p.strip() for p in (text or "").replace(";", ",").replace("\n", ",").split(",")]
    return [p for p in parts if p]


def valid_address(address: str) -> bool:
    local, _, domain = address.partition("@")
    return bool(local) and "." in domain and not any(c in address for c in " <>\r\n")


def load_settings(db: Database, secrets: SecretStore) -> MailSettings:
    values = db.get_settings()
    try:
        password = secrets.decrypt(values.get("smtp_password_enc", ""))
    except ValueError:
        password = ""
    try:
        port = int(values.get("smtp_port") or 587)
    except ValueError:
        port = 587
    return MailSettings(
        enabled=values.get("mail_enabled") == "1",
        host=values.get("smtp_host", "").strip(),
        port=port,
        security=values.get("smtp_security", "starttls"),
        user=values.get("smtp_user", "").strip(),
        password=password,
        sender=values.get("mail_from", "").strip(),
        recipients=split_addresses(values.get("mail_to", "")),
    )


def send_smtp(settings: MailSettings, subject: str, body: str) -> None:
    problem = settings.problem()
    if problem:
        raise MailError(problem)
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = settings.sender
    message["To"] = ", ".join(settings.recipients)
    message["Date"] = formatdate(localtime=True)
    message["Message-ID"] = make_msgid(domain=settings.sender.partition("@")[2] or None)
    message.set_content(body)
    try:
        if settings.security == "ssl":
            smtp: smtplib.SMTP = smtplib.SMTP_SSL(settings.host, settings.port, timeout=SMTP_TIMEOUT_S,
                                                  context=ssl.create_default_context())
        else:
            smtp = smtplib.SMTP(settings.host, settings.port, timeout=SMTP_TIMEOUT_S)
        with smtp:
            if settings.security == "starttls":
                smtp.starttls(context=ssl.create_default_context())
            if settings.user:
                smtp.login(settings.user, settings.password)
            smtp.send_message(message)
    except smtplib.SMTPAuthenticationError as exc:
        raise MailError("SMTP-Anmeldung abgelehnt. Benutzer und Passwort prüfen.") from exc
    except (smtplib.SMTPException, OSError, ssl.SSLError) as exc:
        raise MailError(f"Mail nicht gesendet: {exc}") from exc


SendFn = Callable[[MailSettings, str, str], None]


class Mailer:
    def __init__(self, db: Database, secrets: SecretStore, send: SendFn = send_smtp) -> None:
        self.db = db
        self.secrets = secrets
        self.send_fn = send

    def settings(self) -> MailSettings:
        return load_settings(self.db, self.secrets)

    def send(self, subject: str, body: str, force: bool = False) -> None:
        """Sendet, wenn Mail eingeschaltet ist (force: auch ausgeschaltet, für die Testmail)."""
        settings = self.settings()
        if not settings.enabled and not force:
            return
        self.send_fn(settings, subject, body)
