"""Resolve the built-in update source without exposing it as a user setting."""
DEFAULT_SOURCE = 'https://raw.githubusercontent.com/Arduino-Projekte/releases/main/firmware/fcg/'


def custom_source(value: str) -> str:
    value = value.strip()
    return '' if not value or value.rstrip('/') == DEFAULT_SOURCE.rstrip('/') else value


def effective_source(value: str) -> str:
    return custom_source(value) or DEFAULT_SOURCE


def public_text(value: str) -> str:
    # Includes historical diagnostic/audit messages written by older versions.
    if DEFAULT_SOURCE.rstrip('/') in value:
        value = value.replace('raw.githubusercontent.com', '[Standardziel]')
        value = value.replace('https://[Standardziel]/Arduino-Projekte/releases/main/firmware/fcg', '[Standardquelle]')
    return value.replace('https://github.com/Arduino-Projekte/releases', '[Standardquelle]')
