"""Warnungen: Zustände, um die sich jemand kümmern sollte.

Bei jeder Prüfung wird die Liste der aktuellen Probleme neu berechnet. Neue
Probleme werden geöffnet, verschwundene geschlossen. Eine Mail geht beim
Öffnen und beim Schließen, nicht bei jeder Prüfung.
"""
from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

from .db import Database, now_text
from .mailer import MailError, Mailer

log = logging.getLogger("fcg_nas.alerts")

# Wichtigkeit: err = dringend, warn = beobachten, info = Hinweis (nicht mehr aktuell)
LEVEL_TEXT = {"err": "Dringend", "warn": "Beobachten", "info": "Hinweis"}
LEVEL_ORDER = {"err": 0, "warn": 1, "info": 2}
LOG_ERROR_STALE_MINUTES = 60


@dataclass(frozen=True)
class Problem:
    key: str
    level: str  # err | warn | info
    text: str
    fingerprint: str = ""  # ändert sich bei neuen Ereignissen und hebt eine Quittierung auf


def _parse(text: str | None) -> datetime | None:
    try:
        return datetime.strptime(text or "", "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _title(row) -> str:
    return row["label"] or row["counter_name"] or row["host"]


def current_problems(db: Database, data_dir: Path, export_problem: str = "", backup_problem: str = "") -> list[Problem]:
    settings = db.get_settings()
    offline_hours = max(1, int(settings.get("alert_offline_hours") or 2))
    disk_min_mb = max(0, int(settings.get("alert_disk_min_mb") or 0))
    now = datetime.now()
    problems: list[Problem] = []
    with db.connect() as conn:
        gateways = conn.execute("SELECT * FROM gateways WHERE enabled = 1 ORDER BY id").fetchall()
    for gw in gateways:
        last_ok = _parse(gw["last_ok_at"])
        since = last_ok or _parse(gw["created_at"])
        if gw["last_attempt_at"] and since and now - since > timedelta(hours=offline_hours):
            age = int((now - since).total_seconds() // 3600)
            reason = f" Letzter Fehler: {gw['last_error']}" if gw["last_error"] else ""
            problems.append(Problem(f"offline:{gw['id']}", "err",
                                    f"{_title(gw)} ({gw['host']}) seit {age} Stunden nicht abgeholt.{reason}"))
        elif gw["last_error"] and (last_ok is None or (_parse(gw["last_attempt_at"]) or now) > last_ok):
            problems.append(Problem(f"error:{gw['id']}", "warn",
                                    f"{_title(gw)} ({gw['host']}): {gw['last_error']}"))
        if gw["demo_mode"]:
            problems.append(Problem(f"demo:{gw['id']}", "warn",
                                    f"{_title(gw)} ({gw['host']}) liefert Demo-Daten."))
    if disk_min_mb:
        try:
            free_mb = shutil.disk_usage(data_dir).free // (1024 * 1024)
            if free_mb < disk_min_mb:
                problems.append(Problem("disk", "err", f"Nur noch {free_mb} MB frei im Datenordner (Grenze {disk_min_mb} MB)."))
        except OSError:
            pass
    if export_problem:
        problems.append(Problem("export", "warn", f"Automatischer Export: {export_problem}"))
    if backup_problem:
        problems.append(Problem("backup", "err", f"Sicherung: {backup_problem}"))
    return problems


def storage_problems(db: Database, live=None) -> dict[str, Problem]:
    """Speicherfehler der Gateways, für alle Konten sichtbar.

    Quellen: persisted_state aus /api/counter (Livewerte, ohne Login, alle 30 s)
    und health aus /api/collector (ab Firmware V0.21.46, bei jeder Abholung).
    Ältere Firmware liefert beides nicht; dann wird nichts gemeldet.
    """
    problems: dict[str, Problem] = {}
    with db.connect() as conn:
        gateways = conn.execute("SELECT id, label, counter_name, host, health_json FROM gateways WHERE enabled = 1").fetchall()
    for gw in gateways:
        try:
            health = json.loads(gw["health_json"]) if gw["health_json"] else {}
        except ValueError:
            health = {}
        health = health if isinstance(health, dict) else {}
        persistence = health.get("counter_persistence") if isinstance(health.get("counter_persistence"), dict) else {}
        failed, error = persistence.get("last_save_failed"), str(persistence.get("last_save_error") or "")
        state = live.state(gw["id"]) if live is not None else None
        if state is not None and state.ok and state.save_failed is not None:
            failed, error = state.save_failed, state.save_error  # aktueller als die letzte Abholung
        if failed is True:
            reason = f" Meldung: {error}." if error else ""
            problems[f"persist:{gw['id']}"] = Problem(
                f"persist:{gw['id']}", "err",
                f"{_title(gw)} ({gw['host']}) kann den Zählerstand nicht speichern.{reason} "
                "Bei einem Neustart gehen die Impulse seit der letzten Speicherung verloren.")
        nvs = health.get("nvs") if isinstance(health.get("nvs"), dict) else {}
        if nvs.get("low") is True:
            free = nvs.get("available_entries")
            amount = f"nur noch {free} Einträge frei" if isinstance(free, int) else "fast voll"
            problems[f"nvs:{gw['id']}"] = Problem(
                f"nvs:{gw['id']}", "warn", f"{_title(gw)} ({gw['host']}): Gerätespeicher (NVS) {amount}.")
    return problems


SILENCE_REFERENCE_DAYS = 90
SILENCE_MIN_FILL_DAYS = 5
LOG_ERROR_HOURS = 24


def _median(values: list[float]) -> float:
    ordered = sorted(values)
    middle = len(ordered) // 2
    return ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2


def silence_problems(db: Database, today: date | None = None) -> dict[str, Problem]:
    """Messstellen, die viel länger als üblich keinen Füllvorgang hatten.

    Üblich heißt: der mittlere Abstand (Median) zwischen zwei Tagen mit
    Füllvorgang in den letzten 90 Tagen. Gemeldet wird ab Faktor x diesem
    Abstand, frühestens nach alert_silence_min_days. So fällt ein abgeklemmter
    Impulsgeber auf, ohne dass selten genutzte Tanks dauernd warnen.
    """
    settings = db.get_settings()
    factor = int(settings.get("alert_silence_factor") or 0)
    if factor <= 0:
        return {}
    min_days = max(1, int(settings.get("alert_silence_min_days") or 2))
    today = today or date.today()
    since = (today - timedelta(days=SILENCE_REFERENCE_DAYS)).isoformat()
    problems: dict[str, Problem] = {}
    with db.connect() as conn:
        sites = conn.execute(
            "SELECT s.site_id, s.counter_name, g.label, g.host FROM sites s JOIN gateways g ON g.id = s.gateway_id "
            "WHERE g.enabled = 1").fetchall()
        for site in sites:
            days = [date.fromisoformat(r[0]) for r in conn.execute(
                "SELECT DISTINCT entry_date FROM entries WHERE site_id = ? AND entry_date >= ? "
                "AND consumed_quantity > 0 ORDER BY entry_date", (site["site_id"], since))]
            if len(days) < SILENCE_MIN_FILL_DAYS:
                continue
            usual = _median([(b - a).days for a, b in zip(days, days[1:])])
            limit = max(min_days, factor * usual)
            quiet = (today - days[-1]).days
            if quiet > limit:
                title = site["label"] or site["counter_name"] or site["site_id"]
                usual_text = "täglich" if usual <= 1 else f"etwa alle {usual:g} Tage".replace(".", ",")
                key = f"silent:{site['site_id']}"
                problems[key] = Problem(
                    key, "warn", f"{title} ({site['host']}): seit {quiet} Tagen kein Füllvorgang, sonst {usual_text}. "
                                 "Impulsgeber und Verkabelung prüfen.")
    return problems


def _short(text: str, limit: int = 160) -> str:
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def log_error_problems(db: Database, now: datetime | None = None) -> dict[str, Problem]:
    """Fehler (Stufe E) im Ereignislog der Gateways in den letzten 24 Stunden.

    Liegt der letzte Fehler über eine Stunde zurück, ist es nur noch ein
    Hinweis (Stufe info): das Problem besteht vermutlich nicht mehr.
    """
    if db.get_settings().get("alert_log_errors", "1") != "1":
        return {}
    now = now or datetime.now()
    since = (now - timedelta(hours=LOG_ERROR_HOURS)).strftime("%Y-%m-%d %H:%M:%S")
    stale_before = (now - timedelta(minutes=LOG_ERROR_STALE_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
    problems: dict[str, Problem] = {}
    with db.connect() as conn:
        rows = conn.execute(
            """
            SELECT l.gateway_id, l.host, g.label, g.counter_name, COUNT(*) AS n, COUNT(DISTINCT l.message) AS kinds,
              MAX(l.id) AS last_id, MAX(l.fetched_at) AS last_at
            FROM gateway_logs l JOIN gateways g ON g.id = l.gateway_id
            WHERE l.level = 'E' AND l.fetched_at >= ? AND g.enabled = 1
            GROUP BY l.gateway_id
            """, (since,)).fetchall()
        last = {r["gateway_id"]: r for r in conn.execute(
            "SELECT gateway_id, area, message FROM gateway_logs WHERE id IN ({})".format(
                ",".join(str(int(r["last_id"])) for r in rows) or "0"))}
    for row in rows:
        title = row["label"] or row["counter_name"] or row["host"]
        count = "1 Fehler" if row["n"] == 1 else f"{row['n']} Fehler"
        if row["kinds"] > 1:
            count += f" ({row['kinds']} verschiedene)"
        latest = last.get(row["gateway_id"])
        latest_text = _short(f"{latest['area']}: {latest['message']}") if latest else ""
        stale = row["last_at"] < stale_before
        when = row["last_at"][11:16]
        if row["last_at"][:10] != now.strftime("%Y-%m-%d"):
            when = f"{row['last_at'][8:10]}.{row['last_at'][5:7]}. {when}"
        key = f"logerr:{row['gateway_id']}"
        if stale:
            text = (f"{title} ({row['host']}): {count} im Gateway-Log, der letzte um {when}, seitdem keine neuen. "
                    f"Zuletzt: {latest_text}")
        else:
            text = f"{title} ({row['host']}): {count} im Gateway-Log in den letzten 24 Stunden, zuletzt um {when}: {latest_text}"
        problems[key] = Problem(key, "info" if stale else "warn", text, fingerprint=str(row["last_id"]))
    return problems


class Alerts:
    def __init__(self, db: Database, mailer: Mailer, data_dir: Path) -> None:
        self.db = db
        self.mailer = mailer
        self.data_dir = Path(data_dir)
        # Weitere Quellen (Export, Sicherung, OTA) melden ihren Zustand hier.
        self.sources: list = []

    def evaluate(self) -> tuple[list[dict], list[dict]]:
        """Gleicht offene Warnungen ab. Liefert (neu geöffnet, geschlossen)."""
        extra = {}
        for source in self.sources:
            try:
                extra.update(source())
            except Exception:
                log.exception("Warnquelle fehlgeschlagen")
        problems = {p.key: p for p in current_problems(self.db, self.data_dir, extra.get("export", ""),
                                                       extra.get("backup", ""))}
        for key, value in extra.items():
            if isinstance(value, Problem):
                problems[key] = value
            elif key not in ("export", "backup") and value:
                problems[key] = Problem(key, "warn", value)
        now = now_text()
        opened, closed = [], []
        with self.db.transaction() as conn:
            open_rows = {r["key"]: r for r in conn.execute("SELECT * FROM alerts WHERE closed_at IS NULL")}
            for key, problem in problems.items():
                row = open_rows.get(key)
                if row is not None:
                    # Neues Ereignis oder höhere Wichtigkeit: Quittierung aufheben.
                    renewed = (problem.fingerprint != row["fingerprint"]
                               or LEVEL_ORDER.get(problem.level, 1) < LEVEL_ORDER.get(row["level"], 1))
                    conn.execute(
                        "UPDATE alerts SET last_seen_at = ?, text = ?, level = ?, fingerprint = ?"
                        + (", acked_at = NULL, acked_by = NULL" if renewed else "") + " WHERE id = ?",
                        (now, problem.text, problem.level, problem.fingerprint, row["id"]))
                    if problem.level != "info" and LEVEL_ORDER.get(problem.level, 1) < LEVEL_ORDER.get(row["level"], 1):
                        # wichtiger geworden, z. B. aus einem Hinweis wieder ein aktueller Fehler
                        opened.append({"id": row["id"], "level": problem.level, "text": problem.text})
                else:
                    alert_id = conn.execute(
                        "INSERT INTO alerts(key, level, text, opened_at, last_seen_at, fingerprint) VALUES(?, ?, ?, ?, ?, ?)",
                        (key, problem.level, problem.text, now, now, problem.fingerprint)).lastrowid
                    if problem.level != "info":   # Hinweise ohne Mail
                        opened.append({"id": alert_id, "level": problem.level, "text": problem.text})
            for key, row in open_rows.items():
                if key not in problems:
                    conn.execute("UPDATE alerts SET closed_at = ? WHERE id = ?", (now, row["id"]))
                    if row["level"] != "info" and not row["acked_at"]:
                        closed.append({"id": row["id"], "level": row["level"], "text": row["text"]})
            conn.execute("DELETE FROM alerts WHERE closed_at IS NOT NULL AND closed_at < ?",
                         ((datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S"),))
        if opened or closed:
            self._mail(opened, closed)
        return opened, closed

    def _mail(self, opened: list[dict], closed: list[dict]) -> None:
        if not self.mailer.settings().enabled:
            return
        lines = []
        if opened:
            lines.append("Neue Warnungen:")
            lines += [f"- {LEVEL_TEXT.get(a['level'], a['level'])}: {a['text']}" for a in opened]
        if closed:
            if lines:
                lines.append("")
            lines.append("Wieder in Ordnung:")
            lines += [f"- {a['text']}" for a in closed]
        lines += ["", f"Offene Warnungen insgesamt: {len(self.open_alerts())}", "", "FCG Zentrale"]
        subject = f"FCG Zentrale: {len(opened)} neue Warnung(en)" if opened else "FCG Zentrale: Warnung behoben"
        try:
            self.mailer.send(subject, "\n".join(lines))
        except MailError as exc:
            log.warning("Warnmail nicht gesendet: %s", exc)
            return
        with self.db.connect() as conn:
            for a in opened:
                conn.execute("UPDATE alerts SET mailed_open = 1 WHERE id = ?", (a["id"],))
            for a in closed:
                conn.execute("UPDATE alerts SET mailed_closed = 1 WHERE id = ?", (a["id"],))

    def open_alerts(self, acked: bool = False) -> list[dict]:
        """Offene Warnungen, wichtigste zuerst. acked=True: nur die quittierten."""
        with self.db.connect() as conn:
            rows = [dict(r) for r in conn.execute(
                "SELECT * FROM alerts WHERE closed_at IS NULL AND (acked_at IS NOT NULL) = ? ORDER BY opened_at",
                (int(acked),))]
        from .update_source import public_text
        for row in rows:
            row['text'] = public_text(row['text'])
        return sorted(rows, key=lambda r: LEVEL_ORDER.get(r["level"], 1))

    def acknowledge(self, alert_id: int, username: str) -> dict | None:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM alerts WHERE id = ? AND closed_at IS NULL", (alert_id,)).fetchone()
            if row is None:
                return None
            conn.execute("UPDATE alerts SET acked_at = ?, acked_by = ? WHERE id = ?", (now_text(), username, alert_id))
        return dict(row)

    def unacknowledge(self, alert_id: int) -> dict | None:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM alerts WHERE id = ? AND closed_at IS NULL", (alert_id,)).fetchone()
            if row is None:
                return None
            conn.execute("UPDATE alerts SET acked_at = NULL, acked_by = NULL WHERE id = ?", (alert_id,))
        return dict(row)

    def recent_closed(self, limit: int = 20) -> list[dict]:
        with self.db.connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT * FROM alerts WHERE closed_at IS NOT NULL ORDER BY closed_at DESC LIMIT ?", (limit,))]
