"""Display release information; this does not install or authorize an update."""
import hashlib
import json
import re
from pathlib import Path

from . import __version__
from .db import now_text
from .image_updates import latest_image
from .ota import OtaError
from .update_source import effective_source, public_text

MAX_BYTES = 32 * 1024


def version_key(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{1,6}\.\d{1,6}\.\d{1,6}', value):
        raise ValueError('Ungültige Versionsangabe.')
    return tuple(map(int, value.split('.')))


def parse_release(raw):
    if len(raw) > MAX_BYTES:
        raise ValueError('Versionshinweise sind zu groß.')
    value = json.loads(raw)
    if not isinstance(value, dict) or value.get('schema') != 'fcg_central_release_v1':
        raise ValueError('Unbekanntes Format der Versionshinweise.')
    version_key(value.get('version'))
    notes = value.get('notes', {})
    if not isinstance(notes, dict) or any(not isinstance(v, str) or len(v) > 12000 for v in notes.values()):
        raise ValueError('Ungültige Versionshinweise.')
    return {'version': value['version'], 'notes': {k: public_text(v) for k, v in notes.items() if k in ('de', 'en')}}


def installed_release():
    release = parse_release(Path(__file__).with_name('release.json').read_bytes())
    if release['version'] != __version__:
        raise ValueError('Versionshinweise passen nicht zur installierten Version.')
    return release


class CentralUpdates:
    def __init__(self, db, fetch, deployment="docker"):
        self.db, self.fetch, self.deployment = db, fetch, deployment

    def check(self):
        if self.db.get_settings().get('update_mode')=='offline':return {'offline':True}
        base = effective_source(self.db.get_settings().get('ota_source_url', '')).rstrip('/') + '/'
        try:
            # Read the version from the actual published image, not just a
            # release announcement which may precede the image build.
            if self.deployment == 'vm':
                from .vm_package import verify_manifest
                m = verify_manifest(self.fetch(base + 'vm-update.json', MAX_BYTES))
                state = {'checked_at': now_text(), 'release': {'version': m['version'], 'notes': m['notes']}}
            else:
                version = latest_image()
                state = {'checked_at': now_text(), 'release': {'version': version, 'notes': {}}}
                try:
                    release = parse_release(self.fetch(base + 'central-update.json', MAX_BYTES))
                    if release['version'] == version:
                        state['release'] = release
                except (OtaError, ValueError, UnicodeError, OSError):
                    pass  # The image check succeeds even if optional notes are missing.
        except (OtaError, ValueError, UnicodeError, OSError, TypeError, AttributeError):
            state = {'checked_at': now_text(), 'error': True}
        state['source'] = hashlib.sha256((base + ('|vm' if self.deployment == 'vm' else '')).encode()).hexdigest()
        self.db.set_settings({'central_update_check': json.dumps(state, ensure_ascii=False)})
        return state

    def status(self):
        if self.db.get_settings().get('update_mode')=='offline':return {'offline':True}
        try:
            state = json.loads(self.db.get_settings().get('central_update_check', '{}'))
            base = effective_source(self.db.get_settings().get('ota_source_url', '')).rstrip('/') + '/'
            if not isinstance(state, dict) or state.get('source') != hashlib.sha256((base + ('|vm' if self.deployment == 'vm' else '')).encode()).hexdigest():
                return {}
            if 'release' in state:
                state['release'] = parse_release(json.dumps({'schema': 'fcg_central_release_v1', **state['release']}))
                state['available'] = version_key(state['release']['version']) > version_key(__version__)
            return state
        except (ValueError, TypeError, UnicodeError):
            return {}
