"""FuelCounterGateway NAS-Collector.

Holt die Zählerhistorie der Gateways über /api/collector ab, speichert sie
in einer SQLite-Datenbank und zeigt sie auf einer Webseite an.
"""

__version__ = "0.17.0"
