"""Gateway-Liste aus dem PowerShell-Collector übernehmen.

fcg_ips.txt: eine IP oder ein Hostname pro Zeile, # und Leerzeilen zählen nicht.
fcg_config.json (optional): weitere IPs unter "ips", Collector-Login unter
"auth" und Abruf- und Statistikeinstellungen. Gelesen wird nur, was der
NAS-Collector auch kennt; Pfade wie default_output_dir gelten hier nicht.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from . import statistics as stats
from .db import Database
from .gateway_client import normalize_host

MAX_HOSTS = 500

# fcg_config.json -> Einstellung im NAS-Collector, mit erlaubtem Bereich
FETCH_KEYS = {
    "limit": ("limit", 1, 100),
    "timeout_sec": ("timeout_sec", 5, 600),
    "max_pages_per_gateway": ("max_pages_per_gateway", 1, 100000),
}


@dataclass
class HostLine:
    raw: str
    host: str = ""
    error: str = ""
    source: str = ""


@dataclass
class ConfigImport:
    hosts: list[HostLine] = field(default_factory=list)
    username: str = ""
    password: str = ""
    has_auth: bool = False
    settings: dict[str, str] = field(default_factory=dict)
    problems: list[str] = field(default_factory=list)


def _decode(data: bytes) -> str:
    return data.decode("utf-8-sig", errors="replace")


def parse_ip_list(text: str, source: str) -> list[HostLine]:
    lines = []
    for raw in text.splitlines():
        value = raw.strip()
        if not value or value.startswith("#"):
            continue
        lines.append(_host_line(value, source))
    return lines


def _host_line(value: str, source: str) -> HostLine:
    try:
        return HostLine(raw=value, host=normalize_host(value), source=source)
    except ValueError as exc:
        return HostLine(raw=value, error=str(exc), source=source)


def _flag(obj: dict, names: tuple[str, ...], default: bool) -> bool:
    for name in names:
        if name in obj:
            value = obj[name]
            if isinstance(value, str):
                return value.strip().lower() in ("1", "true", "ja", "yes")
            return bool(value)
    return default


def parse_config(data: bytes, result: ConfigImport) -> None:
    try:
        cfg = json.loads(_decode(data))
    except ValueError as exc:
        result.problems.append(f"fcg_config.json ist kein gültiges JSON: {exc}")
        return
    if not isinstance(cfg, dict):
        result.problems.append("fcg_config.json enthält kein JSON-Objekt.")
        return
    for value in cfg.get("ips") or []:
        if str(value).strip():
            result.hosts.append(_host_line(str(value).strip(), "fcg_config.json"))

    auth = cfg.get("auth") if isinstance(cfg.get("auth"), dict) else {}
    mode = str(auth.get("mode") or "basic").lower()
    if auth and mode == "basic":
        result.username = str(auth.get("username") or "")[:64]
        result.password = str(auth.get("password") or "")
        result.has_auth = bool(result.username)
    elif auth and mode not in ("", "none"):
        result.problems.append(f"Anmeldeart '{mode}' wird nicht übernommen, nur basic (Benutzer und Passwort).")

    for key, (setting, low, high) in FETCH_KEYS.items():
        if key in cfg:
            try:
                value = int(cfg[key])
            except (TypeError, ValueError):
                result.problems.append(f"{key}: keine Zahl, nicht übernommen.")
                continue
            if low <= value <= high:
                result.settings[setting] = str(value)
            else:
                result.problems.append(f"{key}={value} liegt nicht zwischen {low} und {high}, nicht übernommen.")

    statistics = cfg.get("statistics") if isinstance(cfg.get("statistics"), dict) else None
    if statistics is not None:
        _parse_statistics(statistics, result)


def _parse_statistics(cfg: dict, result: ConfigImport) -> None:
    # Gleiche Schalter und Vorgaben wie Get-FcgStatsSettings im PowerShell-Collector.
    enabled = _flag(cfg, ("enabled", "aktiv"), True)
    monthly = _flag(cfg, ("monthly_enabled",), True)
    values = {
        "stats_calendar_month": enabled and monthly and _flag(cfg, ("calendar_month_enabled", "kalendermonat_enabled"), True),
        "stats_cutoff_month": enabled and monthly and _flag(cfg, ("cutoff_month_enabled", "stichtag_enabled"), True),
        "stats_annual": enabled and _flag(cfg, ("annual_enabled",), False),
        "stats_include_open": _flag(cfg, ("include_open_period_preview", "offene_periode"), True),
        "stats_per_site": _flag(cfg, ("per_gateway_enabled", "counter_reports_enabled"), True),
        "stats_overall": _flag(cfg, ("overall_enabled", "gesamt_enabled"), True),
    }
    result.settings.update({k: "1" if v else "0" for k, v in values.items()})
    for name in ("monthly_cutoff_day", "stichtag_tag", "cutoff_day"):
        if name in cfg:
            try:
                day = int(cfg[name])
            except (TypeError, ValueError):
                day = 0
            if 1 <= day <= 28:
                result.settings["stats_cutoff_day"] = str(day)
            else:
                result.problems.append(f"{name}={cfg[name]}: Tag 1-28 erwartet, nicht übernommen.")
            break
    if "annual_cutoff_day_month" in cfg:
        try:
            day, month = stats.parse_annual(str(cfg["annual_cutoff_day_month"]))
            result.settings["stats_annual_day_month"] = f"{day:02d}.{month:02d}"
        except ValueError as exc:
            result.problems.append(f"{exc}, nicht übernommen.")
    policy = str(cfg.get("existing_report_policy") or "")
    if policy:
        if policy in stats.POLICIES:
            result.settings["stats_policy"] = policy
        else:
            result.problems.append(f"existing_report_policy '{policy}' ist unbekannt, nicht übernommen.")


def read_uploads(files: list[tuple[str, bytes]]) -> ConfigImport:
    result = ConfigImport()
    found = False
    for name, data in files:
        lower = name.lower()
        if lower.endswith(".txt"):
            result.hosts.extend(parse_ip_list(_decode(data), name))
            found = True
        elif lower.endswith(".json"):
            parse_config(data, result)
            found = True
        else:
            result.problems.append(f"{name}: weder .txt noch .json, ignoriert.")
    if not found:
        result.problems.append("Keine fcg_ips.txt oder fcg_config.json gefunden.")
    # doppelte Adressen nur einmal
    seen: set[str] = set()
    unique = []
    for line in result.hosts:
        key = line.host.lower() if line.host else ""
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        unique.append(line)
    result.hosts = unique[:MAX_HOSTS]
    return result


def preview_rows(db: Database, hosts: list[HostLine]) -> list[dict]:
    with db.connect() as conn:
        existing = {r["host"].lower(): r for r in conn.execute("SELECT id, host, label, counter_name, enabled FROM gateways")}
    rows = []
    for line in hosts:
        row = {"raw": line.raw, "host": line.host, "error": line.error, "source": line.source}
        if line.error:
            row["status"] = "invalid"
        elif line.host.lower() in existing:
            gateway = existing[line.host.lower()]
            row["status"] = "existing"
            row["title"] = gateway["label"] or gateway["counter_name"] or ""
            row["enabled"] = bool(gateway["enabled"])
        else:
            row["status"] = "new"
        rows.append(row)
    return rows


def to_staged(result: ConfigImport, encrypt) -> bytes:
    """Für die Vorschau zwischenspeichern; das Passwort nur verschlüsselt."""
    return json.dumps({
        "hosts": [line.__dict__ for line in result.hosts],
        "username": result.username,
        "password_enc": encrypt(result.password) if result.has_auth else "",
        "has_auth": result.has_auth,
        "settings": result.settings,
        "problems": result.problems,
    }).encode("utf-8")


def from_staged(data: bytes) -> dict[str, Any]:
    staged = json.loads(data.decode("utf-8"))
    staged["hosts"] = [HostLine(**line) for line in staged["hosts"]]
    return staged
