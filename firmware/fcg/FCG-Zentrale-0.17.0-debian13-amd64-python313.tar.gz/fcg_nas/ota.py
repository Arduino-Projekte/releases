"""OTA-Spiegel: neue Firmware aus dem releases-Repo holen und nach Freigabe bereitstellen.

Ersetzt tools/fcg_publish_ota.bat. Ablauf:
1. Regelmäßig update.json von github.com/Arduino-Projekte/releases (firmware/fcg) laden.
2. Manifest prüfen wie die Firmware: Schema, Dateiname, Signatur (ECDSA P-256
   über den kanonischen Text aus tools/fcg_sign_update.ps1) mit dem
   öffentlichen Schlüssel aus fcg_main/fcg_ota_trust.local.h.
3. Firmware laden und gegen den signierten SHA-256 prüfen. Die Version wartet
   dann auf Freigabe.
4. Erst wenn der Admin freigibt, kommen .bin und zuletzt update.json in den
   Webordner der NAS (/ota = web/fcg_update). So sieht kein Gateway ein
   Manifest, dessen Firmware noch fehlt.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import logging
import os
import re
import shutil
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from .db import Database, now_text

log = logging.getLogger("fcg_nas.ota")

# Öffentlicher Schlüssel wie in fcg_main/fcg_ota_trust.local.h (kein Geheimnis).
TRUSTED_KEYS = {
    "prod-2026-09": (
        "-----BEGIN PUBLIC KEY-----\n"
        "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjOvtA2rPJ1dNweF/ShGflUG1HQBE\n"
        "FW9ToK3KbZCtpt33TQ94bCADfXU0F4Xql3YJlJAjHOcNbKsdgsUii8liMg==\n"
        "-----END PUBLIC KEY-----\n"
    ),
}
SIGNED_FIELDS = ("schema", "project", "target", "board_profile", "version", "file", "url", "min_version",
                 "sha256", "key_id", "signature_algorithm")
VERSION_PATTERN = re.compile(r"^V\d{1,6}\.\d{1,6}\.\d{1,6}$")
MAX_MANIFEST_BYTES = 64 * 1024
MAX_FIRMWARE_BYTES = 8 * 1024 * 1024
TIMEOUT_S = 60
LEGACY_BIN = "fcg_main.ino.bin"


class OtaError(Exception):
    def __init__(self, message):
        from .update_source import public_text
        super().__init__(public_text(str(message)))


DownloadFn = Callable[[str, int], bytes]


def download(url: str, max_bytes: int) -> bytes:
    if not url.startswith("https://"):
        raise OtaError("Quelle muss mit https:// beginnen.")
    request = urllib.request.Request(url, headers={"Cache-Control": "no-cache", "User-Agent": "fcg-nas-collector"})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_S) as response:
            data = response.read(max_bytes + 1)
    except urllib.error.HTTPError as exc:
        raise OtaError(f"HTTP {exc.code} beim Laden von {url}") from exc
    except (urllib.error.URLError, OSError) as exc:
        raise OtaError(f"{url} nicht erreichbar: {getattr(exc, 'reason', exc)}") from exc
    if len(data) > max_bytes:
        raise OtaError(f"{url} ist größer als erlaubt.")
    return data


def version_key(version: str) -> tuple[int, ...]:
    if not VERSION_PATTERN.match(version or ""):
        return (0,)
    return tuple(int(p) for p in version[1:].split("."))


def canonical_payload(manifest: dict) -> bytes:
    lines = ["FCG-OTA-SIGNED-PAYLOAD-V2"] + [f"{name}={manifest.get(name, '')}" for name in SIGNED_FIELDS]
    return ("\n".join(lines) + "\n").encode("utf-8")


def parse_manifest(raw: bytes, trusted: dict[str, str] | None = None) -> dict:
    """Prüft ein update.json wie die Firmware. Liefert das Manifest oder wirft OtaError."""
    trusted = TRUSTED_KEYS if trusted is None else trusted
    try:
        manifest = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise OtaError("update.json ist kein gültiges JSON.") from exc
    if not isinstance(manifest, dict):
        raise OtaError("update.json enthält kein JSON-Objekt.")
    if manifest.get("schema") != "fcg_ota_manifest_v2":
        raise OtaError(f"Unerwartetes Manifest-Schema: {manifest.get('schema')}")
    if manifest.get("project") != "fcg_main":
        raise OtaError(f"Manifest gehört nicht zu fcg_main: {manifest.get('project')}")
    version = str(manifest.get("version", ""))
    if not VERSION_PATTERN.match(version):
        raise OtaError(f"Ungültige Version im Manifest: {version}")
    if manifest.get("file") != f"fcg_main_{version}.bin":
        raise OtaError(f"Unerwarteter Dateiname im Manifest: {manifest.get('file')}")
    if not re.fullmatch(r"[0-9a-f]{64}", str(manifest.get("sha256", ""))):
        raise OtaError("SHA-256 im Manifest ist ungültig.")
    for name in SIGNED_FIELDS:
        value = str(manifest.get(name, ""))
        if not value or any(not 0x20 <= ord(c) <= 0x7E for c in value):
            raise OtaError(f"Feld {name} fehlt oder enthält ungültige Zeichen.")
    if manifest.get("signature_algorithm") != "ecdsa-p256-sha256":
        raise OtaError(f"Unbekanntes Signaturverfahren: {manifest.get('signature_algorithm')}")
    key_pem = trusted.get(str(manifest.get("key_id")))
    if not key_pem:
        raise OtaError(f"Unbekannter Signaturschlüssel {manifest.get('key_id')}. "
                       "Bei einem neuen Schlüssel muss auch die FCG Zentrale aktualisiert werden.")
    try:
        signature = base64.b64decode(str(manifest.get("signature", "")), validate=True)
        key = load_pem_public_key(key_pem.encode("ascii"))
        if not isinstance(key, ec.EllipticCurvePublicKey):
            raise OtaError("Vertrauensschlüssel ist kein EC-Schlüssel.")
        key.verify(signature, canonical_payload(manifest), ec.ECDSA(hashes.SHA256()))
    except (InvalidSignature, binascii.Error, ValueError) as exc:
        raise OtaError("Signatur von update.json ist ungültig. Die Version wird nicht übernommen.") from exc
    return manifest


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_atomic(target: Path, data: bytes) -> None:
    partial = target.with_name(target.name + ".part")
    partial.write_bytes(data)
    os.replace(partial, target)


@dataclass
class PublishedState:
    version: str = ""
    file: str = ""
    present: bool = False
    error: str = ""


class OtaMirror:
    def __init__(self, db: Database, cache_dir: Path, ota_dir: Path, fetch: DownloadFn = download,
                 trusted: dict[str, str] | None = None) -> None:
        self.db = db
        self.cache_dir = Path(cache_dir)
        self.ota_dir = Path(ota_dir)
        self.fetch = fetch
        self.trusted = TRUSTED_KEYS if trusted is None else trusted
        self._lock = threading.RLock()
        self.deployment_busy = lambda: False

    # --- Zustand ----------------------------------------------------------

    def folder_problem(self) -> str:
        if not self.ota_dir.is_dir():
            return (f"OTA-Ordner {self.ota_dir} ist im Container nicht vorhanden. In der docker-compose.yml "
                    "den Webordner der NAS (web/fcg_update) nach /ota einbinden.")
        if not os.access(self.ota_dir, os.W_OK):
            return f"OTA-Ordner {self.ota_dir} ist nicht beschreibbar (Rechte der Freigabe web prüfen)."
        return ""

    def published(self) -> PublishedState:
        state = PublishedState()
        manifest_path = self.ota_dir / "update.json"
        if not manifest_path.is_file():
            return state
        try:
            manifest = json.loads(manifest_path.read_bytes().decode("utf-8-sig"))
            state.version = str(manifest.get("version", ""))
            state.file = str(manifest.get("file", ""))
            state.present = bool(state.file) and (self.ota_dir / Path(state.file).name).is_file()
        except (OSError, ValueError, AttributeError) as exc:
            state.error = f"update.json im OTA-Ordner nicht lesbar: {exc}"
        return state

    def releases(self) -> list[dict]:
        with self.db.connect() as conn:
            rows = [dict(r) for r in conn.execute("SELECT * FROM ota_releases")]
        for row in rows:
            manifest = json.loads(row["manifest"])
            row["min_version"] = manifest.get("min_version", "")
            row["url"] = manifest.get("url", "")
            from .update_source import public_text
            notes = manifest.get("notes", "")
            row["notes"] = public_text(notes[:12000]) if isinstance(notes, str) else ""
            row["cached"] = (self.cache_dir / row["version"] / row["file"]).is_file()
        return sorted(rows, key=lambda r: version_key(r["version"]), reverse=True)

    def last_check(self) -> dict[str, str]:
        values = self.db.get_settings()
        from .update_source import public_text
        return {"at": values.get("ota_last_check_at", ""), "ok": values.get("ota_last_check_ok", ""),
                "summary": public_text(values.get("ota_last_check_summary", ""))}

    def problems(self) -> dict[str, str]:
        """Für die Warnungen: wartende Freigabe und anhaltende Prüffehler."""
        if self.db.get_settings().get("ota_enabled") != "1":
            return {}
        result = {}
        pending = [r["version"] for r in self.releases() if r["status"] == "pending"]
        if pending:
            result["ota_pending"] = f"Firmware {pending[0]} ist geprüft und wartet auf Freigabe."
        last = self.last_check()
        if last["ok"] == "0" and self.db.get_settings().get("update_mode")!="offline":
            result["ota_check"] = f"OTA-Spiegel: {last['summary']}"
        return result

    # --- Prüfen -----------------------------------------------------------

    def check(self) -> str:
        """Holt das aktuelle Manifest. Liefert eine Zusammenfassung; Fehler werden gemerkt und geworfen."""
        with self._lock:
            if self.db.get_settings().get("update_mode")=="offline":
                raise OtaError("Offline-Betrieb aktiv. Pakete unter Offline-Updates von SMB einlesen.")
            try:
                summary = self._check()
            except OtaError as exc:
                self._remember(False, str(exc))
                raise
            self._remember(True, summary)
            return summary

    def _check(self) -> str:
        from .update_source import effective_source
        base = effective_source(self.db.get_settings().get("ota_source_url", ""))
        if not base.endswith("/"):
            base += "/"
        raw = self.fetch(base + "update.json", MAX_MANIFEST_BYTES)
        manifest = parse_manifest(raw, self.trusted)
        version = manifest["version"]
        with self.db.connect() as conn:
            known = conn.execute("SELECT status FROM ota_releases WHERE version = ?", (version,)).fetchone()
        folder = self.cache_dir / version
        if known and (folder / manifest["file"]).is_file():
            return f"Aktuell an der Updatequelle: {version} (schon bekannt)."
        firmware = self.fetch(base + manifest["file"], MAX_FIRMWARE_BYTES)
        if hashlib.sha256(firmware).hexdigest() != manifest["sha256"]:
            raise OtaError(f"SHA-256 von {manifest['file']} passt nicht zum signierten Manifest. Nicht übernommen.")
        folder.mkdir(parents=True, exist_ok=True)
        _write_atomic(folder / manifest["file"], firmware)
        _write_atomic(folder / "update.json", raw)
        with self.db.connect() as conn:
            conn.execute(
                "INSERT INTO ota_releases(version, file, sha256, manifest, found_at, status) VALUES(?, ?, ?, ?, ?, 'pending') "
                "ON CONFLICT(version) DO UPDATE SET manifest = excluded.manifest",
                (version, manifest["file"], manifest["sha256"], json.dumps(manifest), now_text()),
            )
        log.info("OTA-Spiegel: %s geprüft, wartet auf Freigabe", version)
        return f"Neue Firmware {version} geprüft (Signatur und SHA-256 ok), wartet auf Freigabe."

    def import_local(self, manifest_path: Path, firmware_path: Path) -> None:
        """A checked SMB snapshot enters the same approval path as online firmware."""
        raw = manifest_path.read_bytes()
        manifest = parse_manifest(raw, self.trusted)
        if firmware_path.stat().st_size > MAX_FIRMWARE_BYTES or _sha256_file(firmware_path) != manifest['sha256']:
            raise OtaError('Firmware-Datei passt nicht zum signierten Manifest.')
        with self._lock:
            with self.db.connect() as conn:
                known = conn.execute('SELECT sha256 FROM ota_releases WHERE version=?',(manifest['version'],)).fetchone()
            if known and known['sha256'] != manifest['sha256']:
                raise OtaError('Für diese Version ist bereits eine andere Firmware bekannt. Eine neue Versionsnummer ist erforderlich.')
            folder = self.cache_dir / manifest['version']
            folder.mkdir(parents=True, exist_ok=True)
            partial = folder / (manifest['file'] + '.part')
            shutil.copyfile(firmware_path, partial)
            if _sha256_file(partial) != manifest['sha256']:
                partial.unlink(missing_ok=True)
                raise OtaError('Firmware-Kopie ist beschädigt.')
            os.replace(partial, folder / manifest['file'])
            _write_atomic(folder / 'update.json', raw)
            with self.db.transaction() as conn:
                conn.execute("INSERT OR IGNORE INTO ota_releases(version,file,sha256,manifest,found_at,status) VALUES(?,?,?,?,?,'pending')",
                    (manifest['version'],manifest['file'],manifest['sha256'],json.dumps(manifest),now_text()))

    def _remember(self, ok: bool, summary: str) -> None:
        self.db.set_settings({"ota_last_check_at": now_text(), "ota_last_check_ok": "1" if ok else "0",
                              "ota_last_check_summary": summary[:500]})

    def due(self) -> bool:
        values = self.db.get_settings()
        if values.get("ota_enabled") != "1" or values.get("update_mode")=="offline":
            return False
        last = values.get("ota_last_check_at", "")
        hours = max(1, int(values.get("ota_check_hours") or 6))
        try:
            return datetime.now() - datetime.strptime(last, "%Y-%m-%d %H:%M:%S") >= timedelta(hours=hours)
        except ValueError:
            return True

    # --- Freigeben ----------------------------------------------------------

    def _release(self, version: str) -> dict:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM ota_releases WHERE version = ?", (version,)).fetchone()
        if row is None:
            raise OtaError("Version nicht gefunden.")
        return dict(row)

    def approve(self, version: str, username: str) -> None:
        with self._lock:
            if self.deployment_busy():raise OtaError('Eine Gateway-Verteilung läuft. Erst deren Abschluss abwarten.')
            row = self._release(version)
            problem = self.folder_problem()
            if problem:
                raise OtaError(problem)
            current = self.published()
            if current.version and version_key(version) < version_key(current.version):
                raise OtaError(f"{version} ist älter als die bereitgestellte {current.version}. "
                               "Die Gateways installieren keine ältere Version.")
            folder = self.cache_dir / version
            source_bin = folder / row["file"]
            raw_manifest = (folder / "update.json").read_bytes() if (folder / "update.json").is_file() else b""
            if not source_bin.is_file() or not raw_manifest:
                raise OtaError("Die geladenen Dateien fehlen. Bitte erneut prüfen lassen.")
            # Vor dem Bereitstellen noch einmal alles prüfen, nicht nur der Datenbank glauben.
            manifest = parse_manifest(raw_manifest, self.trusted)
            if manifest["version"] != version or _sha256_file(source_bin) != manifest["sha256"]:
                raise OtaError("Die geladene Firmware passt nicht mehr zum Manifest. Bitte erneut prüfen lassen.")
            for name in (row["file"], LEGACY_BIN):
                target = self.ota_dir / name
                partial = target.with_name(name + ".part")
                shutil.copyfile(source_bin, partial)
                if _sha256_file(partial) != manifest["sha256"]:
                    partial.unlink(missing_ok=True)
                    raise OtaError(f"Kopie von {name} im OTA-Ordner ist beschädigt. Nichts bereitgestellt.")
                os.replace(partial, target)
            _write_atomic(self.ota_dir / "update.json", raw_manifest)
            with self.db.connect() as conn:
                conn.execute("UPDATE ota_releases SET status = 'published', decided_by = ?, decided_at = ? WHERE version = ?",
                             (username, now_text(), version))
        log.info("OTA-Spiegel: %s von %s freigegeben", version, username)

    # --- Bereinigen ----------------------------------------------------------

    def cleanup_candidates(self) -> list[dict]:
        """Was "Bereinigen" löschen würde: ältere Versionen als die bereitgestellte und abgelehnte."""
        current = self.published().version
        result = []
        for row in self.releases():
            if row["version"] == current or row["status"] == "pending":
                continue
            if row["status"] == "rejected" or (current and version_key(row["version"]) < version_key(current)):
                result.append(row)
        return result

    def cleanup(self) -> tuple[int, int]:
        """Löscht alte Versionen aus Zwischenspeicher, OTA-Ordner und Liste. Liefert (Anzahl, Bytes)."""
        with self._lock:
            published = self.published()
            keep = {published.file, LEGACY_BIN, "update.json"}
            count = freed = 0
            for row in self.cleanup_candidates():
                folder = self.cache_dir / row["version"]
                if folder.is_dir():
                    freed += sum(f.stat().st_size for f in folder.rglob("*") if f.is_file())
                    shutil.rmtree(folder, ignore_errors=True)
                name = Path(row["file"]).name
                target = self.ota_dir / name
                if name not in keep and target.is_file():
                    freed += target.stat().st_size
                    target.unlink()
                with self.db.connect() as conn:
                    conn.execute("DELETE FROM ota_releases WHERE version = ?", (row["version"],))
                count += 1
        if count:
            log.info("OTA-Spiegel: %s alte Version(en) gelöscht, %s Bytes frei", count, freed)
        return count, freed

    def reject(self, version: str, username: str) -> None:
        self._release(version)
        with self.db.connect() as conn:
            conn.execute("UPDATE ota_releases SET status = 'rejected', decided_by = ?, decided_at = ? "
                         "WHERE version = ? AND status = 'pending'", (username, now_text(), version))
