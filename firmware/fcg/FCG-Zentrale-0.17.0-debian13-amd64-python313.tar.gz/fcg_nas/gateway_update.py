"""Firmware-Update der Gateways, vom Collector ausgelöst.

Das Gateway installiert über /api/ota/install?confirm=1 die Firmware, die sein
eigenes Manifest (normalerweise der OTA-Spiegel auf der NAS) anbietet, und
startet danach neu. Bei diesem manuellen Aufruf prüft die Firmware ihren
Ruhe-Wächter (10 Minuten ohne Impuls, CAN ruhig) nicht. Das übernimmt hier der
Collector: er liest vorher /api/ota/status und installiert nur, wenn
idle_guard.ready gesetzt ist. Nach dem Neustart wird über /api/health
(ohne Login) geprüft, welche Version läuft.

Der Gateway-Admin-Login wird bei jedem Auslösen eingegeben und nur im
Speicher für diesen einen Durchgang gehalten, nie gespeichert oder protokolliert.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, replace
from typing import Any, Callable
from urllib.parse import quote

from .db import Database, now_text
from .gateway_client import GatewayAuth, GatewayError, GatewayUnreachable, JsonFn, PostFn
from .live import format_age
from .ota import version_key

MAX_PARALLEL = 10

log = logging.getLogger("fcg_nas.gateway_update")

ADMIN_TIMEOUT_S = 15.0
INSTALL_TIMEOUT_S = 240.0     # Download und Flashen laufen, bevor das Gateway antwortet
RESTART_WAIT_S = 240.0
RESTART_POLL_S = 5.0
HEALTH_TIMEOUT_S = 5.0

STATE_TEXT = {"wait": "wartet", "run": "läuft", "ok": "aktualisiert", "skip": "übersprungen", "fail": "Fehler"}


@dataclass
class OtaState:
    version: str
    auto_install: bool | None
    auto_check: bool | None
    busy: bool
    idle_ready: bool
    idle_text: str
    manifest_url: str


@dataclass
class Step:
    gateway_id: int
    host: str
    title: str
    state: str = "wait"           # wait | run | ok | skip | fail
    text: str = ""
    before: str = ""
    after: str = ""
    at: str = field(default_factory=now_text)

    @property
    def state_text(self) -> str:
        return STATE_TEXT.get(self.state, self.state)


def _dict(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _bool(value: Any) -> bool | None:
    return value if isinstance(value, bool) else None


def idle_text(guard: dict) -> str:
    """Warum das Gateway gerade nicht installieren darf, in Worten."""
    if guard.get("ready") is True:
        return "bereit (kein Impuls seit 10 Minuten, CAN ruhig)"
    reasons = []
    if guard.get("pulse_idle_ok") is False or guard.get("pulse_boot_guard_ok") is False:
        age = guard.get("pulse_age_ms")
        if isinstance(age, (int, float)) and not isinstance(age, bool):
            reasons.append(f"letzter Impuls vor {format_age(age / 1000)}")
        else:
            reasons.append("Gateway erst kurz gestartet")
    if guard.get("can_idle_ok") is False or guard.get("can_boot_guard_ok") is False:
        reasons.append("CAN-Bus aktiv")
    if not reasons:
        reasons.append(str(guard.get("message") or "Ruhe-Wächter meldet nicht bereit"))
    return ", ".join(reasons)


def parse_ota_status(data: Any) -> OtaState:
    if not isinstance(data, dict):
        raise GatewayError("Antwort von /api/ota/status ist kein JSON-Objekt.")
    remote = _dict(data.get("remote_update"))
    scheduler = _dict(remote.get("auto_scheduler"))
    config = _dict(remote.get("config"))
    guard = _dict(scheduler.get("idle_guard"))
    if not guard:
        raise GatewayError("Die Firmware meldet keinen Ruhe-Wächter (idle_guard); Update aus dem Collector nicht möglich.")
    auto_install = _bool(config.get("auto_install_enabled"))
    if auto_install is None:
        auto_install = _bool(scheduler.get("auto_install_enabled"))
    return OtaState(
        version=str(data.get("version") or ""),
        auto_install=auto_install,
        auto_check=_bool(config.get("auto_check_enabled")),
        busy=scheduler.get("busy") is True,
        idle_ready=guard.get("ready") is True,
        idle_text=idle_text(guard),
        manifest_url=str(config.get("manifest_url") or ""),
    )


def _login_error(exc: GatewayError) -> str:
    text = str(exc)
    if text.startswith("HTTP 401"):
        return "Gateway-Admin-Login abgelehnt. Benutzer und Passwort des Gateway-Admins prüfen."
    return text


class GatewayUpdater:
    def __init__(self, db: Database, get_json: JsonFn, post_json: PostFn,
                 sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.monotonic) -> None:
        self.publication_lock = threading.RLock()
        self.published_version = None
        self.db = db
        self.get_json = get_json
        self.post_json = post_json
        self.sleep = sleep
        self.clock = clock
        self._lock = threading.Lock()
        self._steps: list[Step] = []
        self._running = False
        self._thread: threading.Thread | None = None

    # --- Anzeige ----------------------------------------------------------

    @property
    def running(self) -> bool:
        with self._lock:
            return self._running

    def steps(self) -> list[Step]:
        with self._lock:
            return [replace(s) for s in self._steps]

    def _set(self, step: Step, **changes: Any) -> None:
        with self._lock:
            for key, value in changes.items():
                setattr(step, key, value)
            step.at = now_text()

    # --- Zustand lesen ------------------------------------------------------

    def read_state(self, gateway, auth: GatewayAuth) -> OtaState:
        state = parse_ota_status(self.get_json(gateway["host"], "/api/ota/status", auth, ADMIN_TIMEOUT_S))
        self._remember(gateway["id"], state.auto_install, state.version)
        return state

    def _remember(self, gateway_id: int, auto_install: bool | None, version: str = "") -> None:
        with self.db.connect() as conn:
            conn.execute("UPDATE gateways SET ota_auto_install = ?, ota_state_at = ? WHERE id = ?",
                         (None if auto_install is None else int(auto_install), now_text(), gateway_id))
            if version:
                conn.execute("UPDATE gateways SET fw_version = ? WHERE id = ?", (version, gateway_id))

    def read_states(self, gateways: list, auth: GatewayAuth) -> list[tuple[Any, OtaState | None, str]]:
        """(Gateway, Zustand oder None, Fehlertext) für die Anzeige nach 'Zustand abfragen'."""
        result = []
        for gw in gateways:
            try:
                result.append((gw, self.read_state(gw, auth), ""))
            except GatewayError as exc:
                result.append((gw, None, _login_error(exc)))
        return result

    # --- Auto-Install schalten ------------------------------------------------

    def set_auto_install(self, gateway, auth: GatewayAuth, enabled: bool) -> str:
        """Schaltet nur den Auto-Install-Schalter um. URL, Login und Prüfzeit bleiben, wie sie sind."""
        host = gateway["host"]
        try:
            config = self.get_json(host, "/api/ota/config", auth, ADMIN_TIMEOUT_S)
        except GatewayError as exc:
            raise GatewayError(_login_error(exc)) from exc
        if not isinstance(config, dict) or "manifest_url" not in config:
            raise GatewayError("Antwort von /api/ota/config ist unvollständig.")
        hour, minute = config.get("check_hour"), config.get("check_minute")
        if not isinstance(hour, int) or not isinstance(minute, int):
            raise GatewayError("Antwort von /api/ota/config enthält keine Prüfzeit.")
        # Passwort und Token der Updatequelle bleiben leer: die Firmware behält dann die gespeicherten.
        query = "&".join([
            "url=" + quote(str(config.get("manifest_url") or ""), safe=":/._-~"),
            "user=" + quote(str(config.get("username") or ""), safe=""),
            "autocheck=" + ("1" if config.get("auto_check_enabled") is not False else "0"),
            "autoinstall=" + ("1" if enabled else "0"),
            f"hour={hour}",
            f"minute={minute}",
        ])
        try:
            answer = self.post_json(host, "/api/ota/config/save?" + query, auth, ADMIN_TIMEOUT_S)
        except GatewayError as exc:
            raise GatewayError(_login_error(exc)) from exc
        if not isinstance(answer, dict) or answer.get("ok") is not True:
            raise GatewayError(str(_dict(answer).get("message") or "Gateway hat die Einstellung nicht gespeichert."))
        self._remember(gateway["id"], enabled)
        return str(answer.get("message") or "gespeichert")

    def set_manifest_source(self, gateway, auth, url):
        config = self.get_json(gateway['host'], '/api/ota/config', auth, ADMIN_TIMEOUT_S)
        if not isinstance(config,dict) or not isinstance(config.get('check_hour'),int) or not isinstance(config.get('check_minute'),int):
            raise GatewayError('Gateway meldet keine vollständige Updatekonfiguration.')
        if config.get('manifest_url') == url:return
        if config.get('username') or config.get('password_set') or config.get('token_set'):
            raise GatewayError('Die bisherige Gateway-Updatequelle hat eigene Zugangsdaten. Diese zuerst auf der Gateway-Systemseite zurücksetzen; danach erneut verteilen.')
        query='&'.join(['url='+quote(url,safe=':/._-~'),'user=',
            'autocheck='+('0' if config.get('auto_check_enabled') is False else '1'),
            'autoinstall='+('1' if config.get('auto_install_enabled') is True else '0'),
            'hour='+str(config['check_hour']),'minute='+str(config['check_minute'])])
        result=self.post_json(gateway['host'],'/api/ota/config/save?'+query,auth,ADMIN_TIMEOUT_S)
        if not isinstance(result,dict) or result.get('ok') is not True:
            raise GatewayError('Gateway hat die lokale Updatequelle nicht übernommen.')

    # --- Update -------------------------------------------------------------

    def start(self, gateways: list, auth: GatewayAuth, username: str, target: str, force: bool = False, manifest_url: str = "") -> bool:
        """Startet die Updates nacheinander im Hintergrund. False, wenn schon ein Durchgang läuft."""
        with self.publication_lock:
            if self.published_version and self.published_version()!=target:
                return False
            with self._lock:
                if self._running:return False
                self._running=True
                self._steps=[Step(gw['id'],gw['host'],gw['label'] or gw['counter_name'] or gw['host'],before=gw['fw_version'] or '') for gw in gateways]
            self._thread=threading.Thread(target=self._run,args=(list(gateways),auth,username,target,force,manifest_url),name='fcg-gateway-update',daemon=True)
            self._thread.start()
            return True

    def join(self, timeout: float | None = None) -> None:
        if self._thread is not None:
            self._thread.join(timeout)

    def _run(self, gateways: list, auth: GatewayAuth, username: str, target: str, force: bool = False, manifest_url: str = "") -> None:
        # In Gruppen: höchstens ota_parallel Gateways gleichzeitig, die nächste Gruppe erst,
        # wenn die vorige fertig ist (Einstellung unter Firmware > Einstellungen).
        group_size = max(1, min(MAX_PARALLEL, self.db.get_int_setting("ota_parallel") or 1))
        pairs = list(zip(gateways, self.steps_ref()))

        def one(pair) -> None:
            gw, step = pair
            try:
                if manifest_url:self.set_manifest_source(gw,auth,manifest_url)
                self.update_one(gw, step, auth, target, force)
            except Exception as exc:  # ein Gateway darf die anderen nicht aufhalten
                log.exception("Update von %s fehlgeschlagen", gw["host"])
                self._set(step, state="fail", text=f"Unerwarteter Fehler: {exc}")
            self.db.audit(username, "gateway_update",
                          f"{step.host}: {step.state_text}"
                          + (f" {step.before} -> {step.after}" if step.after and step.after != step.before else "")
                          + (f" ({step.text})" if step.state != "ok" else ""))

        try:
            for start in range(0, len(pairs), group_size):
                group = pairs[start:start + group_size]
                if len(group) == 1:
                    one(group[0])
                    continue
                with ThreadPoolExecutor(max_workers=len(group), thread_name_prefix="fcg-gateway-update") as pool:
                    list(pool.map(one, group))
        finally:
            with self._lock:
                self._running = False

    def steps_ref(self) -> list[Step]:
        with self._lock:
            return list(self._steps)

    def _health(self, host: str) -> dict | None:
        try:
            data = self.get_json(host, "/api/health", GatewayAuth(), HEALTH_TIMEOUT_S)
        except GatewayError:
            return None
        return data if isinstance(data, dict) else None

    def _no_update_needed(self, gw, step: Step, state: OtaState, target: str, message: str) -> bool:
        """Explain a verified no-update response without masking install/signature errors."""
        detail = message
        prefix = "HTTP 400 bei /api/ota/install?confirm=1: "
        if detail.startswith(prefix):
            detail = detail[len(prefix):]
        if not detail.startswith("Remote-OTA nicht nötig:"):
            return False
        # Another updater may have finished between status check and install request.
        health = self._health(gw["host"]) or {}
        actual = str(health.get("version") or state.version)
        if target and (not actual or version_key(actual) < version_key(target)):
            self._set(step, state="fail", after=actual,
                      text=f"Zielversion {target} wurde nicht installiert; Gateway läuft mit {actual or 'unbekannter Version'}. "
                           "Die Updatequelle des Gateways bietet derzeit keine neuere installierbare Version an. "
                           "In der Zentrale unter Firmware zuerst „Jetzt prüfen“, dann die Zielversion freigeben. "
                           "Falls sie bereits freigegeben ist, Manifest-URL und OTA-Webordner prüfen. "
                           f"Gatewaymeldung: {detail}")
        else:
            if actual:
                self._remember(gw["id"], state.auto_install, actual)
            self._set(step, state="skip", after=actual,
                      text=(f"Zielversion {target} bereits erreicht; kein erneutes Update nötig. " if target else
                            "Die Updatequelle bietet keine neuere Version an; keine Installation ausgeführt. ") + detail)
        return True

    def update_one(self, gw, step: Step, auth: GatewayAuth, target: str, force: bool = False) -> None:
        """Ein Gateway aktualisieren. force: auch installieren, wenn es nicht in Ruhe ist."""
        host = gw["host"]
        self._set(step, state="run", text="prüft Zustand")
        try:
            state = self.read_state(gw, auth)
        except GatewayError as exc:
            self._set(step, state="fail", text=_login_error(exc))
            return
        self._set(step, before=state.version)
        if target and state.version and version_key(state.version) >= version_key(target):
            self._set(step, state="skip", text=f"läuft schon mit {state.version}", after=state.version)
            return
        if state.busy:
            self._set(step, state="skip", text="Gateway prüft gerade selbst auf ein Update")
            return
        if not state.idle_ready and not force:
            self._set(step, state="skip", text=f"nicht in Ruhe: {state.idle_text}. Später erneut versuchen "
                                               "oder „auch wenn nicht in Ruhe“ anhaken.")
            return
        health = self._health(host) or {}
        uptime_before = health.get("uptime_ms") if isinstance(health.get("uptime_ms"), int) else None

        self._set(step, text="lädt und installiert die Firmware"
                  + ("" if state.idle_ready else f" (erzwungen, nicht in Ruhe: {state.idle_text})"))
        try:
            answer = self.post_json(host, "/api/ota/install?confirm=1", auth, INSTALL_TIMEOUT_S)
        except GatewayUnreachable:
            # Die Verbindung kann beim Neustart abreißen; ob es geklappt hat, zeigt die Version danach.
            answer = None
        except GatewayError as exc:
            if not self._no_update_needed(gw, step, state, target, str(exc)):
                self._set(step, state="fail", text=_login_error(exc))
            return
        if answer is not None and _dict(answer).get("ok") is not True:
            message = str(_dict(answer).get("message") or "Gateway hat nicht installiert.")
            if not self._no_update_needed(gw, step, state, target, message):
                self._set(step, state="fail", text=message)
            return

        self._set(step, text="wartet auf den Neustart")
        deadline = self.clock() + RESTART_WAIT_S
        while self.clock() < deadline:
            self.sleep(RESTART_POLL_S)
            health = self._health(host)
            if not health:
                continue
            version = str(health.get("version") or "")
            uptime = health.get("uptime_ms")
            if version and version != state.version:
                with self.db.connect() as conn:
                    conn.execute("UPDATE gateways SET fw_version = ? WHERE id = ?", (version, gw["id"]))
                if target and version != target:
                    self._set(step, state="fail", after=version,
                              text=f"läuft jetzt mit {version}, erwartet war {target}. Manifest-URL am Gateway prüfen.")
                else:
                    self._set(step, state="ok", after=version, text=f"läuft mit {version}")
                return
            if isinstance(uptime, int) and uptime_before is not None and uptime < uptime_before:
                self._set(step, state="fail", after=version,
                          text=f"neu gestartet, läuft aber weiter mit {version}. Gateway-Log prüfen.")
                return
        self._set(step, state="fail",
                  text=f"nach {int(RESTART_WAIT_S // 60)} Minuten keine neue Version gemeldet. Gateway prüfen.")
