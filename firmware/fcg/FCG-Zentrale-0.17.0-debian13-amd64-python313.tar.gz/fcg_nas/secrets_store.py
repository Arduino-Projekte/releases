"""Verschlüsselung der Gateway-Zugangsdaten in der Datenbank.

Der Schlüssel liegt als eigene Datei im Datenordner. Ein Export der
Datenbank allein enthält die Passwörter damit nur verschlüsselt.
"""
from __future__ import annotations

import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken


class SecretStore:
    def __init__(self, key_path: Path) -> None:
        self.key_path = Path(key_path)
        self._fernet = Fernet(self._load_or_create_key())

    def _load_or_create_key(self) -> bytes:
        if self.key_path.exists():
            return self.key_path.read_bytes().strip()
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        key = Fernet.generate_key()
        # Exklusiv anlegen, damit zwei gleichzeitige Starts nicht zwei Schlüssel erzeugen.
        fd = os.open(self.key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(key)
        return key

    def reload(self) -> None:
        """Schlüssel neu lesen, z. B. nach einer Rücksicherung."""
        self._fernet = Fernet(self._load_or_create_key())

    def encrypt(self, plain: str) -> str:
        if not plain:
            return ""
        return self._fernet.encrypt(plain.encode("utf-8")).decode("ascii")

    def decrypt(self, token: str) -> str:
        if not token:
            return ""
        try:
            return self._fernet.decrypt(token.encode("ascii")).decode("utf-8")
        except InvalidToken as exc:
            raise ValueError(
                "Gateway-Passwort kann nicht entschlüsselt werden (secret.key passt nicht zur Datenbank)."
            ) from exc
