"""Root-only systemd worker: verified staging, consistent backup and rollback."""
import argparse
import fcntl
import hashlib
import json
import logging
import os
from pathlib import Path
import platform
import pwd
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request
from urllib.parse import urlsplit
import zipfile

from . import __version__
from .central_updates import version_key
from .db import now_text
from .ota import download
from .update_source import effective_source, public_text
from .vm_package import MAX_PACKAGE, unpack, verify_manifest

ROOT = Path('/opt/fcg')
STATE = Path('/var/lib/fcg-update')
DATA = Path('/var/lib/fcg/data')
log = logging.getLogger('fcg-vm-update')


def command(args, **kw):
    return subprocess.run([str(a) for a in args], check=True, timeout=300, **kw)


def prepare(package, manifest, releases):
    if sys.version_info[:2] != (3, 13) or platform.machine() != 'x86_64':
        raise ValueError('Dieses Paket benötigt Debian 13, Python 3.13 und AMD64.')
    releases.mkdir(parents=True, exist_ok=True)
    destination = releases / (manifest['version'] + '-' + manifest['sha256'][:12])
    with tempfile.TemporaryDirectory(prefix='.stage-', dir=releases) as temporary:
        staging = Path(temporary)
        # The root worker has UMask=0077 for backups. Application code and its
        # venv must nevertheless be traversable by the unprivileged service.
        previous_umask = os.umask(0o022)
        try:
            unpack(package, staging, manifest)
            command(['/usr/bin/python3', '-m', 'venv', staging / 'venv'])
            command([staging / 'venv/bin/python', '-m', 'pip', 'install', '--no-index', '--no-compile',
                     '--find-links', staging / 'wheels', '-r', staging / 'requirements.txt'],
                    stdout=subprocess.DEVNULL)
        finally:
            os.umask(previous_umask)
        # Use python -m uvicorn at runtime: venv console-script shebangs contain
        # their staging path and are not relocatable after the atomic rename.
        if destination.exists():
            raise ValueError('Dieses Paket wurde bereits vorbereitet.')
        staging.chmod(0o755)
        os.replace(staging, destination)
    return destination


def switch(target):
    temporary = ROOT / '.next'
    temporary.unlink(missing_ok=True)
    temporary.symlink_to(target)
    os.replace(temporary, ROOT / 'current')


def health(version, attempts=40):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(attempts):
        try:
            value = json.loads(opener.open('http://127.0.0.1:8080/healthz', timeout=2).read())
            if value.get('ok') is True and value.get('version') == version:
                return
        except (OSError, ValueError):
            pass
        time.sleep(1)
    raise RuntimeError('Startprüfung fehlgeschlagen.')


def write_status(state, version=''):
    temporary = STATE / '.status.tmp'
    temporary.write_text(json.dumps({'state': state, 'version': version, 'at': now_text()}))
    temporary.chmod(0o644)
    os.replace(temporary, STATE / 'status.json')


def safety_backup(old, folder):
    script = '''from pathlib import Path
import sys
from fcg_nas.backup import BackupService
from fcg_nas.db import Database
p=Path(sys.argv[1])
b=BackupService(Database(p/'fcg_collector.sqlite3'),p,Path(sys.argv[2]))
print(b.create('vor_update').path)
'''
    result = command(['runuser', '-u', 'fcg', '--', old / 'venv/bin/python', '-c', script, DATA, DATA / 'backups'], cwd=old,
                     capture_output=True, text=True)
    source = Path(result.stdout.strip().splitlines()[-1])
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = folder / source.name
    fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as incoming:
        info = os.fstat(incoming.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != pwd.getpwnam('fcg').pw_uid or info.st_size > 1024**3:
            raise ValueError('Ungültige Sicherheitssicherung.')
        with target.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing)
    target.chmod(0o600)
    with zipfile.ZipFile(target) as archive:
        if archive.getinfo('fcg_collector.sqlite3').file_size > 1024**3 or archive.getinfo('secret.key').file_size > 200:
            raise ValueError('Sicherheitssicherung überschreitet die Rücksicherungsgrenze.')
    return target


def restore(backup):
    account = pwd.getpwnam('fcg')
    with zipfile.ZipFile(backup) as archive:
        for name in ('fcg_collector.sqlite3', 'secret.key'):
            if name not in archive.namelist():
                raise ValueError('Sicherheitssicherung ist unvollständig.')
            limit = 200 if name == 'secret.key' else 1024**3
            if archive.getinfo(name).file_size > limit:
                raise ValueError('Sicherheitssicherung ist zu groß.')
            # Create in the root-only directory, then replace the destination;
            # never follow a symlink in app-owned data while privileged.
            temporary = STATE / 'private' / (name + '.restore')
            temporary.write_bytes(archive.read(name))
            temporary.chmod(0o600)
            os.chown(temporary, account.pw_uid, account.pw_gid)
            os.replace(temporary, DATA / name)
    for suffix in ('-wal', '-shm'):
        Path(str(DATA / 'fcg_collector.sqlite3') + suffix).unlink(missing_ok=True)


def install(request, offline=None):
    version = request.get('version', '')
    if version_key(version) <= version_key(__version__):
        raise ValueError('Keine neuere Version angefordert.')
    if offline:
        manifest = verify_manifest(offline[1].read_bytes())
    else:
        source = request.get('source', '')
        if not isinstance(source, str) or len(source) > 1024:
            raise ValueError('Ungültige Updatequelle.')
        base = effective_source(source).rstrip('/') + '/'
        url = urlsplit(base)
        if url.scheme != 'https' or not url.hostname or url.username or url.password or url.query or url.fragment:
            raise ValueError('Updatequelle benötigt eine HTTPS-Verzeichnisadresse.')
        manifest = verify_manifest(download(base + 'vm-update.json', 32768))
    if manifest['version'] != version:
        raise ValueError('Angebotene Version hat sich geändert. Erneut prüfen.')
    write_status('preparing', version)
    with tempfile.TemporaryDirectory(dir=STATE / 'private') as temporary:
        work = Path(temporary)
        package = work / manifest['file']
        if offline:
            if offline[0].stat().st_size > MAX_PACKAGE:
                raise ValueError('Update-Paket ist zu groß.')
            shutil.copyfile(offline[0], package)
        else:
            package.write_bytes(download(base + manifest['file'], MAX_PACKAGE))
        candidate = prepare(package, manifest, ROOT / 'releases')
        old = (ROOT / 'current').resolve(strict=True)
        if old.parent != ROOT / 'releases':
            raise ValueError('Ungültiger bisheriger Installationspfad.')
        command(['systemctl', 'stop', 'fcg.service'])
        backup = None
        try:
            # Service is stopped before snapshotting; no collector writes can
            # race with this backup or a subsequent schema migration.
            backup = safety_backup(old, STATE / 'private/backups')
            os.sync()
            transaction = STATE / 'private/transaction.json'
            pending = transaction.with_suffix('.tmp')
            pending.write_text(json.dumps({'old': str(old), 'backup': str(backup), 'version': version}))
            pending.chmod(0o600)
            with pending.open('rb') as handle: os.fsync(handle.fileno())
            os.replace(pending, transaction)
            os.sync()
            switch(candidate)
            command(['systemctl', 'reset-failed', 'fcg.service'])
            command(['systemctl', 'start', 'fcg.service'])
            health(version)
        except Exception:
            command(['systemctl', 'stop', 'fcg.service'])
            switch(old)
            if backup:
                restore(backup)
            command(['systemctl', 'reset-failed', 'fcg.service'])
            command(['systemctl', 'start', 'fcg.service'])
            health(__version__)
            (STATE / 'private/transaction.json').unlink(missing_ok=True)
            os.sync()
            write_status('rolled_back', version)
            return
        (STATE / 'private/transaction.json').unlink(missing_ok=True)
        os.sync()
        write_status('installed', version)


def install_queued_offline(request):
    """Never trust an app-writable path or install directly from a mutable share."""
    package_id = request.get('offline')
    if not isinstance(package_id,str) or not re.fullmatch('[a-f0-9]{64}',package_id):
        raise ValueError('Ungültige Offline-Paketkennung.')
    flags = os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW
    parent = os.open(STATE/'inbox/packages',flags)
    try:
        folder = os.open(package_id,flags,dir_fd=parent)
    finally:os.close(parent)
    try:
        with tempfile.TemporaryDirectory(prefix='offline-',dir=STATE/'private') as temporary:
            work=Path(temporary)
            def copy(name,limit):
                fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=folder)
                with os.fdopen(fd,'rb') as src, (work/name).open('wb') as dst:
                    info=os.fstat(src.fileno())
                    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size>limit:
                        raise ValueError('Ungültige Offline-Paketdatei.')
                    total=0
                    while chunk:=src.read(min(1024*1024,limit+1-total)):
                        total+=len(chunk)
                        if total>limit:raise ValueError('Offline-Paketdatei ist zu groß.')
                        dst.write(chunk)
            copy('manifest.json',32768)
            manifest=verify_manifest((work/'manifest.json').read_bytes())
            if hashlib.sha256((work/'manifest.json').read_bytes()).hexdigest()!=package_id:
                raise ValueError('Offline-Manifest wurde verändert.')
            copy(manifest['file'],MAX_PACKAGE)
            install(request,(work/manifest['file'],work/'manifest.json'))
    finally:os.close(folder)


def consume():
    if os.geteuid() != 0:
        raise PermissionError('Update worker requires root.')
    with (STATE / 'private/worker.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        request_path = STATE / 'inbox/request.json'
        processing = STATE / 'private/request.json'
        try:
            os.replace(request_path, processing)
        except FileNotFoundError:
            return
        try:
            fd = os.open(processing, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, 'rb') as handle:
                info = os.fstat(handle.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_size > 4096 or info.st_nlink != 1:
                    raise ValueError('Ungültige Updateanforderung.')
                request = json.loads(handle.read(4097))
            if not isinstance(request, dict):
                raise ValueError('Ungültige Updateanforderung.')
            if request.get('runtime_sync') is True:
                from .vm_runtime import synchronize
                try:synchronize()
                except Exception:
                    from .vm_runtime import record_failure
                    try:record_failure()
                    except OSError:pass
                    log.error('VM access component synchronization failed.')
                return
            if "offline" in request:
                install_queued_offline(request)
            else:
                install(request)
        except Exception as exc:
            log.error('VM update failed: %s', public_text(str(exc)))
            write_status('failed')
        finally:
            processing.unlink(missing_ok=True)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument('--initial-package', type=Path)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--offline-package', type=Path)
    args = parser.parse_args()
    if args.initial_package:
        if os.geteuid() != 0:
            raise PermissionError('Installation requires root.')
        manifest = verify_manifest(args.manifest.read_bytes())
        switch(prepare(args.initial_package, manifest, ROOT / 'releases'))
    elif args.offline_package:
        if os.geteuid() != 0:
            raise PermissionError('Installation requires root.')
        manifest = verify_manifest(args.manifest.read_bytes())
        with (STATE / 'private/worker.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            install({'version': manifest['version']}, (args.offline_package.resolve(), args.manifest.resolve()))
    else:
        consume()
