"""Read the published image version without Docker socket access or credentials."""
import hashlib
import json
import platform
import re
import urllib.request

REPOSITORY = 'juliawf/fcg-nas-collector'
REGISTRY = 'https://ghcr.io'
ACCEPT = ', '.join(('application/vnd.oci.image.index.v1+json',
                    'application/vnd.docker.distribution.manifest.list.v2+json',
                    'application/vnd.oci.image.manifest.v1+json',
                    'application/vnd.docker.distribution.manifest.v2+json'))


def read_json(url, token='', digest=None):
    headers = {'Accept': ACCEPT, 'Cache-Control': 'no-cache', 'User-Agent': 'fcg-central-update-check'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=15) as response:
        raw = response.read(512 * 1024 + 1)
    if len(raw) > 512 * 1024:
        raise ValueError('Image-Metadaten sind zu groß.')
    if digest and 'sha256:' + hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('Image-Metadaten passen nicht zur Prüfsumme.')
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError('Ungültige Image-Metadaten.')
    return value


def checked_digest(descriptor):
    digest = descriptor.get('digest', '') if isinstance(descriptor, dict) else ''
    if not isinstance(digest, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', digest):
        raise ValueError('Ungültige Image-Prüfsumme.')
    return digest


def latest_image(fetch=None, machine=None):
    fetch = fetch or read_json
    auth = fetch(REGISTRY + '/token?service=ghcr.io&scope=repository:' + REPOSITORY + ':pull')
    token = auth.get('token') or auth.get('access_token')
    if not isinstance(token, str) or not token or len(token) > 16384:
        raise ValueError('Image-Prüfung konnte nicht autorisiert werden.')
    base = REGISTRY + '/v2/' + REPOSITORY
    manifest = fetch(base + '/manifests/latest', token)
    if 'manifests' in manifest:
        arch = {'x86_64': 'amd64', 'AMD64': 'amd64', 'aarch64': 'arm64', 'arm64': 'arm64'}.get(machine or platform.machine())
        descriptors = manifest['manifests']
        if not isinstance(descriptors, list):
            raise ValueError('Ungültige Image-Plattformliste.')
        selected = next((d for d in descriptors if isinstance(d, dict)
                         and isinstance(d.get('platform'), dict)
                         and d['platform'].get('os') == 'linux'
                         and d['platform'].get('architecture') == arch), None)
        digest = checked_digest(selected)
        manifest = fetch(base + '/manifests/' + digest, token, digest)
    config_digest = checked_digest(manifest.get('config'))
    config = fetch(base + '/blobs/' + config_digest, token, config_digest)
    version = config.get('config', {}).get('Labels', {}).get('org.opencontainers.image.version', '')
    if not isinstance(version, str) or not re.fullmatch(r'\d{1,6}\.\d{1,6}\.\d{1,6}', version):
        raise ValueError('Das veröffentlichte Image enthält keine gültige FCG-Version.')
    return version
