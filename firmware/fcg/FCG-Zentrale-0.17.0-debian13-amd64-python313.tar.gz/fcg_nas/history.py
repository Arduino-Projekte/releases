"""Historische Stände und nachvollziehbare Datumsprobleme ohne Schätzwerte."""
from datetime import date


def valid_day(value):
    try:
        return date.fromisoformat(value) if value else None
    except (ValueError, TypeError):
        return None


def entries_by_site(db, site=""):
    with db.connect() as conn:
        rows = conn.execute("""SELECT e.*, s.counter_name, s.location, s.unit, s.csv_stem
            FROM entries e JOIN sites s ON s.site_id=e.site_id
            WHERE (?='' OR e.site_id=?) ORDER BY e.site_id, e.seq""", (site, site)).fetchall()
    groups = {}
    for row in rows:
        groups.setdefault(row["site_id"], []).append(dict(row))
    return groups


def counter_snapshots(db, selected, site=""):
    with db.connect() as conn:
        sites = conn.execute("SELECT * FROM sites WHERE (?='' OR site_id=?) ORDER BY location, counter_name", (site, site)).fetchall()
    groups = entries_by_site(db, site)
    result = []
    for item in sites:
        candidates = [r for r in groups.get(item["site_id"], [])
                      if valid_day(r["entry_date"]) and valid_day(r["entry_date"]) <= selected]
        latest = max(candidates, key=lambda r: (r["entry_date"], r["ts"], r["seq"]), default=None)
        result.append({"site": dict(item), "entry": latest,
                       "older": bool(latest and latest["entry_date"] < selected.isoformat())})
    return result


def undated_entries(db, site=""):
    result = []
    for rows in entries_by_site(db, site).values():
        for index, row in enumerate(rows):
            if valid_day(row["entry_date"]) is not None:
                continue
            previous = rows[index-1] if index else None
            following = rows[index+1] if index+1 < len(rows) else None
            result.append({"entry": row, "previous": previous, "following": following,
                           "difference": row["total_quantity"]-previous["total_quantity"] if previous else None})
    return result
