"""One bilingual content source for contextual help, internal pages and PDFs."""
import json
from functools import lru_cache
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape
from . import __version__

@lru_cache(maxsize=1)
def source():
    return json.loads(Path(__file__).with_name('help').joinpath('topics.json').read_text(encoding='utf-8'))

def topics(lang='de', role='guest'):
    allowed = {'all'} | ({'reader'} if role in {'admin','reader'} else set()) | ({'admin'} if role=='admin' else set())
    return [{'id': t['id'], **t.get(lang, t['de'])} for t in source() if t['audience'] in allowed]

def summary(topic_id, lang='de'):
    topic = next((t for t in source() if t['id']==topic_id), None)
    return topic.get(lang, topic['de'])['summary'] if topic else ''

def field_summary(name, lang='de'):
    for topic in source():
        text = topic.get(lang, topic['de']).get('fields', {}).get(name)
        if text:
            return text
    return ''


def pdf(lang='de', role='guest', logo=None, installation_only=False):
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, KeepTogether, Image
    regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    if 'FCGHelp' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('FCGHelp', regular))
        pdfmetrics.registerFont(TTFont('FCGHelpBold', bold))
    styles=getSampleStyleSheet()
    for name in ['Normal','Title','Heading1','Heading2']:
        styles[name].fontName='FCGHelpBold' if name!='Normal' else 'FCGHelp'
        styles[name].leading=styles[name].fontSize*1.45
    styles['Normal'].spaceAfter=9
    styles.add(ParagraphStyle('Intro',parent=styles['Normal'],textColor=colors.HexColor('#416180')))
    out=BytesIO()
    title='FCG Zentrale – Benutzerhandbuch' if lang=='de' else 'FCG Zentrale – User guide'
    doc=SimpleDocTemplate(out,title=title,author='FCG Zentrale',leftMargin=20*mm,rightMargin=20*mm,topMargin=20*mm,bottomMargin=20*mm)
    items=topics(lang,role)
    if installation_only:
        items=[item for item in items if item['id'].startswith('installation-')]
        title='FCG Zentrale – Installationsanleitung' if lang=='de' else 'FCG Zentrale – Installation guide'
        doc.title=title
    story=[Paragraph(escape(title),styles['Title']),Spacer(1,8*mm),
           Paragraph(f'Version {__version__} · {lang.upper()}',styles['Normal']),
           Paragraph('Diese PDF gehört zur angegebenen Softwareversion. Nach Updates die interne Hilfe verwenden.' if lang=='de' else 'This PDF describes the software version above. After updates, consult the internal help.',styles['Normal'])]
    if logo:
        # Decode locally, restrict dimensions, preserve proportions; no external URLs.
        from PIL import Image as PillowImage, UnidentifiedImageError
        try:
            if len(logo)>512*1024:
                raise ValueError('Logo too large')
            with PillowImage.open(BytesIO(logo)) as image:
                width,height=image.size
                if width<1 or height<1 or width*height>16000000:
                    raise ValueError('Logo dimensions')
                image.load()
                normalized=BytesIO()
                image.convert('RGBA').save(normalized,format='PNG')
            scale=min(150*mm/width,30*mm/height)
            story.insert(0,Spacer(1,8*mm))
            story.insert(0,Image(BytesIO(normalized.getvalue()),width=width*scale,height=height*scale))
        except (ValueError,OSError,UnidentifiedImageError,PillowImage.DecompressionBombError):
            pass
    story += [Paragraph(escape(t['title']),styles['Normal']) for t in items]
    story.append(PageBreak())
    for topic in items:
        story.append(KeepTogether([Paragraph(escape(topic['title']),styles['Heading1']),Paragraph(escape(topic['summary']),styles['Intro'])]))
        story += [Paragraph(escape(p),styles['Normal']) for p in topic['paragraphs']]
        story += [Paragraph(f'{i}. {escape(p)}',styles['Normal']) for i,p in enumerate(topic['steps'],1)]
        for name, description in topic.get('fields', {}).items():
            story.append(Paragraph(escape(name),styles['Heading2']))
            story.append(Paragraph(escape(description),styles['Normal']))
        story.append(Spacer(1,5*mm))
    def footer(canvas, document):
        canvas.saveState();canvas.setFont('FCGHelp',8)
        canvas.drawString(20*mm,12*mm,f'FCG Zentrale {__version__} · {lang.upper()}')
        canvas.drawRightString(190*mm,12*mm,str(document.page));canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return out.getvalue()
