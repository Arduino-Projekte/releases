"""Admin-controlled SMB imports into immutable, independently verified package caches."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import threading
import time

from . import __version__
from .central_updates import version_key
from .db import now_text
from . import docker_package, vm_package, ota as ota_mod
from .smb_updates import Share, ShareError, validate_source
from .update_source import public_text

KINDS = {'gateway': 'FCG-Gateway', 'vm': 'Zentrale (VM)', 'docker': 'Zentrale (Docker)'}
STATES = {'checked':'Geprüft – wartet auf Freigabe', 'approved':'Freigegeben', 'queued':'Installation angefordert',
          'installed':'Installiert', 'failed':'Installation fehlgeschlagen', 'rolled_back':'Vorheriger Stand wiederhergestellt'}


class OfflineUpdates:
    def __init__(self, db, secrets, data_dir, ota, deployment, *, share_factory=Share, keys=None):
        self.db, self.secrets, self.ota, self.deployment = db, secrets, ota, deployment
        self.root = Path(data_dir)/'offline_updates'
        (self.root/'cache').mkdir(parents=True,exist_ok=True,mode=0o700)
        self.share_factory, self.keys = share_factory, keys
        self._lock = threading.Lock()
        self._running = False
        self._thread = None
        self._sync_mode()

    def _sync_mode(self):
        marker=self.root/'offline-mode'
        if self.db.get_settings().get('update_mode')=='offline':
            fd,name=tempfile.mkstemp(prefix='.mode-',dir=self.root)
            try:
                with os.fdopen(fd,'w') as stream:stream.write('offline\n')
                os.replace(name,marker)
            finally:Path(name).unlink(missing_ok=True)
        else:marker.unlink(missing_ok=True)

    def set_mode(self, mode):
        if mode not in ('online','offline'):raise ValueError('Unbekannter Updatebetrieb.')
        self.db.set_settings({'update_mode':mode})
        self._sync_mode()

    def sources(self):
        with self.db.connect() as conn:
            rows = [dict(row) for row in conn.execute('SELECT * FROM update_sources ORDER BY lower(name),id')]
        for row in rows:
            row['has_password'] = bool(row.pop('password_enc'))
        return rows

    def source(self, source_id):
        with self.db.connect() as conn:
            row = conn.execute('SELECT * FROM update_sources WHERE id=?',(source_id,)).fetchone()
        if row is None:raise ValueError('Updatefreigabe nicht gefunden.')
        return dict(row)

    def save_source(self, source_id, values, password):
        clean = validate_source(values)
        if len(password)>256 or '\x00' in password:raise ValueError('SMB-Passwort ist zu lang oder enthält ein Nullzeichen.')
        previous = self.source(source_id) if source_id else None
        if previous and not password and (clean['server'].lower()!=previous['server'].lower() or clean['username']!=previous['username']):
            raise ValueError('Bei einem Server- oder Benutzerwechsel das SMB-Passwort erneut eingeben.')
        token = self.secrets.encrypt(password) if password else (previous['password_enc'] if previous else '')
        if not token:raise ValueError('Ein SMB-Passwort ist erforderlich. Ein Benutzer mit Leseberechtigung genügt.')
        fields = (*[clean[k] for k in ('name','server','share','subdir','username')],token,int(clean['encrypt']),int(clean['enabled']))
        with self.db.transaction() as conn:
            if source_id:
                conn.execute('UPDATE update_sources SET name=?,server=?,share=?,subdir=?,username=?,password_enc=?,encrypt=?,enabled=? WHERE id=?',(*fields,source_id))
            else:
                if conn.execute('SELECT COUNT(*) FROM update_sources').fetchone()[0]>=16:
                    raise ValueError('Höchstens 16 Updatefreigaben können verwaltet werden.')
                source_id = conn.execute('INSERT INTO update_sources(name,server,share,subdir,username,password_enc,encrypt,enabled) VALUES(?,?,?,?,?,?,?,?)',fields).lastrowid
        return source_id

    def delete_source(self, source_id):
        self.source(source_id)
        with self.db.transaction() as conn:
            conn.execute('DELETE FROM update_sources WHERE id=?',(source_id,))

    def clear_credentials(self, source_id):
        self.source(source_id)
        with self.db.transaction() as conn:
            conn.execute("UPDATE update_sources SET username='',password_enc='',enabled=0 WHERE id=?",(source_id,))

    def test(self, source_id):
        source = self.source(source_id)
        if not source['password_enc'] or not source['username']:raise ValueError('SMB-Zugangsdaten fehlen.')
        try:
            with self.share_factory(source,self.secrets.decrypt(source['password_enc']),timeout=20) as share:
                # Starting the iterator also proves directory read access, even if empty.
                next(iter(share.manifests()),None)
        except ShareError:raise
        except Exception:raise ValueError('SMB-Zugangsdaten können nicht verwendet werden. Verbindung und Sicherungsschlüssel prüfen.') from None
        return 'SMB-Verbindung und Lesezugriff erfolgreich geprüft.'

    def job(self):
        try:result = json.loads(self.db.get_settings().get('offline_update_job','{}'))
        except ValueError:result = {}
        if not isinstance(result,dict):result = {}
        if result.get('running') and not self._running:
            result.update(running=False,message='Einlesen wurde unterbrochen. Bitte erneut starten.')
        return result

    def _job(self, **values):
        self.db.set_settings({'offline_update_job':json.dumps({'at':now_text(),**values},ensure_ascii=False)})

    def start_scan(self, source_id=None):
        with self._lock:
            if self._running:raise ValueError('Es läuft bereits eine Paketprüfung.')
            self._running = True
        self._job(running=True,message='Updatefreigaben werden gelesen.',errors=[])
        self._thread = threading.Thread(target=self.scan,args=(source_id,),name='fcg-smb-updates',daemon=True)
        self._thread.start()

    def scan(self, source_id=None):
        """Synchronous entry point also used by the real SMB integration tests."""
        count, errors = 0, []
        try:
            sources = [self.source(source_id)] if source_id else [self.source(s['id']) for s in self.sources() if s['enabled']]
            if not sources:raise ValueError('Zuerst eine Updatefreigabe einrichten und aktivieren.')
            for source in sources:
                try:
                    if not source['enabled'] or not source['password_enc']:raise ValueError('Updatefreigabe ist deaktiviert oder hat keine Zugangsdaten.')
                    with self.share_factory(source,self.secrets.decrypt(source['password_enc'])) as share:
                        manifests = list(share.manifests())
                        if len(manifests)>64:raise ValueError('Zu viele Updatepakete. Höchstens 64 Manifeste je Updatefreigabe.')
                        for relative in manifests:
                            try:
                                self._import(share,relative,source['id'])
                                count += 1
                            except (ValueError,ota_mod.OtaError, OSError, KeyError, TypeError):
                                # Never expose raw SMB/JSON exceptions or secret-bearing paths.
                                errors.append('Ein Paket konnte nicht übernommen werden. Signatur, passende Paketdatei und freien Speicher prüfen.')
                except ShareError as exc:errors.append(str(exc))
                except Exception:errors.append('Eine Updatefreigabe ist nicht verwendbar. Zugangsdaten und Verbindung prüfen.')
            self._job(running=False,message=f'{count} Paket(e) geprüft und intern bereitgestellt.',errors=errors[:32])
        except Exception:
            self._job(running=False,message='Einlesen nicht möglich. Updatefreigaben und Verbindung prüfen.',errors=[])
        finally:
            self._running = False
        return count

    def _manifest(self, raw, name):
        if name=='update.json':
            m = ota_mod.parse_manifest(raw,self.ota.trusted)
            notes = m.get('notes','')
            return 'gateway',m,str(m['target'])+'/'+str(m['board_profile']), {'de':public_text(notes[:12000]) if isinstance(notes,str) else ''}, ota_mod.MAX_FIRMWARE_BYTES
        if name=='vm-update.json':
            m = vm_package.verify_manifest(raw,self.keys)
            return 'vm',m,m['target'],m['notes'],vm_package.MAX_PACKAGE
        m = docker_package.verify_manifest(raw,self.keys)
        if name!=f"docker-update-{m['architecture']}.json":raise ValueError('Docker-Architektur und Manifestname stimmen nicht überein.')
        return 'docker',m,m['architecture'],m['notes'],docker_package.MAX_PACKAGE

    def _import(self, share, relative, source_id):
        with tempfile.TemporaryDirectory(prefix='.incoming-',dir=self.root) as temporary:
            folder = Path(temporary)/'ready';folder.mkdir(mode=0o700)
            manifest_path = folder/'manifest.json'
            share.copy(relative,manifest_path,ota_mod.MAX_MANIFEST_BYTES)
            raw = manifest_path.read_bytes()
            kind,m,target,notes,limit = self._manifest(raw,PurePosixPath(relative).name)
            package_id = hashlib.sha256(kind.encode()+b'\n'+raw).hexdigest()
            binary = folder/m['file']
            remote = str(PurePosixPath(relative).parent/m['file'])
            if remote.startswith('./'):remote=remote[2:]
            # Always read the bytes afresh; a previous check does not bless changed SMB files.
            share.copy(remote,binary,limit)
            self._check_binary(kind,binary,m)
            destination = self.root/'cache'/package_id
            if destination.exists():
                if destination.is_symlink():raise ValueError('Ungültiger Paketcache.')
                # A valid snapshot never changes. Repair a missing/corrupt copy only
                # with freshly verified bytes bound to this identical manifest ID.
                try:self._verify_folder(destination,kind)
                except (ValueError,OSError,KeyError,ota_mod.OtaError):
                    for name in (m['file'],'manifest.json'):
                        fd,partial=tempfile.mkstemp(prefix='.repair-',dir=destination)
                        try:
                            with os.fdopen(fd,'wb') as dst,(folder/name).open('rb') as src:
                                shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
                            os.replace(partial,destination/name)
                        finally:Path(partial).unlink(missing_ok=True)
                    self._verify_folder(destination,kind)
            else:
                os.replace(folder,destination)
            with self.db.transaction() as conn:
                conn.execute('INSERT OR IGNORE INTO offline_packages(id,source_id,kind,version,target,filename,notes,imported_at) VALUES(?,?,?,?,?,?,?,?)',
                    (package_id,source_id,kind,m['version'],target,m['file'],json.dumps(notes,ensure_ascii=False),now_text()))

    def _check_binary(self, kind, binary, m):
        if kind=='vm':vm_package.check_package(binary,m)
        elif kind=='docker':docker_package.verify_archive(binary,m)
        else:
            with binary.open('rb') as handle:
                if hashlib.file_digest(handle,'sha256').hexdigest()!=m['sha256']:raise ValueError('Firmware-Prüfsumme stimmt nicht überein.')

    def _verify_folder(self, folder, kind):
        if folder.is_symlink() or (folder/'manifest.json').is_symlink():raise ValueError('Ungültiger Paketcache.')
        raw = (folder/'manifest.json').read_bytes()
        name = 'update.json' if kind=='gateway' else 'vm-update.json' if kind=='vm' else 'docker-update-'+json.loads(raw)['architecture']+'.json'
        checked,m,*_ = self._manifest(raw,name)
        if checked!=kind or (folder/m['file']).is_symlink():raise ValueError('Ungültiger Paketcache.')
        self._check_binary(kind,folder/m['file'],m)
        return m

    def package(self, package_id):
        if not re.fullmatch('[a-f0-9]{64}',package_id or ''):raise ValueError('Ungültige Paketkennung.')
        with self.db.connect() as conn:
            row = conn.execute('SELECT * FROM offline_packages WHERE id=?',(package_id,)).fetchone()
        if row is None:raise ValueError('Paket nicht gefunden.')
        return dict(row)

    def packages(self):
        with self.db.connect() as conn:
            rows = [dict(row) for row in conn.execute('SELECT * FROM offline_packages ORDER BY imported_at DESC,id DESC LIMIT 200')]
        for row in rows:
            row['notes'] = json.loads(row['notes'])
            row['kind_text'] = KINDS[row['kind']]
            row['target_text'] = 'FCG ESP32-S3 · Hardwareprofil 1' if row['kind']=='gateway' and row['target']=='esp32s3/1' else 'Debian-VM · Intel/AMD64' if row['kind']=='vm' else 'Linux · Intel/AMD64' if row['target']=='amd64' else 'Linux · ARM64' if row['target']=='arm64' else row['target']
            row['state_text'] = STATES.get(row['state'],row['state'])
            row['cached'] = (self.root/'cache'/row['id']/row['filename']).is_file()
            row['compatible'] = (row['kind']=='gateway' and row['target']=='esp32s3/1'
                or row['kind']==self.deployment and (row['kind']=='vm' or row['target']==docker_package.architecture()))
            row['newer'] = row['kind']=='gateway' or version_key(row['version'])>version_key(__version__)
        return rows

    def approve_gateway(self, package_id, username):
        row = self.package(package_id)
        if row['kind']!='gateway' or row['target']!='esp32s3/1':raise ValueError('Paket passt nicht zu den unterstützten FCG-Gateways.')
        folder = self.root/'cache'/package_id
        self._verify_folder(folder,'gateway')
        self.ota.import_local(folder/'manifest.json',folder/row['filename'])
        self.ota.approve(row['version'],username)
        self.decide(package_id,'approved',username)
        return row

    def decide(self, package_id, state, username):
        if state not in STATES:raise ValueError('Ungültiger Paketstatus.')
        with self.db.transaction() as conn:
            conn.execute('UPDATE offline_packages SET state=?,decided_by=?,decided_at=? WHERE id=?',(state,username,now_text(),package_id))

    def install(self, package_id, username):
        row = self.package(package_id)
        if row['kind']!=self.deployment or row['kind'] not in ('vm','docker'):
            raise ValueError('Updatepaket passt nicht zu dieser Installation.')
        if version_key(row['version'])<=version_key(__version__):raise ValueError('Nur eine neuere Version kann installiert werden.')
        folder = self.root/'cache'/package_id
        manifest = self._verify_folder(folder,row['kind'])
        if row['kind']=='vm':
            from .vm_queue import enqueue_offline
            enqueue_offline(manifest,folder/'manifest.json',folder/row['filename'])
        else:
            from .docker_queue import enqueue
            enqueue(package_id,self.root)
        self.decide(package_id,'queued',username)
