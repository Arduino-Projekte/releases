"""HTTP-Zugriff auf die Gateway-API.

Das Gateway spricht nur HTTP. Zugangsdaten gehen per Basic-Auth mit, wie
beim PowerShell-Collector (fcg_collector/central_share/fcg_collect.ps1).
"""
from __future__ import annotations

import base64
import errno
import json
import re
import socket
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable

# Hostname oder IPv4, optional mit Port. Keine Pfade, keine Zugangsdaten in der URL.
HOST_PATTERN = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.\-]{0,251}[A-Za-z0-9])?(?::\d{1,5})?$")
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
MAX_GATEWAY_LIMIT = 100


class GatewayError(Exception):
    """Abruf fehlgeschlagen; die Meldung ist für die Anzeige gedacht."""


class GatewayUnreachable(GatewayError):
    """Keine Verbindung zum Gateway (aus, falsche Adresse, kein Netz)."""


class GatewayTimeout(GatewayUnreachable):
    pass


@dataclass(frozen=True)
class GatewayAuth:
    username: str = ""
    password: str = ""


def normalize_host(host: str) -> str:
    value = (host or "").strip()
    if value.lower().startswith("http://"):
        value = value[7:]
    value = value.rstrip("/")
    if not HOST_PATTERN.match(value):
        raise ValueError("Ungültige Adresse. Erlaubt sind IP oder Hostname, optional mit :Port.")
    if ":" in value and not 1 <= int(value.rsplit(":", 1)[1]) <= 65535:
        raise ValueError("Ungültiger Port.")
    return value


def _is_timeout(exc: BaseException) -> bool:
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return True
    reason = getattr(exc, "reason", None)
    return isinstance(reason, (socket.timeout, TimeoutError))


def _describe_network_error(exc: BaseException) -> str:
    reason = getattr(exc, "reason", exc)
    if isinstance(reason, ConnectionRefusedError):
        return "Verbindung abgelehnt (Gateway aus, oder Adresse/Port falsch)."
    if isinstance(reason, socket.gaierror):
        return "Hostname unbekannt."
    if isinstance(reason, OSError) and reason.errno in (errno.EHOSTUNREACH, errno.ENETUNREACH):
        return "keine Route zum Gateway (anderes Netz oder Gateway aus)."
    return str(reason)


def _send(request: urllib.request.Request, path: str, auth: GatewayAuth, timeout: float) -> bytes:
    if auth.username:
        token = base64.b64encode(f"{auth.username}:{auth.password}".encode("utf-8")).decode("ascii")
        request.add_header("Authorization", f"Basic {token}")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(MAX_RESPONSE_BYTES + 1)
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise GatewayError(
                "HTTP 401: Anmeldung abgelehnt. Im Gateway unter Admin > Collector-Zugriff "
                "Benutzer und Passwort prüfen und hier eintragen."
            ) from exc
        if exc.code == 403:
            raise GatewayError("HTTP 403: Zugriff vom Gateway gesperrt (z. B. nach Fehlversuchen).") from exc
        detail = _error_message(exc)
        raise GatewayError(f"HTTP {exc.code} bei {path}" + (f": {detail}" if detail else "")) from exc
    except (urllib.error.URLError, OSError) as exc:
        if _is_timeout(exc):
            raise GatewayTimeout(f"Zeitüberschreitung nach {timeout:g} s bei {path}") from exc
        raise GatewayUnreachable(f"Gateway nicht erreichbar: {_describe_network_error(exc)}") from exc

    if len(raw) > MAX_RESPONSE_BYTES:
        raise GatewayError("Antwort des Gateways ist unplausibel groß.")
    return raw


def _error_message(exc: urllib.error.HTTPError) -> str:
    """Meldung aus einer JSON-Fehlerantwort des Gateways, sonst leer."""
    try:
        data = json.loads(exc.read(64 * 1024).decode("utf-8"))
    except Exception:
        return ""
    if isinstance(data, dict):
        for key in ("message", "error"):
            if isinstance(data.get(key), str) and data[key]:
                return data[key][:300]
    return ""


def http_get_bytes(host: str, path: str, auth: GatewayAuth, timeout: float, accept: str = "application/json") -> bytes:
    request = urllib.request.Request(f"http://{host}{path}", headers={"Accept": accept, "Cache-Control": "no-cache"})
    return _send(request, path, auth, timeout)


def _parse_json(raw: bytes) -> Any:
    if not raw.strip():
        raise GatewayError("Leere Antwort vom Gateway.")
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        preview = raw[:300].decode("utf-8", "replace")
        raise GatewayError(f"Antwort ist kein gültiges JSON (Login- oder Fehlerseite?): {preview}") from exc


def http_get_json(host: str, path: str, auth: GatewayAuth, timeout: float) -> Any:
    return _parse_json(http_get_bytes(host, path, auth, timeout))


def http_post_json(host: str, path: str, auth: GatewayAuth, timeout: float) -> Any:
    """Schreibender Aufruf. Das Gateway verlangt POST und X-FCG-Write-Intent: 1."""
    request = urllib.request.Request(f"http://{host}{path}", data=b"", method="POST", headers={
        "Accept": "application/json", "Cache-Control": "no-cache", "X-FCG-Write-Intent": "1",
        "Content-Type": "application/x-www-form-urlencoded"})
    return _parse_json(_send(request, path, auth, timeout))


def http_get_text(host: str, path: str, auth: GatewayAuth, timeout: float) -> str:
    """Textdatei vom Gateway, z. B. /api/log.txt."""
    return http_get_bytes(host, path, auth, timeout, accept="text/plain").decode("utf-8", "replace")


def fetch_collector_page(host: str, after_seq: int, limit: int, auth: GatewayAuth, timeout: float) -> dict:
    limit = max(1, min(int(limit), MAX_GATEWAY_LIMIT))
    data = http_get_json(host, f"/api/collector?after_seq={int(after_seq)}&limit={limit}", auth, timeout)
    if not isinstance(data, dict):
        raise GatewayError("Antwort von /api/collector ist kein JSON-Objekt.")
    return data


FetchFn = Callable[[str, int, int, GatewayAuth, float], dict]
JsonFn = Callable[[str, str, GatewayAuth, float], Any]
PostFn = Callable[[str, str, GatewayAuth, float], Any]
TextFn = Callable[[str, str, GatewayAuth, float], str]
