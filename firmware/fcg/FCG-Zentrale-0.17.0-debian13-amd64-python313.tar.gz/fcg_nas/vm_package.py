"""Signed, bounded application packages for the Debian VM edition."""
import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from .ota import TRUSTED_KEYS

MAX_PACKAGE = 128 * 1024 * 1024
MAX_UNPACKED = 512 * 1024 * 1024
TARGET = 'debian13-amd64-python313'
FIELDS = ('schema', 'version', 'target', 'file', 'sha256', 'key_id', 'notes')


def payload(manifest):
    return ('FCG-VM-PACKAGE-V1\n' + json.dumps({k: manifest[k] for k in FIELDS},
            sort_keys=True, ensure_ascii=True, separators=(',', ':')) + '\n').encode()


def trusted_keys(path=Path('/etc/fcg/update-keys.json')):
    # This file is installed root-owned; the web service cannot change trust.
    return json.loads(path.read_text()) if path.is_file() else TRUSTED_KEYS


def verify_manifest(raw, keys=None):
    if len(raw) > 32768:
        raise ValueError('Update-Manifest ist zu groß.')
    m = json.loads(raw)
    if not isinstance(m, dict) or m.get('schema') != 'fcg_vm_package_v1' or m.get('target') != TARGET:
        raise ValueError('Update-Paket passt nicht zu dieser VM.')
    version = m.get('version', '')
    if not isinstance(version, str) or not re.fullmatch(r'\d{1,6}\.\d{1,6}\.\d{1,6}', version):
        raise ValueError('Ungültige Paketversion.')
    if m.get('file') != f'FCG-Zentrale-{version}-{TARGET}.tar.gz':
        raise ValueError('Ungültiger Paketdateiname.')
    if not isinstance(m.get('sha256'), str) or not re.fullmatch(r'[0-9a-f]{64}', m['sha256']):
        raise ValueError('Ungültige Paketprüfsumme.')
    if not isinstance(m.get('notes'), dict) or any(k not in ('de', 'en') or not isinstance(v, str)
                                                 or len(v) > 12000 for k, v in m['notes'].items()):
        raise ValueError('Ungültige Versionshinweise.')
    try:
        key = load_pem_public_key((keys if keys is not None else trusted_keys())[m['key_id']].encode())
        key.verify(base64.b64decode(m['signature'], validate=True), payload(m), ec.ECDSA(hashes.SHA256()))
    except Exception as exc:
        raise ValueError('Update-Signatur ist ungültig oder der Schlüssel unbekannt.') from exc
    return m


def check_package(package, manifest):
    if package.stat().st_size > MAX_PACKAGE:
        raise ValueError('Update-Paket ist zu groß.')
    with package.open('rb') as handle:
        if hashlib.file_digest(handle, 'sha256').hexdigest() != manifest['sha256']:
            raise ValueError('Update-Prüfsumme stimmt nicht überein.')
    with tarfile.open(package, 'r:gz') as archive:
        members = archive.getmembers()
        if len(members) > 10000 or sum(m.size for m in members) > MAX_UNPACKED:
            raise ValueError('Entpacktes Paket ist zu groß.')
        names = set()
        for member in members:
            path = PurePosixPath(member.name)
            if (path.is_absolute() or '..' in path.parts or not path.parts
                    or path.parts[0] not in ('fcg_nas', 'wheels', 'requirements.txt')
                    or not (member.isfile() or member.isdir()) or member.name in names):
                raise ValueError('Update enthält einen unerlaubten Dateipfad.')
            names.add(member.name)
        if 'fcg_nas/__init__.py' not in names or 'requirements.txt' not in names:
            raise ValueError('Update ist unvollständig.')


def unpack(package, destination, manifest):
    check_package(package, manifest)
    with tarfile.open(package, 'r:gz') as archive:
        archive.extractall(destination, filter='data')
