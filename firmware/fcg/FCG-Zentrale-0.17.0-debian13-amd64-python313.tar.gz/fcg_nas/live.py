"""Füllanzeige: fragt alle Gateways regelmäßig nach Livewerten.

Quelle ist /api/counter (ohne Login lesbar). Es liefert pulse_seen,
seconds_since_last_pulse, flow_per_hour und die Blockmengen. /api/live hat
pulse_seen nicht; dort heißt seconds_since_last_pulse=0 sowohl "gerade eben"
als auch "seit dem Neustart kein Impuls".

"Wird befüllt" heißt: es gab einen Impuls in den letzten N Minuten
(Einstellung fueling_window_min, Standard 10).
Die Werte liegen nur im Speicher; nach einem Neustart des Containers sind sie
nach dem ersten Abruf wieder da.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any

from .db import Database, now_text
from .gateway_client import GatewayAuth, GatewayError, JsonFn, http_get_json

log = logging.getLogger("fcg_nas.live")

LIVE_TIMEOUT_S = 5.0
# Ruhe-Wächter der Firmware: Update nur, wenn so lange kein Impuls kam.
UPDATE_IDLE_S = 600
MAX_WORKERS = 8


@dataclass
class LiveState:
    ok: bool
    fetched_at: str
    fetched_mono: float
    error: str = ""
    pulse_seen: bool = False
    seconds_since_pulse: float | None = None
    flow_per_hour: float = 0.0
    total_quantity: float | None = None
    unit: str = "l"
    active_block: bool = False
    block_quantity: float | None = None   # laufender Füllvorgang, sonst der letzte
    today_quantity: float | None = None
    # Speicherzustand aus persisted_state; None = ältere Firmware ohne das Feld
    save_failed: bool | None = None
    save_error: str = ""
    pulses_per_unit: float | None = None

    def seconds_since_pulse_now(self) -> float | None:
        """Sekunden seit dem letzten Impuls, fortgeschrieben bis jetzt."""
        if not self.ok or not self.pulse_seen or self.seconds_since_pulse is None:
            return None
        return self.seconds_since_pulse + (time.monotonic() - self.fetched_mono)


def _num(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def parse_counter(data: Any) -> LiveState:
    if not isinstance(data, dict):
        raise GatewayError("Antwort von /api/counter ist kein JSON-Objekt.")
    averages = data.get("consumption_averages") if isinstance(data.get("consumption_averages"), dict) else {}
    seconds = _num(data.get("seconds_since_last_pulse"))
    if "pulse_seen" in data:
        pulse_seen = data.get("pulse_seen") is True
    else:
        # Ältere Firmware: 0 ist nicht von "nie" zu unterscheiden, daher nur > 0 werten.
        pulse_seen = bool(seconds and seconds > 0)
    persisted = data.get("persisted_state") if isinstance(data.get("persisted_state"), dict) else {}
    save_failed = persisted.get("last_save_failed") if isinstance(persisted.get("last_save_failed"), bool) else None
    active = averages.get("active_block") is True
    block = _num(averages.get("active_block_quantity")) if active else _num(averages.get("last_block_quantity"))
    return LiveState(
        ok=True,
        fetched_at=now_text(),
        fetched_mono=time.monotonic(),
        pulse_seen=pulse_seen,
        seconds_since_pulse=seconds,
        flow_per_hour=_num(data.get("flow_per_hour")) or 0.0,
        total_quantity=_num(data.get("total_quantity")),
        unit=str(data.get("unit") or "l"),
        active_block=active,
        block_quantity=block,
        today_quantity=_num(averages.get("today_quantity")),
        save_failed=save_failed,
        save_error=str(persisted.get("last_save_error") or "")[:300],
        pulses_per_unit=_num(data.get("pulses_per_unit")),
    )


def format_age(seconds: float) -> str:
    seconds = int(seconds)
    if seconds < 60:
        return "unter 1 Minute"
    if seconds < 3600:
        minutes = seconds // 60
        return "1 Minute" if minutes == 1 else f"{minutes} Minuten"
    if seconds < 48 * 3600:
        hours = seconds // 3600
        return "1 Stunde" if hours == 1 else f"{hours} Stunden"
    return f"{seconds // 86400} Tagen"


class LiveMonitor:
    def __init__(self, db: Database, get_json: JsonFn = http_get_json) -> None:
        self.db = db
        self.get_json = get_json
        self._lock = threading.Lock()
        self._states: dict[int, LiveState] = {}
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._stored_ppu: dict[int, float] = {}

    # --- Abfrage --------------------------------------------------------

    def poll_gateway(self, gateway_id: int, host: str) -> LiveState:
        try:
            state = parse_counter(self.get_json(host, "/api/counter", GatewayAuth(), LIVE_TIMEOUT_S))
        except (GatewayError, ValueError) as exc:
            state = LiveState(ok=False, fetched_at=now_text(), fetched_mono=time.monotonic(), error=str(exc))
        with self._lock:
            self._states[gateway_id] = state
        if state.ok and state.pulses_per_unit and self._stored_ppu.get(gateway_id) != state.pulses_per_unit:
            # Für die Messstellen-Seite merken, auch wenn das Gateway später nicht erreichbar ist.
            with self.db.connect() as conn:
                conn.execute("UPDATE gateways SET pulses_per_unit = ? WHERE id = ?", (state.pulses_per_unit, gateway_id))
            self._stored_ppu[gateway_id] = state.pulses_per_unit
        return state

    def poll_all(self) -> None:
        with self.db.connect() as conn:
            gateways = [(r["id"], r["host"]) for r in conn.execute("SELECT id, host FROM gateways WHERE enabled = 1")]
        with self._lock:
            known = {gid for gid, _ in gateways}
            for gid in list(self._states):
                if gid not in known:
                    del self._states[gid]
        if not gateways:
            return
        with ThreadPoolExecutor(max_workers=min(MAX_WORKERS, len(gateways)), thread_name_prefix="fcg-live") as pool:
            list(pool.map(lambda g: self.poll_gateway(*g), gateways))

    # --- Auswertung -----------------------------------------------------

    def state(self, gateway_id: int) -> LiveState | None:
        with self._lock:
            return self._states.get(gateway_id)

    def view(self, gateway_id: int) -> dict:
        """Fertige Anzeige für Kachel und /api/status."""
        window_s = self.db.get_int_setting("fueling_window_min") * 60
        state = self.state(gateway_id)
        if state is None:
            return {"state": "unknown", "text": "Livewerte noch nicht abgefragt", "fueling": False}
        if not state.ok:
            return {"state": "error", "text": "Livewerte nicht abrufbar", "fueling": False, "error": state.error}
        age = state.seconds_since_pulse_now()
        unit = state.unit or "l"
        # Zählerstand live vom Gateway: zeigt auch Korrekturen ohne Füllvorgang.
        total = {"total_text": f"{_de(state.total_quantity)} {unit}"} if state.total_quantity is not None else {}
        # Vorschau für Firmware > Gateways aktualisieren (ohne Login; den CAN-Bus prüft erst "Zustand abfragen").
        if age is None:
            total.update(update_ready=True, update_text="kein Impuls seit dem Neustart")
        elif age >= UPDATE_IDLE_S:
            total.update(update_ready=True, update_text=f"letzter Impuls vor {format_age(age)}")
        else:
            wait = format_age(UPDATE_IDLE_S - age + 59)
            total.update(update_ready=False, update_text=f"letzter Impuls vor {format_age(age)}, frühestens in {wait}")
        if age is not None and age < window_s:
            parts = ["Wird befüllt" if state.active_block else "Befüllt"]
            parts[0] += f", letzter Impuls vor {format_age(age)}"
            if state.block_quantity:
                parts.append(f"{_de(state.block_quantity)} {unit}")
            if state.active_block and state.flow_per_hour > 0:
                parts.append(f"{_de(state.flow_per_hour, 0)} {unit}/h")
            return {"state": "fueling", "text": " · ".join(parts), "fueling": True,
                    "seconds": int(age), "quantity": state.block_quantity, "flow": state.flow_per_hour, **total}
        if age is None:
            text = "Seit dem Neustart des Gateways kein Füllvorgang"
        else:
            text = f"Letzter Füllvorgang vor {format_age(age)}"
        return {"state": "idle", "text": text, "fueling": False, "seconds": None if age is None else int(age), **total}

    # --- Hintergrund ------------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="fcg-live", daemon=True)
        self._thread.start()

    def poke(self) -> None:
        """Sofort neu abfragen, z. B. nach dem Anlegen eines Gateways."""
        self._wake.set()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join(timeout=LIVE_TIMEOUT_S + 2)

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._wake.clear()
            started = time.monotonic()
            try:
                self.poll_all()
            except Exception:  # Livewerte dürfen nie den Dienst beenden
                log.exception("Livewerte konnten nicht abgefragt werden")
            interval = max(10, self.db.get_int_setting("live_interval_sec"))
            self._wake.wait(max(1.0, interval - (time.monotonic() - started)))


def _de(value: float, digits: int = 1) -> str:
    text = f"{value:,.{digits}f}"
    return text.replace(",", "_").replace(".", ",").replace("_", ".")
