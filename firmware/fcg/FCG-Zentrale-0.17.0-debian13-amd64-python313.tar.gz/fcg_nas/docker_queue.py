"""No Docker socket in the UI. A separately configured host worker consumes requests."""
import fcntl
import json
import os
from pathlib import Path
import re
import tempfile
import time


def status(root):
    result={}
    try:
        value=json.loads((root/'docker-status.json').read_text())
        if isinstance(value,dict):result={k:str(value.get(k,''))[:120] for k in ('state','version','at','package_id')}
    except (OSError,ValueError):pass
    try:
        epoch=int((root/'docker-heartbeat').read_text())
        result['ready']=0<=time.time()-epoch<180
    except (OSError,ValueError):result['ready']=False
    result['pending']=(root/'docker-inbox/request.json').exists()
    return result


def enqueue(package_id,root):
    if not re.fullmatch('[a-f0-9]{64}',package_id):raise ValueError('Ungültige Paketkennung.')
    if status(root).get('state')=='preparing':raise ValueError('Ein Docker-Update wird bereits verarbeitet.')
    if not status(root).get('ready'):
        raise ValueError('Der Docker-Updatedienst auf der NAS ist nicht eingerichtet oder nicht erreichbar. Anleitung zur einmaligen Einrichtung beachten.')
    inbox=root/'docker-inbox';inbox.mkdir(mode=0o700,exist_ok=True)
    with (inbox/'queue.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if os.path.lexists(inbox/'request.json'):raise ValueError('Ein Docker-Update wartet bereits auf Verarbeitung.')
        fd,name=tempfile.mkstemp(prefix='.request-',dir=inbox)
        try:
            with os.fdopen(fd,'w') as stream:
                json.dump({'package_id':package_id},stream);stream.flush();os.fsync(stream.fileno())
            os.replace(name,inbox/'request.json')
        finally:Path(name).unlink(missing_ok=True)


def host_state(root, action, state='', version='', package_id=''):
    """Runs in a read-only, pristine helper container with ONLY /data writable.

    Never let host-root shell writes follow a symlink placed by the web container.
    An absolute symlink here reaches the helper's read-only root, not the NAS root.
    """
    if root.is_symlink():raise ValueError('Ungültiger Statusordner.')
    root.mkdir(mode=0o700,exist_ok=True)
    if action=='consume':
        inbox=root/'docker-inbox'
        fd=os.open(inbox,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:
            try:os.unlink('request.json',dir_fd=fd)
            except FileNotFoundError:pass
        finally:os.close(fd)
        return
    if action=='heartbeat':
        if (root/'docker-inbox').is_symlink():raise ValueError('Ungültiger Anforderungsordner.')
        (root/'docker-inbox').mkdir(mode=0o700,exist_ok=True)
        filename, value = 'docker-heartbeat', str(int(time.time()))
    else:
        if state not in ('preparing','installed','rolled_back','failed'):raise ValueError('Ungültiger Status.')
        if version and not re.fullmatch(r'\d{1,6}\.\d{1,6}\.\d{1,6}',version):raise ValueError('Ungültige Version.')
        if package_id and not re.fullmatch('[a-f0-9]{64}',package_id):raise ValueError('Ungültige Paketkennung.')
        from .db import now_text
        filename,value='docker-status.json',json.dumps(dict(state=state,version=version,package_id=package_id,at=now_text()))
    fd,name=tempfile.mkstemp(prefix='.host-',dir=root)
    try:
        os.fchmod(fd,0o644)
        with os.fdopen(fd,'w') as stream:stream.write(value);stream.flush();os.fsync(stream.fileno())
        os.replace(name,root/filename)
    finally:Path(name).unlink(missing_ok=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['heartbeat','consume','status'])
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--state',default='')
    parser.add_argument('--version',default='')
    parser.add_argument('--package-id',default='')
    args=parser.parse_args()
    try:host_state(args.root,args.action,args.state,args.version,args.package_id)
    except Exception:raise SystemExit('Update-Statusordner ist nicht sicher verwendbar.')
