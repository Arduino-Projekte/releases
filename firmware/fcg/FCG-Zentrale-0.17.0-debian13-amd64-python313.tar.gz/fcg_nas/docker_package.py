"""Signed offline Docker images; validation also runs in a pristine host helper image."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import stat
import tarfile

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from .central_updates import version_key
from .ota import TRUSTED_KEYS

MAX_PACKAGE = 2 * 1024**3
FIELDS = ('schema', 'version', 'target', 'architecture', 'file', 'sha256', 'image_id', 'key_id', 'notes')


def architecture():
    return {'x86_64': 'amd64', 'aarch64': 'arm64', 'arm64': 'arm64'}.get(platform.machine().lower(), '')


def payload(manifest):
    return ('FCG-DOCKER-PACKAGE-V1\n' + json.dumps({k: manifest[k] for k in FIELDS},
            sort_keys=True, ensure_ascii=True, separators=(',', ':')) + '\n').encode()


def verify_manifest(raw, keys=None):
    if len(raw) > 32768:raise ValueError('Docker-Manifest ist zu groß.')
    m = json.loads(raw)
    if not isinstance(m, dict) or m.get('schema') != 'fcg_docker_package_v1' or m.get('target') != 'fcg-central-docker':
        raise ValueError('Unbekanntes Docker-Updatepaket.')
    version_key(m.get('version'))
    if m.get('architecture') not in ('amd64', 'arm64'):
        raise ValueError('Docker-Paket hat eine nicht unterstützte Architektur.')
    if m.get('file') != f"FCG-Zentrale-{m['version']}-docker-{m['architecture']}.tar.gz":
        raise ValueError('Ungültiger Docker-Paketdateiname.')
    if not re.fullmatch(r'[a-f0-9]{64}', str(m.get('sha256', ''))) or not re.fullmatch(r'sha256:[a-f0-9]{64}', str(m.get('image_id', ''))):
        raise ValueError('Ungültige Docker-Prüfsumme oder Image-ID.')
    if not isinstance(m.get('notes'), dict) or any(k not in ('de','en') or not isinstance(v,str) or len(v)>12000 for k,v in m['notes'].items()):
        raise ValueError('Ungültige Versionshinweise.')
    try:
        key = load_pem_public_key((TRUSTED_KEYS if keys is None else keys)[m['key_id']].encode())
        key.verify(base64.b64decode(m['signature'], validate=True), payload(m), ec.ECDSA(hashes.SHA256()))
    except Exception:
        raise ValueError('Docker-Signatur ist ungültig oder der Schlüssel unbekannt.') from None
    return m


def verify_archive(path, manifest):
    if path.stat().st_size > MAX_PACKAGE:raise ValueError('Docker-Paket ist zu groß.')
    with path.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=manifest['sha256']:
            raise ValueError('Docker-Paket stimmt nicht mit der signierten Prüfsumme überein.')
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        if len(members)>20000 or sum(m.size for m in members)>8*1024**3:
            raise ValueError('Docker-Archiv ist zu groß.')
        names = set()
        for item in members:
            parts = Path(item.name).parts
            if (item.name.startswith('/') or '..' in parts or item.name in names
                    or not (item.isfile() or item.isdir())):
                raise ValueError('Docker-Archiv enthält unerlaubte Einträge.')
            names.add(item.name)
        def read(name, limit):
            item = archive.getmember(name)
            if not item.isfile() or item.size>limit:raise ValueError('Ungültige Docker-Metadaten.')
            return archive.extractfile(item).read(limit+1)
        images = json.loads(read('manifest.json',65536))
        if not isinstance(images,list) or len(images)!=1 or not isinstance(images[0],dict):
            raise ValueError('Das Paket muss genau ein Docker-Image enthalten.')
        config = read(images[0]['Config'],1024*1024)
        if 'sha256:'+hashlib.sha256(config).hexdigest()!=manifest['image_id']:
            raise ValueError('Docker-Image-ID passt nicht zum Manifest.')
        info = json.loads(config)
        if info.get('os')!='linux' or info.get('architecture')!=manifest['architecture']:
            raise ValueError('Docker-Image passt nicht zur angegebenen Plattform.')
        if info.get('config',{}).get('Labels',{}).get('org.opencontainers.image.version')!=manifest['version']:
            raise ValueError('Docker-Image und Versionsangabe stimmen nicht überein.')


def stage(incoming, output, keys=None):
    """Host starts this from its trusted installed image, never via docker exec.

    The request only selects a bounded cache ID. The copied package is reverified
    in private host storage before any Docker load/stop command is allowed.
    """
    if incoming.is_symlink() or (incoming/'docker-inbox').is_symlink() or (incoming/'cache').is_symlink():
        raise ValueError('Ungültiger Paketpfad.')
    request = incoming/'docker-inbox/request.json'
    fd = os.open(request,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size>4096:raise ValueError('Ungültige Updateanforderung.')
        value = json.loads(handle.read(4097))
    package_id = value.get('package_id') if isinstance(value,dict) else None
    if not isinstance(package_id,str) or not re.fullmatch('[a-f0-9]{64}',package_id):
        raise ValueError('Ungültige Paketkennung.')
    folder = incoming/'cache'/package_id
    if folder.is_symlink() or (folder/'manifest.json').is_symlink():raise ValueError('Ungültiger Paketpfad.')
    with (folder/'manifest.json').open('rb') as handle:raw = handle.read(32769)
    manifest = verify_manifest(raw, keys)
    if manifest['architecture']!=architecture():raise ValueError('Docker-Paket passt nicht zu diesem Host.')
    source = folder/manifest['file']
    if source.is_symlink() or not source.is_file() or source.stat().st_size>MAX_PACKAGE:
        raise ValueError('Docker-Paketdatei fehlt oder ist zu groß.')
    from . import __version__
    if version_key(manifest['version'])<=version_key(__version__):raise ValueError('Keine neuere Docker-Version angefordert.')
    output.mkdir(parents=True,exist_ok=True)
    with source.open('rb') as src, (output/'package.tar.gz').open('wb') as dst:
        shutil.copyfileobj(src,dst,1024*1024)
    verify_archive(output/'package.tar.gz',manifest)
    (output/'manifest.json').write_bytes(raw)
    for name, text in (('next-image',manifest['image_id']),('next-version',manifest['version']),('package-id',package_id)):
        (output/name).write_text(text+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['stage'])
    parser.add_argument('--incoming',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--keys',type=Path)
    args=parser.parse_args()
    try:
        stage(args.incoming,args.output,json.loads(args.keys.read_text()) if args.keys else None)
    except Exception:
        raise SystemExit('Docker-Paket konnte nicht unabhängig geprüft werden. Manifest, Image und Architektur prüfen.')
