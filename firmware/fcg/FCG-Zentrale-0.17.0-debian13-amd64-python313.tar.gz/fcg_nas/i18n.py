"""Explicit UI messages; additional locales require a catalog, not application changes."""
import html
import json
import re
from functools import lru_cache
from pathlib import Path
from jinja2 import pass_context

ROOT = Path(__file__).with_name("locales")

def key(text):
    return " ".join(html.unescape(str(text)).split())

@lru_cache(maxsize=1)
def catalogs():
    return {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in sorted(ROOT.glob('*.json'))
            if re.fullmatch(r'[a-z]{2,3}(?:-[A-Z]{2})?', p.stem)}

def language(request):
    options = catalogs()
    cookie = request.cookies.get('fcg-language', '')
    if cookie in options:
        return cookie
    for part in request.headers.get('accept-language', '').split(','):
        candidate = part.split(';', 1)[0].strip()
        if candidate in options:
            return candidate
        if candidate.split('-')[0] in options:
            return candidate.split('-')[0]
    return 'de'

def translate(message, lang='de'):
    original = html.unescape(str(message))
    if lang == 'de':
        return original
    messages = catalogs().get(lang, {}).get('messages', {})
    exact = messages.get(key(original))
    if exact is not None:
        prefix = original[:len(original)-len(original.lstrip())]
        suffix = original[len(original.rstrip()):]
        return prefix + exact + suffix
    if lang == 'en':
        imported = re.fullmatch(r"(\d+) Paket\(e\) geprüft und intern bereitgestellt\.", original)
        if imported:
            return f"{imported[1]} package(s) verified and stored locally."
        for before, after in [('Stichtagsmonat (ab ', 'Cutoff month (from '), ('Jahr (ab ', 'Year (from ')]:
            if original.startswith(before) and original.endswith(')'):
                return after + original[len(before):]
        match = re.fullmatch(r"Verbrauch unbekannt bei (\d+) Eintrag/Eintraegen \(CSV-Feld 'Verbraucht' leer\)", original)
        if match:
            return f"Consumption unknown for {match[1]} entries (CSV field 'Verbraucht' is empty)"
    return original

@pass_context
def translated(context, message):
    return translate(message, context.get('lang', 'de'))

JS_MESSAGES = ["◐ Auto", "☀ Tag", "☾ Nacht", "Status nicht abrufbar", "Keine Abholung aktiv",
               "Abholung läuft: Gateway {current} von {total}", ", bisher {count} neue Einträge",
               " · letzte: {at}", " · nächste in {duration}", "unter 1 Minute", "{count} Minuten"]


def localized_live(view, lang='de'):
    if not isinstance(view, dict) or lang == 'de':
        return view
    t = lambda message: translate(message, lang)
    result = dict(view)
    seconds = view.get('seconds')
    age = None
    if isinstance(seconds, (int,float)):
        age = t('unter einer Minute') if seconds < 60 else (t('{count} Minuten').format(count=int(seconds//60)) if seconds < 3600 else t('{count} Stunden').format(count=int(seconds//3600)))
    if view.get('state') == 'unknown':
        result['text'] = t('Livewerte noch nicht abgefragt')
    elif view.get('state') == 'error':
        result['text'] = t('Livewerte nicht abrufbar')
    elif view.get('state') == 'fueling':
        result['text'] = t('Wird befüllt') if str(view.get('text','')).startswith('Wird') else t('Befüllt')
        if age:
            result['text'] += t(', letzter Impuls vor {age}').format(age=age)
        unit = str(view.get('total_text', '')).partition(' ')[2] or 'l'
        if view.get('quantity'):
            result['text'] += f" · {float(view['quantity']):,.1f} {unit}"
        if view.get('flow') and '/h' in str(view.get('text', '')):
            result['text'] += f" · {float(view['flow']):,.0f} {unit}/h"
    elif view.get('state') == 'idle':
        result['text'] = t('Letzter Füllvorgang vor {age}').format(age=age) if age else t('Seit dem Neustart des Gateways kein Füllvorgang')
    total = str(view.get('total_text', ''))
    match = re.fullmatch(r'([-+0-9.,]+)(\s+.*)',total)
    if match:
        result['total_text'] = match[1].replace('.','').replace(',','.') + match[2]
    return result

JS_MESSAGES += ['Mindestens 8 Zeichen mit Großbuchstabe, Kleinbuchstabe, Zahl und Sonderzeichen.', 'Grün – länger und vielfältiger.', 'Gelb – Mindestanforderungen erfüllt; Passwort ist zulässig.', 'Rot – Anforderungen noch nicht erfüllt.', 'Passwort eingeben.']
