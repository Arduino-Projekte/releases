"""Statistik wie der PowerShell-Collector (New-FcgStatisticsReport in fcg_collect.ps1).

Zeiträume:
- Kalendermonat: Anker Tag 1, Schritt 1 Monat
- Stichtagsmonat: Anker Stichtag (1-28), Schritt 1 Monat, z. B. 25.05. bis 24.06.
- Jahr: Anker TT.MM, Schritt 12 Monate
Jeder Zeitraum läuft vom Start (inklusive) bis vor den nächsten Start, kein Tag
wird doppelt gezählt. Gruppen je Kraftstoffart: ohne, mit und gesamt mit und
ohne Zusatzaggregate. Unbekannter Verbrauch zählt nicht als 0, sondern als Warnung.
"""
from __future__ import annotations

import bisect
import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from .db import Database

GROUP_WITHOUT = "Ohne_Zusatzaggregate"
GROUP_WITH = "Mit_Zusatzaggregaten"
GROUP_ALL = "Gesamt_mit_und_ohne_Zusatzaggregate"

HEADER = (
    "Berichtsebene;Counter;Berichtstyp;Von;Bis;Gruppierung;Kraftstoffart;Betriebstage;Verbraucht;Eintraege;"
    "Durchschnitt_l_pro_Betriebstag;Max_Tagesverbrauch;Erste_Seq;Letzte_Seq;Erster_Zaehlerstand;"
    "Letzter_Zaehlerstand;Quelle_Erste_Seq;Quelle_Letzte_Seq;Warnung"
)
REPORT_SUBDIR = "_Statistik"
REPORT_PREFIX = "FCG_Statistik"
POLICIES = ("skip_closed_overwrite_open", "overwrite", "versioned", "skip")
KINDS = ("Stichtagsmonat", "Kalendermonat", "Jahr")
EPSILON = 0.0000001

_ANNUAL = re.compile(r"^\s*(\d{1,2})\.(\d{1,2})\.?\s*$")


@dataclass(frozen=True)
class StatsSettings:
    calendar_month: bool = True
    cutoff_month: bool = True
    cutoff_day: int = 25
    annual: bool = False
    annual_day: int = 1
    annual_month: int = 1
    include_open: bool = True
    per_site: bool = True
    overall: bool = True
    policy: str = "skip_closed_overwrite_open"

    def enabled_kinds(self) -> list[str]:
        kinds = []
        if self.cutoff_month:
            kinds.append("Stichtagsmonat")
        if self.calendar_month:
            kinds.append("Kalendermonat")
        if self.annual:
            kinds.append("Jahr")
        return kinds


def parse_annual(text: str) -> tuple[int, int]:
    """'TT.MM' -> (Tag, Monat); Tag 1-28, damit jedes Jahr gültig bleibt."""
    match = _ANNUAL.match(text or "")
    if not match:
        raise ValueError(f"Jahresstichtag muss die Form TT.MM haben, z. B. 01.01. Eingabe: {text}")
    day, month = int(match.group(1)), int(match.group(2))
    if not (1 <= month <= 12 and 1 <= day <= 28):
        raise ValueError(f"Jahresstichtag: Tag 1-28, Monat 1-12. Eingabe: {text}")
    return day, month


def settings_from_values(values: dict[str, str]) -> StatsSettings:
    def flag(key: str, default: bool) -> bool:
        return str(values.get(key, "1" if default else "0")) == "1"

    try:
        cutoff = int(values.get("stats_cutoff_day", "25"))
    except ValueError:
        cutoff = 25
    if not 1 <= cutoff <= 28:
        cutoff = 25
    try:
        annual_day, annual_month = parse_annual(values.get("stats_annual_day_month", "01.01"))
    except ValueError:
        annual_day, annual_month = 1, 1
    policy = values.get("stats_policy", POLICIES[0])
    return StatsSettings(
        calendar_month=flag("stats_calendar_month", True),
        cutoff_month=flag("stats_cutoff_month", True),
        cutoff_day=cutoff,
        annual=flag("stats_annual", False),
        annual_day=annual_day,
        annual_month=annual_month,
        include_open=flag("stats_include_open", True),
        per_site=flag("stats_per_site", True),
        overall=flag("stats_overall", True),
        policy=policy if policy in POLICIES else POLICIES[0],
    )


@dataclass(frozen=True)
class StatRow:
    source: str          # stabiler CSV-Name der Messstelle (wie Quelle_* im PS-Bericht)
    day: date
    seq: int
    counter: float
    diff: float
    diff_known: bool
    fuel: str
    aggregate: bool


@dataclass(frozen=True)
class Period:
    kind: str
    type: str
    label: str
    start: date
    end: date            # inklusive
    closed: bool


@dataclass
class Group:
    name: str
    fuel: str
    first_seq: int
    last_seq: int
    first_counter: float
    last_counter: float
    first_source: str
    last_source: str
    liter: float = 0.0
    entries: int = 0
    unknown: int = 0
    day_liter: dict[str, float] = field(default_factory=dict)

    @property
    def days(self) -> int:
        return len(self.day_liter)

    @property
    def average(self) -> float:
        return self.liter / self.days if self.days else 0.0

    @property
    def max_day(self) -> float:
        return max([0.0, *self.day_liter.values()])

    @property
    def warning(self) -> str:
        if not self.unknown:
            return ""
        return f"Verbrauch unbekannt bei {self.unknown} Eintrag/Eintraegen (CSV-Feld 'Verbraucht' leer)"


def add_months(value: date, months: int) -> date:
    # Anker liegen immer auf Tag 1-28, daher ist jeder Zielmonat gültig.
    index = value.year * 12 + value.month - 1 + months
    return date(index // 12, index % 12 + 1, value.day)


def make_periods(min_date: date, max_date: date, first_anchor: date, step_months: int, kind: str,
                 label_prefix: str, include_open: bool, today: date) -> list[Period]:
    cursor = first_anchor
    while cursor > min_date:
        cursor = add_months(cursor, -step_months)
    periods = []
    while cursor <= max_date:
        nxt = add_months(cursor, step_months)
        end = nxt - timedelta(days=1)
        closed = nxt <= today
        if (closed or include_open) and end >= min_date:
            periods.append(Period(
                kind=kind,
                type=kind if closed else f"{kind}_offen",
                label=f"{label_prefix}_{cursor.isoformat()}_bis_{end.isoformat()}",
                start=cursor,
                end=end,
                closed=closed,
            ))
        cursor = nxt
    return periods


def statistics_periods(min_date: date, max_date: date, s: StatsSettings, today: date,
                       kinds: list[str] | None = None) -> list[Period]:
    kinds = s.enabled_kinds() if kinds is None else kinds
    periods: list[Period] = []
    # Reihenfolge wie im PS-Collector: Kalendermonat, Stichtagsmonat, Jahr.
    if "Kalendermonat" in kinds:
        periods += make_periods(min_date, max_date, date(min_date.year, min_date.month, 1), 1,
                                "Kalendermonat", "Kalendermonat", s.include_open, today)
    if "Stichtagsmonat" in kinds:
        periods += make_periods(min_date, max_date, date(min_date.year, min_date.month, s.cutoff_day), 1,
                                "Stichtagsmonat", "Stichtag", s.include_open, today)
    if "Jahr" in kinds:
        periods += make_periods(min_date, max_date, date(min_date.year, s.annual_month, s.annual_day), 12,
                                "Jahr", "Jahr", s.include_open, today)
    return periods


def measure(period: Period, rows: list[StatRow]) -> dict[str, Group]:
    groups: dict[str, Group] = {}
    for item in rows:
        if item.day < period.start or item.day > period.end:
            continue
        agg_group = GROUP_WITH if item.aggregate else GROUP_WITHOUT
        for name in (agg_group, GROUP_ALL):
            key = f"{name}|{item.fuel}"
            g = groups.get(key)
            if g is None:
                g = groups[key] = Group(
                    name=name, fuel=item.fuel, first_seq=item.seq, last_seq=item.seq,
                    first_counter=item.counter, last_counter=item.counter,
                    first_source=item.source, last_source=item.source,
                )
            g.entries += 1
            if item.seq > 0 and (g.first_seq == 0 or item.seq < g.first_seq):
                g.first_seq, g.first_source = item.seq, item.source
            if item.seq > g.last_seq:
                g.last_seq, g.last_source = item.seq, item.source
            g.last_counter = item.counter
            if not item.diff_known:
                g.unknown += 1
                continue
            if abs(item.diff) > EPSILON:
                day_key = item.day.isoformat()
                g.liter += item.diff
                g.day_liter[day_key] = g.day_liter.get(day_key, 0.0) + item.diff
    return dict(sorted(groups.items(), key=lambda kv: kv[0].lower()))


def decimal3(value: float) -> str:
    """Wie Format-FcgDecimal: drei Nachkommastellen, Komma, ohne Tausenderpunkt.

    .NET rundet ,5 von der Null weg; Pythons Formatierung würde zur geraden Ziffer runden.
    """
    text = str(Decimal(value).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP))
    return ("0.000" if text in ("-0.000",) else text).replace(".", ",")


def format_lines(period: Period, groups: dict[str, Group], scope: str, counter_name: str) -> list[str]:
    lines = [HEADER]
    for g in groups.values():
        lines.append(";".join(str(v) for v in (
            scope, counter_name, period.type, period.start.isoformat(), period.end.isoformat(),
            g.name, g.fuel, g.days, decimal3(g.liter), g.entries, decimal3(g.average), decimal3(g.max_day),
            g.first_seq, g.last_seq, decimal3(g.first_counter), decimal3(g.last_counter),
            g.first_source, g.last_source, g.warning,
        )))
    return lines


def fingerprint(lines: list[str]) -> str:
    """Nur die fachlichen Spalten (Gruppierung bis Letzter_Zaehlerstand) vergleichen."""
    result = []
    for line in lines[1:]:
        fields = line.split(";")
        result.append(";".join(fields[5:16]) if len(fields) >= 16 else line)
    return "\n".join(result)


def safe_file_name(name: str) -> str:
    """Wie ConvertTo-SafeFileName (Windows-verbotene Zeichen und Leerraum -> _)."""
    if not name or not name.strip():
        return "FCG_Unbenannt"
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name.strip())
    safe = re.sub(r"\s+", "_", safe)
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or "FCG_Unbenannt"


@dataclass(frozen=True)
class Report:
    path: str            # relativ zum Exportordner, mit /
    period: Period
    lines: list[str]


def build_reports(rows_by_source: dict[str, list[StatRow]], display_names: dict[str, str],
                  s: StatsSettings, today: date) -> list[Report]:
    """Alle Berichtsdateien wie der PS-Collector sie unter _Statistik/ ablegt."""
    all_rows = [row for source in sorted(rows_by_source) for row in rows_by_source[source]]
    if not all_rows:
        return []
    days = [row.day for row in all_rows]
    periods = statistics_periods(min(days), max(days), s, today)
    reports: list[Report] = []
    if s.per_site:
        for source in sorted(rows_by_source):
            rows = rows_by_source[source]
            if not rows:
                continue
            name = display_names.get(source) or source
            base = f"{REPORT_SUBDIR}/Counter/{safe_file_name(source)}"
            for p in periods:
                lines = format_lines(p, measure(p, rows), "Counter", name)
                reports.append(Report(
                    f"{base}/{safe_file_name(p.kind)}/{REPORT_PREFIX}_{safe_file_name(source)}_{p.label}.csv", p, lines))
    if s.overall:
        for p in periods:
            lines = format_lines(p, measure(p, all_rows), "Gesamt", "Alle_Counter")
            reports.append(Report(
                f"{REPORT_SUBDIR}/Gesamt/{safe_file_name(p.kind)}/{REPORT_PREFIX}_Alle_Counter_{p.label}.csv", p, lines))
    return reports


# --- Daten aus der Datenbank ----------------------------------------------


def load_rows(db: Database, site_id: str | None = None) -> tuple[dict[str, list[StatRow]], dict[str, str], int]:
    """Liefert (Zeilen je Quelle, Anzeigename je Quelle, Einträge ohne lesbares Datum)."""
    sql = (
        "SELECT s.csv_stem, s.counter_name, e.seq, e.entry_date, e.total_quantity, e.consumed_quantity, "
        "e.fuel_type, e.additional_aggregate FROM entries e JOIN sites s ON s.site_id = e.site_id"
    )
    params: tuple = ()
    if site_id is not None:
        sql += " WHERE e.site_id = ?"
        params = (site_id,)
    sql += " ORDER BY s.csv_stem, e.seq"
    rows_by_source: dict[str, list[StatRow]] = {}
    names: dict[str, str] = {}
    undated = 0
    with db.connect() as conn:
        for r in conn.execute(sql, params):
            source = r["csv_stem"] or "FCG_Unbenannt"
            if r["counter_name"]:
                names[source] = r["counter_name"]
            rows_by_source.setdefault(source, [])
            try:
                day = date.fromisoformat(r["entry_date"]) if r["entry_date"] else None
            except ValueError:
                day = None
            if day is None:
                undated += 1
                continue
            known = r["consumed_quantity"] is not None
            fuel = r["fuel_type"] if (r["fuel_type"] or "").strip() else "Unbekannt"
            rows_by_source[source].append(StatRow(
                source=source, day=day, seq=int(r["seq"]), counter=float(r["total_quantity"]),
                diff=float(r["consumed_quantity"]) if known else 0.0, diff_known=known,
                fuel=fuel, aggregate=bool(r["additional_aggregate"]),
            ))
    return rows_by_source, names, undated


# --- Freie Auswertung: eigener Zeitraum, Vergleich, Verlauf, Auffälligkeiten ---

COMPARE_MODES = {"vorjahr": "Gleicher Zeitraum im Vorjahr", "vorzeitraum": "Zeitraum direkt davor (gleich lang)",
                 "eigener": "Eigener Vergleichszeitraum", "keiner": "Kein Vergleich"}
GRANULARITIES = {"auto": "automatisch", "tag": "Tage", "woche": "Wochen", "monat": "Monate"}
ANOMALY_FACTORS = (2, 3, 5)
ANOMALY_REFERENCE_DAYS = 90
ANOMALY_MIN_DAYS = 7
MAX_RANGE_DAYS = 3660

COMPARE_HEADER = (
    "Berichtsebene;Counter;Gruppierung;Kraftstoffart;Von;Bis;Verbraucht;Betriebstage;Eintraege;"
    "Vergleich_Von;Vergleich_Bis;Vergleich_Verbraucht;Vergleich_Betriebstage;Vergleich_Eintraege;"
    "Differenz;Differenz_Prozent"
)
TREND_HEADER = (
    "Abschnitt;Von;Bis;Verbraucht;Eintraege;Unbekannt;Auffaellige_Tage;"
    "Vergleich_Von;Vergleich_Bis;Vergleich_Verbraucht;Differenz;Differenz_Prozent"
)
ANOMALY_HEADER = "Tag;Counter;Verbraucht;Median_Betriebstag;Faktor"


def custom_period(start: date, end: date, today: date) -> Period:
    closed = end < today
    return Period(kind="Zeitraum", type="Zeitraum" if closed else "Zeitraum_offen",
                  label=f"Zeitraum_{start.isoformat()}_bis_{end.isoformat()}", start=start, end=end, closed=closed)


def shift_years(value: date, years: int) -> date:
    try:
        return value.replace(year=value.year + years)
    except ValueError:  # 29.02. -> 28.02.
        return value.replace(year=value.year + years, day=28)


def compare_range(mode: str, start: date, end: date) -> tuple[date, date] | None:
    if mode == "vorjahr":
        return shift_years(start, -1), shift_years(end, -1)
    if mode == "vorzeitraum":
        length = (end - start).days + 1
        return start - timedelta(days=length), start - timedelta(days=1)
    return None


def auto_granularity(start: date, end: date) -> str:
    days = (end - start).days + 1
    if days <= 92:
        return "tag"
    if days <= 400:
        return "woche"
    return "monat"


@dataclass
class Bucket:
    start: date
    end: date
    liter: float = 0.0
    entries: int = 0
    unknown: int = 0
    anomalies: int = 0

    def label(self, granularity: str) -> str:
        if granularity == "monat":
            return self.start.strftime("%m.%Y")
        if granularity == "woche":
            year, week, _ = self.start.isocalendar()
            return f"KW {week:02d}/{year}"
        return self.start.strftime("%d.%m.%Y")


def make_buckets(start: date, end: date, granularity: str) -> list[Bucket]:
    """Abschnitte von start bis end (inklusive); Wochen ab Montag, Monate ab dem 1., am Rand gekürzt."""
    result = []
    cursor = start
    while cursor <= end:
        if granularity == "monat":
            nxt = add_months(date(cursor.year, cursor.month, 1), 1)
        elif granularity == "woche":
            nxt = cursor + timedelta(days=7 - cursor.weekday())
        else:
            nxt = cursor + timedelta(days=1)
        result.append(Bucket(cursor, min(end, nxt - timedelta(days=1))))
        cursor = nxt
    return result


def fill_buckets(buckets: list[Bucket], rows: list[StatRow], anomaly_days: set[date] | None = None) -> list[Bucket]:
    if not buckets:
        return buckets
    starts = [b.start for b in buckets]
    for item in rows:
        if item.day < buckets[0].start or item.day > buckets[-1].end:
            continue
        bucket = buckets[bisect.bisect_right(starts, item.day) - 1]
        bucket.entries += 1
        if item.diff_known:
            bucket.liter += item.diff
        else:
            bucket.unknown += 1
    for day in anomaly_days or ():
        if buckets[0].start <= day <= buckets[-1].end:
            buckets[bisect.bisect_right(starts, day) - 1].anomalies += 1
    return buckets


def percent_change(current: float, previous: float) -> float | None:
    if abs(previous) <= EPSILON:
        return None
    return (current - previous) / previous * 100.0


@dataclass(frozen=True)
class GroupCompare:
    name: str
    fuel: str
    current: Group | None
    previous: Group | None

    @property
    def liter(self) -> float:
        return self.current.liter if self.current else 0.0

    @property
    def previous_liter(self) -> float:
        return self.previous.liter if self.previous else 0.0

    @property
    def diff(self) -> float:
        return self.liter - self.previous_liter

    @property
    def percent(self) -> float | None:
        return percent_change(self.liter, self.previous_liter)


def compare_groups(current: dict[str, Group], previous: dict[str, Group]) -> list[GroupCompare]:
    keys = sorted(set(current) | set(previous), key=str.lower)
    result = []
    for key in keys:
        cur, prev = current.get(key), previous.get(key)
        ref = cur or prev
        result.append(GroupCompare(ref.name, ref.fuel, cur, prev))
    return result


@dataclass(frozen=True)
class Anomaly:
    source: str
    day: date
    liter: float
    median: float

    @property
    def factor(self) -> float:
        return self.liter / self.median if self.median > EPSILON else 0.0


def _median(values: list[float]) -> float:
    ordered = sorted(values)
    mid = len(ordered) // 2
    return ordered[mid] if len(ordered) % 2 else (ordered[mid - 1] + ordered[mid]) / 2


def find_anomalies(rows: list[StatRow], start: date, end: date, factor: float) -> list[Anomaly]:
    """Tage, an denen eine Messstelle mehr als factor-mal so viel verbraucht hat wie an einem typischen Betriebstag.

    Typisch ist der Median der Betriebstage im Zeitraum und in den 90 Tagen davor, je Messstelle.
    Mit weniger als 7 Betriebstagen gibt es keinen belastbaren Vergleich, dann wird nichts markiert.
    """
    reference_start = start - timedelta(days=ANOMALY_REFERENCE_DAYS)
    per_source: dict[str, dict[date, float]] = {}
    for item in rows:
        if item.diff_known and reference_start <= item.day <= end:
            days = per_source.setdefault(item.source, {})
            days[item.day] = days.get(item.day, 0.0) + item.diff
    result = []
    for source, days in per_source.items():
        values = [v for v in days.values() if v > EPSILON]
        if len(values) < ANOMALY_MIN_DAYS:
            continue
        median = _median(values)
        for day, liter in days.items():
            if start <= day <= end and liter > factor * median + EPSILON:
                result.append(Anomaly(source, day, liter, median))
    return sorted(result, key=lambda a: (a.day, a.source))


def _percent_text(value: float | None) -> str:
    return "" if value is None else decimal3(value)


def compare_lines(period: Period, previous: Period, compares: list[GroupCompare], scope: str, counter_name: str) -> list[str]:
    lines = [COMPARE_HEADER]
    for c in compares:
        cur, prev = c.current, c.previous
        lines.append(";".join(str(v) for v in (
            scope, counter_name, c.name, c.fuel, period.start.isoformat(), period.end.isoformat(),
            decimal3(c.liter), cur.days if cur else 0, cur.entries if cur else 0,
            previous.start.isoformat(), previous.end.isoformat(),
            decimal3(c.previous_liter), prev.days if prev else 0, prev.entries if prev else 0,
            decimal3(c.diff), _percent_text(c.percent),
        )))
    return lines


def trend_lines(buckets: list[Bucket], previous: list[Bucket] | None, granularity: str) -> list[str]:
    lines = [TREND_HEADER]
    for index, b in enumerate(buckets):
        p = previous[index] if previous and index < len(previous) else None
        lines.append(";".join(str(v) for v in (
            b.label(granularity), b.start.isoformat(), b.end.isoformat(), decimal3(b.liter), b.entries, b.unknown,
            b.anomalies,
            p.start.isoformat() if p else "", p.end.isoformat() if p else "", decimal3(p.liter) if p else "",
            decimal3(b.liter - p.liter) if p else "", _percent_text(percent_change(b.liter, p.liter)) if p else "",
        )))
    return lines


def anomaly_lines(anomalies: list[Anomaly], names: dict[str, str]) -> list[str]:
    lines = [ANOMALY_HEADER]
    for a in anomalies:
        lines.append(";".join((a.day.isoformat(), names.get(a.source) or a.source, decimal3(a.liter),
                               decimal3(a.median), decimal3(a.factor))))
    return lines
