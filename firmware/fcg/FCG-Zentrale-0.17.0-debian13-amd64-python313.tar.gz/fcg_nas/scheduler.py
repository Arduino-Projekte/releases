"""Zeitgesteuerte Abholung und Wartung im Hintergrund."""
from __future__ import annotations

import logging
import threading
import time

from .collector import Collector
from .db import Database
from .ota import OtaError

log = logging.getLogger("fcg_nas.scheduler")

TICK_SECONDS = 5
FIRST_RUN_DELAY_SECONDS = 10


class Scheduler:
    def __init__(self, db: Database, collector: Collector) -> None:
        self.db = db
        self.collector = collector
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop, name="fcg-scheduler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=TICK_SECONDS * 2)

    def _loop(self) -> None:
        next_due = time.time() + FIRST_RUN_DELAY_SECONDS
        self.collector.set_next_due(next_due)
        while not self._stop.wait(TICK_SECONDS):
            if time.time() < next_due:
                continue
            try:
                if self.collector.run_now("auto", None) is None:
                    log.info("Geplanter Lauf übersprungen, es läuft bereits einer.")
            except Exception:
                log.exception("Geplanter Lauf fehlgeschlagen")
            interval = max(1, self.db.get_int_setting("poll_interval_min")) * 60
            next_due = time.time() + interval
            self.collector.set_next_due(next_due)


class Housekeeper:
    """Wartung im Minutentakt: nächtliche Sicherung, OTA-Prüfung, Warnungen."""

    TICK_SECONDS = 60

    def __init__(self, backups, ota, alerts, extra: list | None = None) -> None:
        self.backups = backups
        self.ota = ota
        self.alerts = alerts
        self.extra = list(extra or [])
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop, name="fcg-housekeeping", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def tick(self) -> None:
        # Jeder Teil für sich: ein Fehler in einem hält die anderen nicht auf.
        steps = [("Sicherung", self._backup), ("OTA-Spiegel", self._ota), ("Warnungen", self.alerts.evaluate), *self.extra]
        for name, step in steps:
            try:
                step()
            except Exception:
                log.exception("%s fehlgeschlagen", name)

    def _backup(self) -> None:
        if self.backups.due():
            self.backups.run_nightly()

    def _ota(self) -> None:
        if self.ota.due():
            try:
                self.ota.check()
            except OtaError as exc:
                log.warning("OTA-Prüfung: %s", exc)

    def _loop(self) -> None:
        if self._stop.wait(FIRST_RUN_DELAY_SECONDS):
            return
        while True:
            self.tick()
            if self._stop.wait(self.TICK_SECONDS):
                return
