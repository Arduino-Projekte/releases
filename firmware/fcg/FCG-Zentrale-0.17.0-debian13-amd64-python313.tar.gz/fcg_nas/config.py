"""Startkonfiguration aus Umgebungsvariablen.

Alles, was sich im Betrieb ändern darf (Abrufintervall, limit, Timeout),
liegt in der Datenbank und wird in der Verwaltung gepflegt.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AppConfig:
    data_dir: Path
    initial_admin_password: str
    start_scheduler: bool
    # Freigabeordner für den automatischen CSV- und Statistikexport.
    export_dir: Path = Path("/export")
    # Sicherungen (enthalten secret.key, daher nicht im Exportordner).
    backup_dir: Path | None = None
    # Webordner der NAS, aus dem die Gateways ihr OTA-Update laden (web/fcg_update).
    ota_dir: Path = Path("/ota")
    # Deployment stays outside portable backups.
    deployment: str = "docker"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "fcg_collector.sqlite3"

    @property
    def secret_key_path(self) -> Path:
        return self.data_dir / "secret.key"

    @property
    def log_dir(self) -> Path:
        return self.data_dir / "logs"

    @property
    def import_dir(self) -> Path:
        return self.data_dir / "import"

    @property
    def backups_dir(self) -> Path:
        return self.backup_dir or self.data_dir / "backups"

    @property
    def ota_cache_dir(self) -> Path:
        return self.data_dir / "ota"


def load_config() -> AppConfig:
    return AppConfig(
        data_dir=Path(os.environ.get("FCG_DATA_DIR", "/data")),
        initial_admin_password=os.environ.get("FCG_ADMIN_PASSWORD", ""),
        start_scheduler=os.environ.get("FCG_SCHEDULER", "1") != "0",
        export_dir=Path(os.environ.get("FCG_EXPORT_DIR", "/export")),
        backup_dir=Path(os.environ["FCG_BACKUP_DIR"]) if os.environ.get("FCG_BACKUP_DIR") else None,
        ota_dir=Path(os.environ.get("FCG_OTA_DIR", "/ota")),
        deployment=os.environ.get("FCG_DEPLOYMENT", "docker"),
    )
