"""Opt-in read-only guest access, limited to explicit networks and routes."""
import ipaddress

GUEST_PATHS = {"/dashboard", "/stats", "/stats/csv", "/analysis", "/analysis/csv", "/counter-history"}


GUEST_AREAS = ('dashboard', 'stats', 'analysis')


def permissions(values):
    return {area: values.get('guest_allow_' + area, '1') == '1' for area in GUEST_AREAS}


def entry_path(values):
    allowed = permissions(values)
    return next(('/' + area for area in GUEST_AREAS if allowed[area]), '/login')


def path_allowed(path, values):
    allowed = permissions(values)
    if path == '/counter-history':
        return allowed['stats'] or allowed['analysis']
    area = path.strip('/').split('/')[0]
    return path in GUEST_PATHS and allowed.get(area, False)


def networks(text):
    lines = text.replace(",", " ").split()
    if len(lines) > 32:
        raise ValueError("Höchstens 32 Netze eintragen.")
    return [ipaddress.ip_network(value, strict=False) for value in lines]


def address(value):
    result = ipaddress.ip_address(value)
    return result.ipv4_mapped if isinstance(result, ipaddress.IPv6Address) and result.ipv4_mapped else result


def guest_allowed(request, values):
    if values.get("guest_enabled") != "1" or not any(permissions(values).values()) or not request.client:
        return False
    try:
        allowed = networks(values.get("guest_networks", ""))
        trusted = networks(values.get("guest_proxy_networks", ""))
        peer = address(request.client.host)
        forwarded = request.headers.get("x-forwarded-for", "")
        has_forwarding = any(request.headers.get(h) for h in ("x-forwarded-for", "x-real-ip", "forwarded"))
        peer_trusted = any(peer in net for net in trusted)
        if has_forwarding:
            # Never grant access on a proxy's address while ignoring its real client.
            if not peer_trusted or not forwarded:
                return False
            chain = [address(v.strip()) for v in forwarded.split(",")]
            if len(chain) > 16:
                return False
            chain.append(peer)
            while len(chain) > 1 and any(chain[-1] in net for net in trusted):
                chain.pop()
            peer = chain[-1]
        elif peer_trusted:
            return False
        return any(peer in net for net in allowed)
    except (ValueError, TypeError):
        return False
