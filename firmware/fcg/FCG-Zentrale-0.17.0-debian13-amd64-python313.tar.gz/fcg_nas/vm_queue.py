"""The unprivileged UI can enqueue an update, never execute root commands."""
import hashlib
import shutil
import fcntl
import json
import os
from pathlib import Path
import tempfile

ROOT = Path('/var/lib/fcg-update')
MESSAGES = {'queued': 'Update wartet auf Verarbeitung', 'preparing': 'Update wird vorbereitet',
            'installed': 'Update installiert',
            'rolled_back': 'Update fehlgeschlagen; vorherige Anwendung und Daten wiederhergestellt',
            'failed': 'Update fehlgeschlagen; Systemprotokoll prüfen'}


def enqueue(version, source, root=ROOT):
    _enqueue({'version': version, 'source': source}, root)

def enqueue_runtime(root=ROOT):
    _enqueue({'runtime_sync':True},root)

def _enqueue(value, root):
    request = root / 'inbox/request.json'
    with (root / 'inbox/queue.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if os.path.lexists(request):
            raise FileExistsError('Update is already queued.')
        fd, name = tempfile.mkstemp(prefix='.request-', dir=request.parent)
        try:
            with os.fdopen(fd, 'w') as handle:
                json.dump(value, handle)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, request)
        finally:
            Path(name).unlink(missing_ok=True)



def enqueue_offline(manifest, manifest_path, package_path, root=ROOT):
    package_id = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    packages = root/'inbox/packages'
    packages.mkdir(mode=0o700,exist_ok=True)
    folder = packages/package_id
    if not folder.exists():
        with tempfile.TemporaryDirectory(prefix='.copy-',dir=packages) as temporary:
            ready = Path(temporary)/'ready';ready.mkdir()
            shutil.copyfile(manifest_path,ready/'manifest.json')
            shutil.copyfile(package_path,ready/manifest['file'])
            os.replace(ready,folder)
    _enqueue({'version':manifest['version'],'offline':package_id},root)


def status(root=ROOT):
    try:
        queued = root / 'inbox/request.json'
        if queued.is_file():
            return {'state': 'queued', 'version': str(json.loads(queued.read_text()).get('version', ''))[:32], 'at': '', 'message': MESSAGES['queued']}
        data = json.loads((root / 'status.json').read_text())
        if not isinstance(data, dict):
            return {}
        result = {k: str(data.get(k, ''))[:300] for k in ('state', 'version', 'at')}
        result['message'] = MESSAGES.get(result['state'], 'Unbekannter Updatestatus')
        return result
    except (OSError, ValueError):
        return {}
