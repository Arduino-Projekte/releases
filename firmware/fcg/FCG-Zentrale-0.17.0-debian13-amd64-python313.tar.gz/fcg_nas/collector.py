"""Abholdienst: holt neue Einträge aller Gateways ab.

Übernimmt die Sicherheitsregeln des PowerShell-Collectors:
- Zuordnung über die site_id des Gateways, nicht über die IP.
- Cursor = höchste gespeicherte Seq der Messstelle, keine Duplikate.
- Ein fehlerhafter Eintrag stoppt dieses Gateway; er wird beim nächsten
  Lauf erneut versucht, höhere Seqs werden nicht still übersprungen.
- Verbrauch kommt vom Gateway (consumed_quantity). Ohne diesen Wert gilt
  die Differenz zum Vorgänger; beim Erstimport ist der Verbrauch unbekannt.
- Zeitüberschreitung halbiert limit und versucht es erneut.
Nach den Einträgen holt der Lauf das Ereignislog des Gateways (gatewaylogs).
Ein Fehler dabei zählt nicht als Fehler des Gateways.
"""
from __future__ import annotations

import json
import logging
import math
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable

from . import gatewaylogs
from .db import Database, now_text
from .exporter import ensure_stem
from .gateway_client import (FetchFn, GatewayAuth, GatewayError, GatewayTimeout, GatewayUnreachable, JsonFn,
                             fetch_collector_page, http_get_json)
from .secrets_store import SecretStore

log = logging.getLogger("fcg_nas.collector")

TIMESTAMP_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})")
TIMESTAMP_DE = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4})[ T](\d{2}):(\d{2}):(\d{2})")
MAX_SITE_ID_LENGTH = 128


class EntryError(ValueError):
    pass


@dataclass
class ParsedEntry:
    seq: int
    ts: str
    entry_date: str | None
    total_quantity: float
    consumed_quantity: float | None
    consumption_source: str
    fuel_type: str
    additional_aggregate: bool


@dataclass
class GatewayResult:
    gateway_id: int | None
    host: str
    ok: bool = False
    added: int = 0
    message: str = ""


@dataclass
class RunState:
    """Momentaufnahme für die Laufanzeige."""

    running: bool = False
    run_id: int | None = None
    trigger: str = ""
    started_by: str | None = None
    started_at: str | None = None
    gateways_total: int = 0
    gateways_done: int = 0
    current_host: str | None = None
    added: int = 0
    last_finished_at: str | None = None
    last_status: str | None = None
    next_due_at: float | None = None
    results: list[dict] = field(default_factory=list)


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        result = float(value)
    else:
        text = str(value).strip()
        if not text:
            return None
        try:
            result = float(text)
        except ValueError:
            try:
                result = float(text.replace(".", "").replace(",", "."))
            except ValueError:
                return None
    if math.isnan(result) or math.isinf(result):
        return None
    return result


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "ja", "on", "aktiv", "active"}


def split_timestamp(raw: Any) -> tuple[str, str | None]:
    """Normalisiert auf 'YYYY-MM-DD HH:MM:SS'; liefert (ts, datum oder None)."""
    text = "" if raw is None else str(raw).strip()
    match = TIMESTAMP_ISO.match(text)
    if match:
        y, mo, d, h, mi, s = match.groups()
        return f"{y}-{mo}-{d} {h}:{mi}:{s}", f"{y}-{mo}-{d}"
    match = TIMESTAMP_DE.match(text)
    if match:
        d, mo, y, h, mi, s = match.groups()
        return f"{y}-{mo}-{d} {h}:{mi}:{s}", f"{y}-{mo}-{d}"
    return text, None


def parse_entry(entry: Any, previous_total: float | None) -> ParsedEntry:
    if not isinstance(entry, dict):
        raise EntryError("Eintrag ist kein JSON-Objekt.")
    seq_raw = entry.get("seq")
    if isinstance(seq_raw, bool) or seq_raw is None:
        raise EntryError("Eintrag ohne gültige Seq.")
    try:
        seq = int(str(seq_raw).strip())
    except ValueError as exc:
        raise EntryError("Eintrag ohne gültige Seq.") from exc
    if seq < 1:
        raise EntryError(f"Seq {seq} ist ungültig.")

    total = _number(entry.get("total_quantity"))
    if total is None:
        raise EntryError(f"Eintrag Seq {seq} ohne gültigen Zählerstand.")

    consumed_raw = entry.get("consumed_quantity")
    if consumed_raw is not None and str(consumed_raw).strip() != "":
        consumed = _number(consumed_raw)
        if consumed is None or consumed < 0:
            raise EntryError(f"Eintrag Seq {seq} enthält ungültigen Verbrauch.")
        source = "api"
    elif previous_total is not None and total >= previous_total:
        consumed = total - previous_total
        source = "legacy_delta"
    elif previous_total is not None:
        consumed = None
        source = "legacy_reset_unknown"
    else:
        # Ein unbekannter Vorgängerstand ist nicht 0: Beim Erstimport darf der
        # Gesamtzaehler nie als Verbrauch erscheinen.
        consumed = None
        source = "first_unknown"

    ts, entry_date = split_timestamp(entry.get("timestamp"))
    fuel = entry.get("fuel_type")
    return ParsedEntry(
        seq=seq,
        ts=ts,
        entry_date=entry_date,
        total_quantity=total,
        consumed_quantity=consumed,
        consumption_source=source,
        fuel_type="" if fuel is None else str(fuel),
        additional_aggregate=_truthy(entry.get("additional_aggregate")),
    )


def site_key_from_response(response: dict, host: str) -> str:
    device = response.get("device") if isinstance(response.get("device"), dict) else {}
    site_id = str(device.get("site_id") or response.get("site_id") or "").strip()
    if len(site_id) > MAX_SITE_ID_LENGTH:
        raise GatewayError("site_id ist unplausibel lang (>128 Zeichen).")
    # Ältere Firmware ohne site_id: Zuordnung über die Adresse.
    return site_id or f"host:{host}"


class Collector:
    def __init__(self, db: Database, secrets: SecretStore, fetch: FetchFn = fetch_collector_page,
                 get_json: JsonFn = http_get_json) -> None:
        self.db = db
        self.secrets = secrets
        self.fetch = fetch
        self.get_json = get_json
        self._run_lock = threading.Lock()
        self._state_lock = threading.Lock()
        self._state = RunState()
        # Wird nach jedem Lauf mit der Zahl neuer Einträge aufgerufen (z. B. Export).
        self.after_run: list[Callable[[int], None]] = []

    # --- Laufanzeige ---------------------------------------------------

    def state(self) -> RunState:
        with self._state_lock:
            snapshot = RunState(**{k: v for k, v in self._state.__dict__.items() if k != "results"})
            snapshot.results = list(self._state.results)
            return snapshot

    def _update_state(self, **changes: Any) -> None:
        with self._state_lock:
            for key, value in changes.items():
                setattr(self._state, key, value)

    def set_next_due(self, epoch: float | None) -> None:
        self._update_state(next_due_at=epoch)

    # --- Läufe ----------------------------------------------------------

    def is_running(self) -> bool:
        return self._run_lock.locked()

    def start_run_async(self, trigger: str, started_by: str | None) -> bool:
        """Startet einen Lauf im Hintergrund; False, wenn schon einer läuft."""
        if not self._run_lock.acquire(blocking=False):
            return False
        thread = threading.Thread(
            target=self._run_locked, args=(trigger, started_by), name="fcg-run", daemon=True
        )
        thread.start()
        return True

    @contextmanager
    def paused(self, timeout: float = 120):
        """Keine Abholung, solange der Block läuft (z. B. Rücksicherung)."""
        if not self._run_lock.acquire(timeout=timeout):
            raise RuntimeError("Es läuft gerade eine Abholung. Bitte gleich noch einmal versuchen.")
        try:
            yield
        finally:
            self._run_lock.release()

    def run_now(self, trigger: str, started_by: str | None) -> int | None:
        """Führt einen Lauf synchron aus; None, wenn schon einer läuft."""
        if not self._run_lock.acquire(blocking=False):
            return None
        return self._run_locked(trigger, started_by)

    def _run_locked(self, trigger: str, started_by: str | None) -> int:
        try:
            run_id = self._run(trigger, started_by)
            added = self._state.added if run_id else 0
            for hook in self.after_run:
                try:
                    hook(added)
                except Exception:
                    log.exception("Fehler nach Lauf %s", run_id)
            return run_id
        finally:
            self._run_lock.release()

    def _run(self, trigger: str, started_by: str | None) -> int:
        with self.db.connect() as conn:
            gateways = conn.execute("SELECT * FROM gateways WHERE enabled = 1 ORDER BY id").fetchall()
        if not gateways:
            # Ohne aktive Gateways kein Eintrag in der Lauf-Historie.
            self._update_state(last_finished_at=now_text(), last_status="ok")
            return 0
        with self.db.connect() as conn:
            started_at = now_text()
            run_id = conn.execute(
                "INSERT INTO runs(trigger, started_by, started_at, status, gateways_total) VALUES(?, ?, ?, 'running', ?)",
                (trigger, started_by, started_at, len(gateways)),
            ).lastrowid
        self._update_state(
            running=True, run_id=run_id, trigger=trigger, started_by=started_by, started_at=started_at,
            gateways_total=len(gateways), gateways_done=0, current_host=None, added=0, results=[],
        )
        log.info("Lauf %s gestartet (%s), %s Gateways", run_id, trigger, len(gateways))

        ok_count = failed_count = added_total = 0
        status = "ok"
        try:
            for index, gateway in enumerate(gateways):
                self._update_state(current_host=gateway["host"])
                result = self.collect_gateway(gateway)
                ok_count += 1 if result.ok else 0
                failed_count += 0 if result.ok else 1
                added_total += result.added
                with self.db.connect() as conn:
                    conn.execute(
                        "INSERT INTO run_results(run_id, gateway_id, host, ok, added, message) VALUES(?, ?, ?, ?, ?, ?)",
                        (run_id, result.gateway_id, result.host, int(result.ok), result.added, result.message),
                    )
                with self._state_lock:
                    self._state.gateways_done = index + 1
                    self._state.added = added_total
                    self._state.results.append(result.__dict__.copy())
            if failed_count:
                status = "partial" if ok_count else "failed"
            removed = gatewaylogs.prune(self.db, self.db.get_int_setting("log_retention_days"))
            if removed:
                log.info("%s alte Gateway-Logeinträge gelöscht", removed)
        except Exception:
            status = "failed"
            log.exception("Lauf %s abgebrochen", run_id)
            raise
        finally:
            finished_at = now_text()
            with self.db.connect() as conn:
                conn.execute(
                    "UPDATE runs SET finished_at = ?, status = ?, gateways_ok = ?, gateways_failed = ?, added = ? WHERE id = ?",
                    (finished_at, status, ok_count, failed_count, added_total, run_id),
                )
            self._update_state(
                running=False, current_host=None, last_finished_at=finished_at, last_status=status
            )
            log.info("Lauf %s beendet: %s, ok=%s, Fehler=%s, neu=%s", run_id, status, ok_count, failed_count, added_total)
        return run_id

    # --- ein Gateway ---------------------------------------------------

    def auth_for(self, gateway: sqlite3.Row) -> GatewayAuth:
        return GatewayAuth(gateway["username"] or "", self.secrets.decrypt(gateway["password_enc"] or ""))

    def _fetch_page(self, host: str, after_seq: int, limit: int, auth: GatewayAuth, timeout: float) -> tuple[dict, int]:
        """Liefert (Antwort, verwendetes limit). Ein verkleinertes limit gilt für den Rest des Gateways."""
        current = limit
        while True:
            try:
                return self.fetch(host, after_seq, current, auth, timeout), current
            except GatewayTimeout:
                if current <= 1:
                    raise
                current = max(1, current // 2)
                log.warning("Timeout bei %s after_seq=%s, neuer Versuch mit limit=%s", host, after_seq, current)

    def collect_gateway(self, gateway: sqlite3.Row) -> GatewayResult:
        host = gateway["host"]
        result = GatewayResult(gateway_id=gateway["id"], host=host)
        settings = self.db.get_settings()
        limit = int(settings["limit"])
        timeout = float(settings["timeout_sec"])
        max_pages = int(settings["max_pages_per_gateway"])
        attempt_at = now_text()
        reachable = True
        try:
            auth = self.auth_for(gateway)
            probe, _ = self._fetch_page(host, 0, 1, auth, timeout)
            site_key = site_key_from_response(probe, host)
            self._remember_device(gateway["id"], site_key, probe)
            result.added, blocked = self._collect_site(host, site_key, auth, limit, timeout, max_pages)
            if blocked:
                result.message = blocked
            else:
                result.ok = True
                result.message = f"{result.added} neue Einträge" if result.added else "keine neuen Einträge"
        except GatewayUnreachable as exc:
            result.message = str(exc)
            reachable = False
        except (GatewayError, ValueError) as exc:
            result.message = str(exc)
        except Exception as exc:  # unerwartet: Lauf geht mit dem nächsten Gateway weiter
            log.exception("Unerwarteter Fehler bei %s", host)
            result.message = f"Unerwarteter Fehler: {exc}"
        if reachable:
            # Auch bei abgelehntem Collector-Login: /api/log ist ohne Login lesbar.
            self._collect_logs(gateway, result)

        with self.db.connect() as conn:
            if result.ok:
                conn.execute(
                    "UPDATE gateways SET last_attempt_at = ?, last_ok_at = ?, last_error = NULL, last_added = ? WHERE id = ?",
                    (attempt_at, now_text(), result.added, gateway["id"]),
                )
            else:
                conn.execute(
                    "UPDATE gateways SET last_attempt_at = ?, last_error = ?, last_added = ? WHERE id = ?",
                    (attempt_at, result.message, result.added, gateway["id"]),
                )
        level = logging.INFO if result.ok else logging.WARNING
        log.log(level, "Gateway %s: %s", host, result.message)
        return result

    def _collect_logs(self, gateway: sqlite3.Row, result: GatewayResult) -> None:
        try:
            added, error = gatewaylogs.collect_logs(self.db, gateway, self.get_json)
        except Exception:
            log.exception("Ereignislog von %s nicht gespeichert", gateway["host"])
            return
        if error:
            log.warning("Gateway %s: Ereignislog nicht abrufbar: %s", gateway["host"], error)
            result.message += "; Ereignislog nicht abrufbar"
        elif added:
            result.message += f", {added} neue Logeinträge"

    def _remember_device(self, gateway_id: int, site_key: str, response: dict) -> None:
        device = response.get("device") if isinstance(response.get("device"), dict) else {}
        values = {
            "counter_name": str(device.get("counter_name") or ""),
            "device_label": str(device.get("device_label") or ""),
            "location": str(device.get("location") or ""),
            "unit": str(device.get("unit") or "l"),
        }
        # Ab Firmware V0.21.46: Speicherzustand (Zählerstand, NVS) für die Warnungen.
        health = response.get("health")
        health_json = json.dumps(health, ensure_ascii=False)[:20000] if isinstance(health, dict) else None
        seen = now_text()
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE gateways SET site_id = ?, counter_name = ?, device_label = ?, location = ?, unit = ?, "
                "fw_version = ?, demo_mode = ?, health_json = ? WHERE id = ?",
                (site_key, values["counter_name"], values["device_label"], values["location"], values["unit"],
                 str(device.get("fw_version") or ""), int(_truthy(device.get("demo_mode"))), health_json, gateway_id),
            )
            conn.execute(
                "INSERT INTO sites(site_id, counter_name, device_label, location, unit, gateway_id, first_seen, last_seen) "
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(site_id) DO UPDATE SET counter_name = excluded.counter_name, "
                "device_label = excluded.device_label, location = excluded.location, unit = excluded.unit, "
                "gateway_id = excluded.gateway_id, last_seen = excluded.last_seen",
                (site_key, values["counter_name"], values["device_label"], values["location"], values["unit"],
                 gateway_id, seen, seen),
            )
            ensure_stem(conn, site_key)

    def _cursor(self, site_key: str) -> tuple[int, float | None]:
        with self.db.connect() as conn:
            row = conn.execute(
                "SELECT seq, total_quantity FROM entries WHERE site_id = ? ORDER BY seq DESC LIMIT 1", (site_key,)
            ).fetchone()
        if row is None:
            return 0, None
        return int(row["seq"]), float(row["total_quantity"])

    def _collect_site(
        self, host: str, site_key: str, auth: GatewayAuth, limit: int, timeout: float, max_pages: int
    ) -> tuple[int, str]:
        """Liefert (neue Einträge, Blockiergrund oder '')."""
        cursor, previous_total = self._cursor(site_key)
        added = 0
        for _page in range(max_pages):
            response, limit = self._fetch_page(host, cursor, limit, auth, timeout)
            if site_key_from_response(response, host) != site_key:
                return added, "Messstelle hat während des Abrufs gewechselt (andere site_id). Nächster Lauf versucht es erneut."
            entries = response.get("entries")
            if not isinstance(entries, list) or not entries:
                return added, ""

            blocked = ""
            page_added = 0
            collected_at = now_text()
            with self.db.transaction() as conn:
                for raw in sorted(entries, key=_seq_sort_key):
                    try:
                        parsed = parse_entry(raw, previous_total)
                    except EntryError as exc:
                        blocked = f"{exc} Abbruch bei Cursor {cursor}, der Eintrag wird beim nächsten Lauf erneut versucht."
                        break
                    if parsed.seq <= cursor:
                        log.warning("%s: Eintrag mit alter Seq %s übersprungen (Cursor %s)", host, parsed.seq, cursor)
                        continue
                    conn.execute(
                        "INSERT INTO entries(site_id, seq, ts, entry_date, total_quantity, consumed_quantity, "
                        "consumption_source, fuel_type, additional_aggregate, collected_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (site_key, parsed.seq, parsed.ts, parsed.entry_date, parsed.total_quantity,
                         parsed.consumed_quantity, parsed.consumption_source, parsed.fuel_type,
                         int(parsed.additional_aggregate), collected_at),
                    )
                    cursor = parsed.seq
                    previous_total = parsed.total_quantity
                    page_added += 1
            added += page_added
            if blocked:
                return added, blocked
            query = response.get("query") if isinstance(response.get("query"), dict) else {}
            if not _truthy(query.get("has_more", response.get("has_more"))):
                return added, ""
            if page_added == 0:
                return added, "Gateway meldet has_more, liefert aber keine neueren Einträge. Abbruch, um eine Endlosschleife zu vermeiden."
        log.warning("%s: maximale Seitenanzahl %s erreicht", host, max_pages)
        return added, ""

    # --- Verbindungstest -------------------------------------------------

    def test_connection(self, host: str, auth: GatewayAuth) -> dict:
        timeout = float(self.db.get_settings()["timeout_sec"])
        started = time.monotonic()
        response, _ = self._fetch_page(host, 0, 1, auth, timeout)
        device = response.get("device") if isinstance(response.get("device"), dict) else {}
        return {
            "site_id": site_key_from_response(response, host),
            "counter_name": str(device.get("counter_name") or ""),
            "fw_version": str(device.get("fw_version") or ""),
            "demo_mode": _truthy(device.get("demo_mode")),
            "duration_ms": int((time.monotonic() - started) * 1000),
        }


def _seq_sort_key(entry: Any) -> int:
    try:
        return int(str(entry.get("seq")).strip()) if isinstance(entry, dict) else -1
    except ValueError:
        return -1
