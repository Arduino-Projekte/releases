"""Read-only SMB transport. Sessions are isolated; secrets never enter URLs or commands."""
import ipaddress
import logging
import ntpath
import re
import time
import threading

for name in ('smbprotocol', 'smbclient', 'spnego'):
    logging.getLogger(name).setLevel(logging.WARNING)


class ShareError(ValueError):
    pass


def component(value):
    if (not isinstance(value, str) or not value or value in ('.', '..') or len(value) > 255
            or value != value.strip() or value.endswith('.') or any(c in value for c in '\\/:*?"<>|')
            or any(ord(c) < 32 for c in value)):
        raise ShareError('Freigabe und Ordnernamen dürfen keine Pfadwechsel oder Sonderpfade enthalten.')
    return value


def validate_source(values):
    server = values.get('server', '').strip()
    try:
        ipaddress.ip_address(server)
    except ValueError:
        if not re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?', server):
            raise ShareError('SMB-Server als IP-Adresse oder Hostname eingeben, ohne smb:// oder Zugangsdaten.')
    share = component(values.get('share', '').strip())
    subdir = values.get('subdir', '').strip().replace('\\', '/')
    if len(subdir)>500:raise ShareError('Der Unterordner darf höchstens 500 Zeichen lang sein.')
    if subdir:
        subdir = '/'.join(component(part) for part in subdir.split('/'))
    username = values.get('username', '').strip()
    if not username or len(username) > 256 or any(ord(c) < 32 for c in username):
        raise ShareError('SMB-Benutzer angeben; bei Bedarf DOMÄNE\\Benutzer verwenden.')
    name = values.get('name', '').strip()
    if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
        raise ShareError('Einen Namen für die Updatefreigabe angeben (höchstens 80 Zeichen).')
    return dict(name=name, server=server, share=share, subdir=subdir, username=username,
                encrypt=bool(values.get('encrypt', True)), enabled=bool(values.get('enabled', True)))


def safe_error(exc):
    code = getattr(exc, 'ntstatus', getattr(exc, 'status', None))
    if code in (0xC000006D, 0xC000006A, 0xC0000064, 0xC0000234):
        return 'SMB-Anmeldung abgelehnt. Benutzer, Passwort und mögliche Kontosperre prüfen.'
    if code == 0xC0000022 or isinstance(exc, PermissionError):
        return 'Keine Leseberechtigung auf der SMB-Freigabe oder dem Updateordner.'
    if isinstance(exc, (FileNotFoundError, NotADirectoryError)) or code in (0xC0000034, 0xC000003A, 0xC00000CC):
        return 'SMB-Freigabe, Ordner oder Paketdatei nicht gefunden.'
    return 'SMB-Verbindung fehlgeschlagen. Server, Netzwerk, Zugangsdaten und SMB-Verschlüsselung prüfen.'


class Share:
    def __init__(self, source, password, *, port=445, timeout=600):
        self.source = source
        self.password = password
        self.port = port
        self.cache = {}
        self.timeout = timeout
        self.timer = None
        self.root = '\\\\' + source['server'] + '\\' + source['share']
        if source['subdir']:
            self.root += '\\' + source['subdir'].replace('/', '\\')

    def __enter__(self):
        import smbclient
        # Never follow referrals to another server with the configured credentials.
        smbclient.ClientConfig(skip_dfs=True)
        self.timer = threading.Timer(self.timeout, self._disconnect)
        self.timer.daemon = True
        self.timer.start()
        try:
            smbclient.register_session(self.source['server'], username=self.source['username'],
                password=self.password, port=self.port, encrypt=self.source['encrypt'],
                connection_timeout=10, connection_cache=self.cache, auth_protocol='ntlm', require_signing=True)
            return self
        except Exception as exc:
            self.__exit__(None, None, None)
            raise ShareError(safe_error(exc)) from None

    def _disconnect(self):
        for connection in list(self.cache.values()):
            try:connection.disconnect(close=True, timeout=2)
            except Exception:pass  # No raw client exceptions (or credentials) in logs.

    def __exit__(self, *args):
        if self.timer:self.timer.cancel()
        self._disconnect()
        self.cache.clear()
        self.password = None

    def _path(self, relative):
        parts = relative.replace('\\', '/').split('/') if relative else []
        return ntpath.join(self.root, *(component(p) for p in parts))

    def manifests(self):
        """Bounded traversal; reparse points/symlinks are never package directories."""
        import smbclient
        todo = [('', 0)]
        count = 0
        deadline = time.monotonic() + 90
        names = {'update.json', 'vm-update.json', 'docker-update-amd64.json', 'docker-update-arm64.json'}
        while todo:
            relative, depth = todo.pop()
            try:
                with smbclient.scandir(self._path(relative), port=self.port, connection_cache=self.cache) as entries:
                    for entry in entries:
                        count += 1
                        if count > 512 or time.monotonic() > deadline:
                            raise ShareError('Zu viele Dateien oder Unterordner. Einen kleineren Updateordner auswählen (höchstens 512 Einträge, drei Ordnerebenen).')
                        name = component(entry.name)
                        path = '/'.join(p for p in (relative, name) if p)
                        if entry.is_symlink():
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            if depth < 3:todo.append((path, depth + 1))
                        elif entry.is_file(follow_symlinks=False) and name in names:
                            yield path
            except ShareError:
                raise
            except Exception as exc:
                raise ShareError(safe_error(exc)) from None

    def copy(self, relative, destination, limit):
        import smbclient
        total = 0
        deadline = time.monotonic() + 600
        try:
            with smbclient.open_file(self._path(relative), mode='rb', port=self.port,
                                     connection_cache=self.cache, share_access='r') as src, destination.open('wb') as dst:
                while data := src.read(min(1024 * 1024, limit + 1 - total)):
                    total += len(data)
                    if total > limit or time.monotonic() > deadline:
                        raise ShareError('Paket ist zu groß oder die Übertragung dauert zu lange.')
                    dst.write(data)
        except ShareError:
            raise
        except Exception as exc:
            raise ShareError(safe_error(exc)) from None
        return total
